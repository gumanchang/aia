# SDLC Agent Task API 使用指南

本文档介绍 P0/P1 优先级功能的 API 使用方法。

## 功能概览

### P0 - 核心功能

| 功能 | Endpoint | 描述 |
|-----|----------|------|
| CLASSIFY | POST /api/tasks/classify | 意图分类：UI/BRD/PROCESS/COLLECT/SEARCHING |
| UI_GEN_UI | POST /api/tasks/ui-generate | 生成现代 Tailwind CSS UI |
| FLOWCHART | POST /api/tasks/flowchart | 生成 Mermaid 流程图 |
| FIX_MERMAID | POST /api/tasks/fix-mermaid | 修复 Mermaid 语法错误 |

### P1 - 重要功能

| 功能 | Endpoint | 描述 |
|-----|----------|------|
| TRANSLATE | POST /api/tasks/translate | 文档翻译（保留 Mermaid 结构） |
| COMMENT_EDIT | POST /api/tasks/comment-edit | 根据批注编辑文档 |
| UI_EDIT | POST /api/tasks/ui-edit | 修改 UI HTML |
| GEN_TITLE | POST /api/tasks/generate-title | 自动生成会话标题 |

---

## API 详细说明

### 1. 意图分类 (CLASSIFY)

自动识别用户意图，返回分类结果。

**Endpoint:** `POST /api/tasks/classify`

**Request:**
```json
{
  "user_input": "帮我设计一个保险理赔的页面",
  "conversation_history": [
    {"role": "user", "content": "我想做一个保险应用"},
    {"role": "assistant", "content": "好的，请问您需要什么功能？"}
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "classification": "UI",
  "confidence": 1.0
}
```

**分类类型：**
- `UI`: 界面设计相关
- `BRD`: 需求文档相关
- `PROCESS`: 业务流程讨论
- `COLLECT`: 信息收集/澄清
- `SEARCHING`: 知识查询

---

### 2. UI 生成 (UI_GEN_UI)

生成使用 Tailwind CSS 的现代化 UI。

**Endpoint:** `POST /api/tasks/ui-generate` (Streaming)

**Request:**
```json
{
  "user_input": "设计一个保险理赔申请页面，包含申请人信息、事故描述、上传材料",
  "session_id": "optional-session-id",
  "is_screenshot": false
}
```

**Response:** (Stream)
```html
<html lang="zh-CN">
  <div class="min-h-[400px] w-full bg-gray-50 flex items-center justify-center p-6">
    ...
  </div>
</html>
```

**特点：**
- 响应式设计
- 现代风格（参考 Stripe、Vercel、Linear）
- 柔和阴影、圆角、大量留白

---

### 3. 流程图生成 (FLOWCHART)

根据描述生成 Mermaid 流程图代码。

**Endpoint:** `POST /api/tasks/flowchart` (Streaming)

**Request:**
```json
{
  "user_input": "保险理赔流程：客户提交申请 -> 系统初审 -> 人工审核 -> 批准/拒绝 -> 通知客户",
  "session_id": "optional-session-id"
}
```

**Response:** (Stream)
```mermaid
graph TD
    A[客户提交申请] --> B{系统初审}
    B -->|通过| C[人工审核]
    B -->|不通过| D[通知客户补充材料]
    C -->|批准| E[理赔批准]
    C -->|拒绝| F[理赔拒绝]
    E --> G[通知客户]
    F --> G
    D --> A
```

---

### 4. Mermaid 修复 (FIX_MERMAID)

修复 Mermaid 代码中的语法错误。

**Endpoint:** `POST /api/tasks/fix-mermaid` (Streaming)

**Request:**
```json
{
  "error_message": "Parse error on line 3: ...",
  "mermaid_code": "graph TD\n  A --> B\n  B -- Error --> C"
}
```

**常见修复：**
- 删除 HTML 标签（`<br>`、`<div>` 等）
- 特殊字符添加引号：`A -- "Price < 100" --> B`
- 修复节点 ID 格式

---

### 5. 文档翻译 (TRANSLATE)

翻译业务需求文档，保留 Mermaid 代码结构。

**Endpoint:** `POST /api/tasks/translate` (Streaming)

**Request:**
```json
{
  "document_content": "# 业务需求\n\n## 流程\n```mermaid\ngraph TD\n  A[开始] --> B[结束]\n```",
  "target_lang": "English"
}
```

**翻译规则：**
- 保留 Markdown 结构
- 保留专业术语
- **不翻译** Mermaid 关键字（graph、flowchart、TD 等）
- **翻译** 节点标签（方括号中的文本）

---

### 6. 批注编辑 (COMMENT_EDIT)

根据用户对选中文字的批注进行修改。

**Endpoint:** `POST /api/tasks/comment-edit` (Streaming)

**Request:**
```json
{
  "selected_text": "系统将在3个工作日内完成审核",
  "user_comment": "改成1个工作日，体现效率",
  "doc_context": "# 审核流程\n系统将在3个工作日内完成审核，并通知用户结果。"
}
```

**原则：**
- 最小修改：只修改选中部分
- 风格一致：保持原文语气
- 上下文一致：修改内容在整体语境中自然

---

### 7. UI 编辑 (UI_EDIT)

根据用户反馈修改 UI HTML。

**Endpoint:** `POST /api/tasks/ui-edit` (Streaming)

**Request:**
```json
{
  "original_html": "<div class=\"bg-blue-500\">...</div>",
  "user_instruction": "把背景色改成红色，按钮加大一些"
}
```

**特点：**
- 保持原有结构
- 使用 Tailwind CSS
- 最小改动原则

---

### 8. 生成标题 (GEN_TITLE)

根据用户输入自动生成会话标题。

**Endpoint:** `POST /api/tasks/generate-title`

**Request:**
```json
{
  "user_input": "帮我设计一个保险理赔的审批流程，需要包含初审和复审环节"
}
```

**Response:**
```json
{
  "status": "success",
  "title": "保险理赔审批流程设计"
}
```

---

## WebSocket 通用接口

### Endpoint: `/ws/task`

支持所有任务类型的统一 WebSocket 接口。

**消息格式：**
```json
{
  "task_type": "UI_GEN_UI",
  "user_input": "...",
  "context": {...},
  "session_id": "..."
}
```

**响应格式：**
```json
// Chunk
{"type": "chunk", "content": "..."}

// Complete
{"type": "complete", "task_type": "UI_GEN_UI", "content": "..."}

// Error
{"type": "error", "message": "..."}
```

**示例 (JavaScript):**
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/task');

ws.onopen = () => {
  ws.send(JSON.stringify({
    task_type: 'FLOWCHART',
    user_input: '保险理赔流程...'
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  if (data.type === 'chunk') {
    console.log(data.content);
  } else if (data.type === 'complete') {
    console.log('Done:', data.content);
  }
};
```

---

## 完整工作流示例

### 场景：用户说"帮我设计一个保险理赔系统"

**Step 1: 意图分类**
```bash
curl -X POST http://localhost:8000/api/tasks/classify \
  -H "Content-Type: application/json" \
  -d '{"user_input": "帮我设计一个保险理赔系统"}'
# Response: {"classification": "COLLECT"}
```

**Step 2: 信息收集**
```bash
curl -X POST http://localhost:8000/api/tasks/execute \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "COLLECT",
    "user_input": "帮我设计一个保险理赔系统"
  }'
# Response: 追问用户具体需求...
```

**Step 3: 生成流程图**
```bash
curl -X POST http://localhost:8000/api/tasks/flowchart \
  -H "Content-Type: application/json" \
  -d '{"user_input": "理赔流程：提交申请->初审->复审->批准/拒绝"}'
```

**Step 4: 生成 UI**
```bash
curl -X POST http://localhost:8000/api/tasks/ui-generate \
  -H "Content-Type: application/json" \
  -d '{"user_input": "理赔申请表单页面"}'
```

**Step 5: 生成文档**
```bash
curl -X POST http://localhost:8000/api/documents/generate \
  -F "doc_type=BRD" \
  -F "requirements=保险理赔系统需求..."
```

---

## 前端集成示例

查看 `static/task_api_demo.html` 获取完整的前端示例代码。

启动服务器后访问：`http://localhost:8000/static/task_api_demo.html`

---

## 错误处理

所有 API 返回标准的 HTTP 状态码：

- `200`: 成功
- `400`: 请求参数错误
- `404`: 资源未找到
- `500`: 服务器内部错误

错误响应格式：
```json
{
  "detail": "Error message"
}
```

---

## 性能提示

1. **Streaming 接口**：所有生成类接口都使用流式响应，建议前端实现渐进式显示
2. **WebSocket 复用**：对于多轮对话，建议使用 WebSocket 连接复用
3. **Session 管理**：使用 `session_id` 保持会话上下文
