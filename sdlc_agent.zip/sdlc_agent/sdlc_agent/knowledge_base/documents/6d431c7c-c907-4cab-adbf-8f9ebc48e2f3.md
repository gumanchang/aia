# Functional Specification Document

## Document Information
- **Document Title**: E-Commerce Platform Order Management Functional Specification
- **Document Version**: 1.0
- **Date**: 2026-02-12
- **Author**: Technical Specifications Team

---

## 1. Introduction

### 1.1 Purpose  
This document defines the functional requirements for the Order Management subsystem of the e-commerce platform. It serves as a formal agreement between stakeholders, developers, product owners, and QA teams to ensure consistent understanding and implementation of order lifecycle capabilities — including creation, retrieval, modification, cancellation, and status tracking.

### 1.2 Scope  
This specification covers all core order-related functionalities accessible to both end customers (via web/mobile frontend) and internal administrators (via merchant dashboard). It excludes payment gateway integration logic (handled by separate Payment Service), inventory synchronization protocols (managed by Inventory Service), and shipping label generation (delegated to Logistics API). The scope includes:
- Customer-initiated order creation (cart-based & guest checkout)
- Real-time order status querying (by order ID or user context)
- Editable fields during pre-fulfillment state (e.g., shipping address, contact info)
- Cancellation workflows with eligibility validation and refund policy enforcement
- Role-based visibility and audit logging for admin operations

### 1.3 Definitions, Acronyms, and Abbreviations  

| Term | Definition |
|------|------------|
| **OMS** | Order Management System — the subsystem governed by this FDS |
| **SKU** | Stock Keeping Unit — unique identifier for each product variant |
| **PO** | Purchase Order — internal fulfillment reference generated post-payment confirmation |
| **SO** | Sales Order — customer-facing order record created at checkout |
| **FBA** | Fulfillment by Amazon — third-party logistics model; referenced in fulfillment routing logic |
| **SLA** | Service Level Agreement — defines max response time for order status queries (< 800ms p95) |
| **PCI-DSS** | Payment Card Industry Data Security Standard — compliance requirement for handling cardholder data (not stored; tokenized only) |

---

## 2. System Overview

### 2.1 Product Perspective  
The Order Management subsystem is a bounded context within the broader e-commerce microservice architecture. It communicates with:
- **Cart Service** (via REST/gRPC) to retrieve cart snapshot at checkout
- **Authentication Service** (JWT-integrated) for user identity and role validation
- **Product Catalog Service** (event-driven) to verify SKU availability and pricing at order creation
- **Notification Service** (async via Kafka) to dispatch email/SMS confirmations
- **Audit Log Service** (centralized) for immutable operation tracing

It exposes its functionality through:
- Public RESTful APIs (`/api/v1/orders`)
- GraphQL endpoint for dashboard analytics (`/graphql`)
- Admin UI components embedded in Merchant Portal (React-based)

### 2.2 Product Functions  
The OMS provides the following key functions:
- ✅ **Order Creation**: Atomic transaction capturing items, shipping/billing addresses, coupons, and tax calculations  
- ✅ **Order Querying**: Filtered search (by ID, date range, status, customer email), paginated listing, real-time status polling  
- ✅ **Order Modification**: Limited edits (address, contact, note) before payment confirmation or warehouse pick-up  
- ✅ **Order Cancellation**: State-aware revocation with automatic partial/full refund initiation and inventory restocking  
- ✅ **Status Lifecycle Management**: Enforced transitions (e.g., `CREATED` → `PAID` → `CONFIRMED` → `SHIPPED` → `DELIVERED` → `COMPLETED`)  
- ✅ **Audit Trail Generation**: Immutable log per order action, including actor, timestamp, IP, and payload diff  

### 2.3 User Classes and Characteristics  

| Role | Characteristics | Access Rights |
|------|-----------------|----------------|
| **Registered Customer** | Uses browser or mobile app; expects intuitive flow, instant feedback, self-service options | Create, view own orders, cancel eligible orders, download invoices |
| **Guest Customer** | No account; provides email + phone; limited post-order support | Create order (email-verified), view order via link, no edit/cancel after submission |
| **Store Administrator** | Internal staff managing merchant portal; trained on SLA policies | View all orders, update status (e.g., mark as shipped), add internal notes, trigger manual refunds |
| **Customer Support Agent** | Tier-1 support; uses agent console with guided workflows | View order details, initiate cancellation/refund, send templated notifications, escalate to logistics |
| **System Auditor** | Compliance/security team; read-only access to logs | Query audit trail, export logs, verify GDPR deletion requests |

### 2.4 Operating Environment  
- **Frontend**: React 18+ (Web), React Native 0.73+ (iOS/Android)  
- **Backend**: Java 17 (Spring Boot 3.2), PostgreSQL 15 (ACID-compliant OLTP), Redis 7 (caching session/order status)  
- **Deployment**: Kubernetes (EKS/GKE), Helm-managed, multi-AZ in `us-east-1` and `eu-west-1`  
- **APIs**: REST/JSON over HTTPS (TLS 1.3), rate-limited (100 req/min per API key), OpenAPI 3.1 spec enforced  
- **Compliance**: GDPR-ready (right-to-erasure), CCPA-aligned, PCI-DSS SAQ A-EP compliant (no raw PAN storage)  

---

## 3. Functional Requirements

### 3.1 Order Lifecycle Management

#### 3.1.1 Requirement ID: FR-001 — Order Creation  
- **Description**: System shall allow authenticated users and guests to create a new sales order from a validated cart snapshot, applying real-time pricing, taxes, and promotional rules.  
- **Input**:  
  - Cart ID (required)  
  - Shipping address (object: `street`, `city`, `state`, `postalCode`, `countryCode`, `phone`)  
  - Billing address (optional; defaults to shipping if omitted)  
  - Contact email & phone (required for guests; optional for registered users)  
  - Coupon code (optional, validated against active campaigns)  
  - Preferred currency (default: user locale or site default)  
- **Processing**:  
  - Validates cart existence and item availability (calls Catalog Service)  
  - Computes subtotal, tax (via Tax Service), shipping cost (via Rate Engine), discounts, and total  
  - Generates SO ID (`SO-{YYYYMMDD}-{6-digit-uuid}`), creates order record in `orders` table  
  - Locks SKUs (via Inventory Service) for 15 minutes to prevent oversell  
  - Publishes `order.created` event to Kafka topic `ecommerce.orders`  
- **Output**:  
  - HTTP 201 Created with JSON payload:  
    ```json
    {
      "soId": "SO-20260212-7a3f9b",
      "status": "CREATED",
      "createdAt": "2026-02-12T09:45:22.183Z",
      "totalAmount": 129.99,
      "currency": "USD",
      "items": [{"sku": "LAP-PRO-X1", "qty": 1, "unitPrice": 119.99}],
      "shippingEstimateDays": 3
    }
    ```  
- **Error Handling**:  
  - `400 Bad Request`: Missing cart ID, invalid address format, expired coupon  
  - `404 Not Found`: Cart not found or empty  
  - `409 Conflict`: SKU out of stock or quantity exceeded  
  - `503 Service Unavailable`: Tax/Inventory service timeout (> 3s)  

#### 3.1.2 Requirement ID: FR-002 — Order Status Query  
- **Description**: System shall enable users to retrieve one or more orders using flexible filters, with pagination and real-time status resolution.  
- **Input**:  
  - Authenticated user context (JWT) *or* valid SO ID + email verification token (for guests)  
  - Optional query parameters: `soId`, `status[]`, `fromDate`, `toDate`, `email`, `page=1`, `limit=20`  
- **Processing**:  
  - For authenticated users: returns all orders matching filters, sorted descending by `createdAt`  
  - For guest lookup: verifies email-token binding before returning single order  
  - Applies PostgreSQL full-text search on `customerEmail`, `shippingAddress->>'city'`, and `items->>'sku'`  
  - Caches results in Redis with TTL=60s for identical parameter sets  
- **Output**:  
  - HTTP 200 OK with paginated response:  
    ```json
    {
      "data": [{
        "soId": "SO-20260212-7a3f9b",
        "status": "PAID",
        "totalAmount": 129.99,
        "currency": "USD",
        "createdAt": "2026-02-12T09:45:22Z",
        "updatedAt": "2026-02-12T09:47:11Z",
        "itemsCount": 1,
        "shippingMethod": "Standard"
      }],
      "pagination": {"page": 1, "limit": 20, "total": 1}
    }
    ```  
- **Error Handling**:  
  - `401 Unauthorized`: Invalid/missing JWT or expired guest token  
  - `403 Forbidden`: Guest attempts to list multiple orders  
  - `422 Unprocessable Entity`: Invalid date format or unsupported status value  

### 3.2 Order Modification & Cancellation

#### 3.2.1 Requirement ID: FR-003 — Order Modification  
- **Description**: System shall permit editing of non-financial, non-fulfillment-critical fields for orders in `CREATED` or `PAID` status, subject to business rules.  
- **Input**:  
  - Valid SO ID (path param)  
  - PATCH body containing editable fields only: `shippingAddress`, `billingAddress`, `contactPhone`, `customerNote`  
- **Processing**:  
  - Validates current order status ∈ {`CREATED`, `PAID`}  
  - Rejects edits if warehouse pick has begun (checked via `fulfillmentStatus` field in `orders_fulfillment` table)  
  - Updates fields atomically; triggers `order.updated` event  
  - Recalculates shipping estimate if address changes (calls Rate Engine)  
- **Output**:  
  - HTTP 200 OK with updated order object (same structure as FR-001 output)  
- **Error Handling**:  
  - `400 Bad Request`: Attempt to modify `totalAmount`, `items`, or `status`  
  - `409 Conflict`: Order status is `CONFIRMED` or higher  
  - `422 Unprocessable Entity`: Invalid address schema or phone number format  

#### 3.2.2 Requirement ID: FR-004 — Order Cancellation  
- **Description**: System shall support cancellation of eligible orders with automated inventory restoration and refund orchestration.  
- **Input**:  
  - SO ID (path param)  
  - Optional reason code: `"customer_changed_mind"`, `"duplicate_order"`, `"item_unavailable"`  
- **Processing**:  
  - Validates eligibility: status ∈ {`CREATED`, `PAID`, `CONFIRMED`} AND no shipment label generated  
  - Transitions status to `CANCELLED`  
  - Calls Inventory Service to release locked SKUs  
  - If `PAID`, publishes `refund.initiate` event to Payment Service (full refund unless partial items cancelled)  
  - Logs cancellation reason and initiator (user vs admin) in `order_audit` table  
- **Output**:  
  - HTTP 200 OK with:  
    ```json
    {
      "soId": "SO-20260212-7a3f9b",
      "status": "CANCELLED",
      "cancelledAt": "2026-02-12T10:15:03.201Z",
      "refundInitiated": true,
      "inventoryRestored": true
    }
    ```  
- **Error Handling**:  
  - `400 Bad Request`: Reason code invalid or missing  
  - `409 Conflict`: Order is `SHIPPED`, `DELIVERED`, or `COMPLETED`  
  - `500 Internal Server Error`: Inventory rollback failed (retries 3x before alert)  

---

## 4. Non-Functional Requirements

### 4.1 Performance Requirements  
- **Order Creation**: ≤ 1.2s p95 latency under 500 TPS load (simulated peak)  
- **Order Query**: ≤ 800ms p95 for single-order lookup; ≤ 1.5s p95 for filtered list (10k+ orders)  
- **Cache Hit Rate**: ≥ 92% for order status queries (measured weekly)  
- **Throughput**: Sustain 1,200 orders/hour during flash sale events (auto-scaled pods)  

### 4.2 Security Requirements  
- All order endpoints require authentication (JWT Bearer token)  
- SO IDs are obfuscated in UI (e.g., `SO-****-7a3f9b`) — full ID exposed only in admin context  
- PII (email, phone, address) encrypted at rest (AES-256-GCM) and masked in logs  
- Audit logs retain full payloads for 180 days; immutable via write-once storage  
- Rate limiting: 50 requests/hour per SO ID for guest lookups  

### 4.3 Usability Requirements  
- Customers complete order creation in ≤ 3 steps (Cart → Address/Contact → Review/Submit)  
- Cancellation flow includes clear eligibility banner and refund timeline estimate  
- Admin dashboard shows visual status timeline (see Appendix A)  
- All error messages are actionable (e.g., “Coupon ‘WELCOME20’ expired on 2026-01-31” instead of “Invalid coupon”)  

### 4.4 Reliability Requirements  
- Data consistency guaranteed via distributed transaction pattern (Saga pattern for refund + inventory)  
- Order records survive database failover with < 15s RPO (PostgreSQL synchronous replication)  
- Idempotent order creation: duplicate POST with same idempotency key returns original SO ID  
- Zero data loss SLA: 99.999% for order writes (backed by WAL archiving + point-in-time recovery)  

---

## 5. Interface Requirements

### 5.1 User Interfaces  
Below is the responsive HTML/CSS for the **Order Detail View** (Customer-Facing), designed for clarity and actionability:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Order #SO-20260212-7a3f9b</title>
  <style>
    :root { --primary: #2563eb; --success: #10b981; --warn: #f59e0b; --danger: #ef4444; }
    body { font-family: 'Segoe UI', system-ui; line-height: 1.6; margin: 0; padding: 1rem; color: #1f2937; }
    .container { max-width: 1024px; margin: 0 auto; }
    .status-badge { display: inline-block; padding: 0.375rem 0.75rem; border-radius: 9999px; font-size: 0.875rem; font-weight: 600; }
    .status-paid { background-color: var(--success); color: white; }
    .status-cancelled { background-color: var(--danger); color: white; }
    .action-btn { background-color: var(--primary); color: white; border: none; padding: 0.5rem 1rem; border-radius: 0.375rem; cursor: pointer; font-weight: 600; }
    .action-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .timeline { position: relative; padding-left: 1.5rem; }
    .timeline::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 2px; background-color: #d1d5db; }
    .timeline-item { margin-bottom: 1.5rem; position: relative; }
    .timeline-item::before { content: ''; position: absolute; left: -32px; top: 0.5rem; width: 16px; height: 16px; border-radius: 50%; background-color: var(--primary); }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>Order Details</h1>
      <p><strong>Order ID:</strong> <code>SO-20260212-7a3f9b</code></p>
      <span class="status-badge status-paid">Paid</span>
      <p><strong>Date:</strong> Feb 12, 2026 • <strong>Estimated Delivery:</strong> Feb 15–18, 2026</p>
    </header>

    <section>
      <h2>Order Summary</h2>
      <ul>
        <li><strong>Laptop Pro X1</strong> × 1 — $119.99</li>
        <li><strong>Shipping</strong> — $4.99</li>
        <li><strong>Tax</strong> — $5.01</li>
      </ul>
      <p><strong>Total:</strong> $129.99</p>
    </section>

    <section>
      <h2>Status Timeline</h2>
      <div class="timeline">
        <div class="timeline-item">
          <h3>Feb 12, 2026 — 09:45 AM</h3>
          <p><strong>Order Created</strong></p>
        </div>
        <div class="timeline-item">
          <h3>Feb 12, 2026 — 09:47 AM</h3>
          <p><strong>Payment Confirmed</strong> • Visa ending in 4242</p>
        </div>
        <div class="timeline-item">
          <h3>Feb 12, 2026 — 10:10 AM</h3>
          <p><strong>Fulfillment Confirmed</strong> • Warehouse Pick Initiated</p>
        </div>
      </div>
    </section>

    <section>
      <h2>Actions</h2>
      <button class="action-btn" id="cancelBtn">Cancel Order</button>
      <button class="action-btn" disabled>Download Invoice</button>
      <button class="action-btn">Contact Support</button>
    </section>

    <footer>
      <p>Need help? Call us at <a href="tel:+18005550199">1-800-555-0199</a> or email <a href="mailto:support@shop.example">support@shop.example</a></p>
    </footer>
  </div>

  <script>
    document.getElementById('cancelBtn').addEventListener('click', function() {
      if (confirm("Are you sure you want to cancel this order? You'll receive a full refund within 3–5 business days.")) {
        fetch('/api/v1/orders/SO-20260212-7a3f9b/cancel', { method: 'POST' })
          .then(r => r.json())
          .then(data => {
            alert(`Order cancelled successfully. Refund initiated.`);
            document.querySelector('.status-badge').textContent = 'Cancelled';
            document.querySelector('.status-badge').className = 'status-badge status-cancelled';
            this.disabled = true;
          });
      }
    });
  </script>
</body>
</html>
```

### 5.2 Hardware Interfaces  
None — cloud-native SaaS deployment; no direct hardware dependencies.

### 5.3 Software Interfaces  
| Interface | Protocol | Direction | Description |
|----------|----------|-----------|-------------|
| `catalog-service` | gRPC over TLS | OMS → Catalog | `GetProduct(SKU)` for price/availability check at creation |
| `inventory-service` | REST/HTTPS | OMS ↔ Inventory | `LockItems(cartId, items[])`, `ReleaseItems(soId)` |
| `tax-service` | REST/HTTPS | OMS → Tax | `CalculateTax(address, amount, lineItems)` |
| `notification-service` | Kafka (Avro) | OMS → Notification | Events: `order.created`, `order.cancelled`, `order.shipped` |
| `payment-service` | REST/HTTPS | OMS → Payment | `InitiateRefund(paymentId, amount, reason)` |

### 5.4 Communications Interfaces  
- All inter-service communication uses mutual TLS (mTLS) with SPIFFE identities  
- External APIs (e.g., carrier tracking) use OAuth 2.0 client credentials flow  
- Webhooks for partner integrations (e.g., ERP sync) secured via HMAC-SHA256 signature validation  

---

## 6. Data Requirements

### 6.1 Data Input  
- **Mandatory Fields**: `cartId`, `shippingAddress`, `contactEmail`, `contactPhone` (guest), `currency`  
- **Validated Formats**:  
  - Email: RFC 5322 compliant regex  
  - Phone: E.164 format (`+1XXXXXXXXXX`)  
  - Postal Code: Per-country regex (e.g., US: `^\d{5}(-\d{4})?$`, UK: `^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$`)  

### 6.2 Data Output  
- **Public APIs**: JSON only (no XML, no custom binary formats)  
- **Admin Reports**: CSV (UTF-8) and PDF (via Puppeteer) — include headers, totals, and pagination metadata  
- **Audit Logs**: Structured JSON (CloudEvents 1.0 spec) with `type`, `source`, `id`, `time`, `data`  

### 6.3 Data Storage  
- **Primary Store**: PostgreSQL 15  
  - Table `orders`: `so_id (PK)`, `user_id`, `status`, `total_amount`, `currency`, `created_at`, `updated_at`, `version`  
  - Table `order_items`: `id (PK)`, `so_id (FK)`, `sku`, `quantity`, `unit_price`, `discount_amount`  
  - Table `order_addresses`: `id (PK)`, `so_id (FK)`, `type ('shipping'/'billing')`, `address_json (JSONB)`  
- **Cache**: Redis 7 — keys: `order:SO-XXXXX`, `order:by_user:{userId}`, TTL=60s  
- **Audit Log**: Append-only TimescaleDB hypertable `order_audit` partitioned by month  

---

## 7. Constraints  
- **Regulatory**: Must comply with EU VAT MOSS rules — tax calculation must reflect customer’s country of residence, not ship-from location  
- **Technical**: No synchronous calls to external logistics APIs during order creation (use async event + eventual consistency)  
- **Business**: Orders cannot be cancelled after `CONFIRMED` status if warehouse pick time > 10 minutes (hard SLA)  
- **Architectural**: All order mutations must be idempotent — repeated identical requests yield same result  
- **Localization**: UI strings must support i18n (English, Spanish, French, German, Japanese); date/time formats locale-aware  

---

## 8. Assumptions and Dependencies  

### Assumptions  
- Cart Service guarantees cart immutability during checkout flow (locks cart on `GET /cart/{id}`)  
- Authentication Service issues JWTs with `user_id`, `roles: ["customer", "admin"]`, and `exp` claims  
- Product Catalog Service updates inventory counts within 2 seconds of `InventoryUpdated` event  
- Customers consent to email/SMS notifications during registration/checkout (GDPR-compliant opt-in)  

### Dependencies  
- **Upstream**:  
  - `auth-service` (v2.4+) — for JWT validation and user profile enrichment  
  - `catalog-service` (v3.1+) — for SKU validation and real-time pricing  
- **Downstream**:  
  - `notification-service` (v1.7+) — required for order confirmation emails  
  - `audit-log-service` (v4.0+) — mandatory for all write operations  
- **External**:  
  - Stripe/PayPal APIs (PCI-DSS certified) — for payment processing (tokenization only)  
  - USPS/FedEx Rate APIs — for shipping cost estimation (fallback to flat-rate if unavailable)  

---

## Appendices

### Appendix A: Sample Screenshots  
**Admin Order Dashboard — Status Timeline Visualization**  
*(Mermaid flowchart showing state transitions)*  

```mermaid
flowchart TD
    A[CREATED] -->|Payment Success| B[PAID]
    B -->|Warehouse Confirms| C[CONFIRMED]
    C -->|Label Generated| D[SHIPPED]
    D -->|Carrier Scan| E[DELIVERED]
    E -->|No Returns| F[COMPLETED]
    
    A -->|User Cancels| G[CANCELLED]
    B -->|User Cancels| G
    C -->|Admin Cancels| G
    D -->|Carrier Exception| H[RETURNED]
    H -->|Restock Confirmed| I[RESTOCKED]
    
    style A fill:#dbeafe,stroke:#3b82f6,color:white
    style B fill:#bbf7d0,stroke:#10b981,color:black
    style C fill:#fef9c3,stroke:#f59e0b,color:black
    style D fill:#c7d2fe,stroke:#6366f1,color:white
    style E fill:#a7f3d0,stroke:#10b981,color:black
    style F fill:#f0fdf4,stroke:#10b981,color:black
    style G fill:#fee2e2,stroke:#ef4444,color:black
    style H fill:#fbcfe8,stroke:#ec4899,color:black
    style I fill:#e0f2fe,stroke:#0891b2,color:black
```

### Appendix B: Sample Reports  
**Daily Order Summary Report (CSV Snippet)**  
```
date,so_id,status,total_amount,currency,items_count,shipping_method,refunded_amount
2026-02-12,SO-20260212-7a3f9b,PAID,129.99,USD,1,Standard,0.00
2026-02-12,SO-20260212-1e8c4d,CANCELLED,89.99,USD,2,Express,89.99
```

### Appendix C: Glossary  
- **Cart Snapshot**: Immutable copy of cart contents at order creation time; decouples order from live cart state  
- **Idempotency Key**: Client-provided UUID used to deduplicate order creation requests (stored in `orders.idempotency_key`)  
- **Fulfillment Status**: Internal flag (`PENDING_PICK`, `IN_PICK`, `PACKED`, `LABEL_GENERATED`) tracked separately from order status  
- **SO ID Obfuscation**: Client-side masking of SO ID for privacy; backend retains full ID for traceability  

---  
*End of Document*

<!--METADATA:{"type": "metadata", "doc_type": "FDS", "flowcharts": [{"id": "flowchart_0", "type": "flowchart", "code": "flowchart TD\n    A[CREATED] -->|Payment Success| B[PAID]\n    B -->|Warehouse Confirms| C[CONFIRMED]\n    C -->|Label Generated| D[SHIPPED]\n    D -->|Carrier Scan| E[DELIVERED]\n    E -->|No Returns| F[COMPLETED]\n    \n    A -->|User Cancels| G[CANCELLED]\n    B -->|User Cancels| G\n    C -->|Admin Cancels| G\n    D -->|Carrier Exception| H[RETURNED]\n    H -->|Restock Confirmed| I[RESTOCKED]\n    \n    style A fill:#dbeafe,stroke:#3b82f6,color:white\n    style B fill:#bbf7d0,stroke:#10b981,color:black\n    style C fill:#fef9c3,stroke:#f59e0b,color:black\n    style D fill:#c7d2fe,stroke:#6366f1,color:white\n    style E fill:#a7f3d0,stroke:#10b981,color:black\n    style F fill:#f0fdf4,stroke:#10b981,color:black\n    style G fill:#fee2e2,stroke:#ef4444,color:black\n    style H fill:#fbcfe8,stroke:#ec4899,color:black\n    style I fill:#e0f2fe,stroke:#0891b2,color:black"}], "ui_designs": [{"id": "ui_design_0", "code": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\n  <title>Order #SO-20260212-7a3f9b</title>\n  <style>\n    :root { --primary: #2563eb; --success: #10b981; --warn: #f59e0b; --danger: #ef4444; }\n    body { font-family: 'Segoe UI', system-ui; line-height: 1.6; margin: 0; padding: 1rem; color: #1f2937; }\n    .container { max-width: 1024px; margin: 0 auto; }\n    .status-badge { display: inline-block; padding: 0.375rem 0.75rem; border-radius: 9999px; font-size: 0.875rem; font-weight: 600; }\n    .status-paid { background-color: var(--success); color: white; }\n    .status-cancelled { background-color: var(--danger); color: white; }\n    .action-btn { background-color: var(--primary); color: white; border: none; padding: 0.5rem 1rem; border-radius: 0.375rem; cursor: pointer; font-weight: 600; }\n    .action-btn:disabled { opacity: 0.5; cursor: not-allowed; }\n    .timeline { position: relative; padding-left: 1.5rem; }\n    .timeline::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 2px; background-color: #d1d5db; }\n    .timeline-item { margin-bottom: 1.5rem; position: relative; }\n    .timeline-item::before { content: ''; position: absolute; left: -32px; top: 0.5rem; width: 16px; height: 16px; border-radius: 50%; background-color: var(--primary); }\n  </style>\n</head>\n<body>\n  <div class=\"container\">\n    <header>\n      <h1>Order Details</h1>\n      <p><strong>Order ID:</strong> <code>SO-20260212-7a3f9b</code></p>\n      <span class=\"status-badge status-paid\">Paid</span>\n      <p><strong>Date:</strong> Feb 12, 2026 • <strong>Estimated Delivery:</strong> Feb 15–18, 2026</p>\n    </header>\n\n    <section>\n      <h2>Order Summary</h2>\n      <ul>\n        <li><strong>Laptop Pro X1</strong> × 1 — $119.99</li>\n        <li><strong>Shipping</strong> — $4.99</li>\n        <li><strong>Tax</strong> — $5.01</li>\n      </ul>\n      <p><strong>Total:</strong> $129.99</p>\n    </section>\n\n    <section>\n      <h2>Status Timeline</h2>\n      <div class=\"timeline\">\n        <div class=\"timeline-item\">\n          <h3>Feb 12, 2026 — 09:45 AM</h3>\n          <p><strong>Order Created</strong></p>\n        </div>\n        <div class=\"timeline-item\">\n          <h3>Feb 12, 2026 — 09:47 AM</h3>\n          <p><strong>Payment Confirmed</strong> • Visa ending in 4242</p>\n        </div>\n        <div class=\"timeline-item\">\n          <h3>Feb 12, 2026 — 10:10 AM</h3>\n          <p><strong>Fulfillment Confirmed</strong> • Warehouse Pick Initiated</p>\n        </div>\n      </div>\n    </section>\n\n    <section>\n      <h2>Actions</h2>\n      <button class=\"action-btn\" id=\"cancelBtn\">Cancel Order</button>\n      <button class=\"action-btn\" disabled>Download Invoice</button>\n      <button class=\"action-btn\">Contact Support</button>\n    </section>\n\n    <footer>\n      <p>Need help? Call us at <a href=\"tel:+18005550199\">1-800-555-0199</a> or email <a href=\"mailto:support@shop.example\">support@shop.example</a></p>\n    </footer>\n  </div>\n\n  <script>\n    document.getElementById('cancelBtn').addEventListener('click', function() {\n      if (confirm(\"Are you sure you want to cancel this order? You'll receive a full refund within 3–5 business days.\")) {\n        fetch('/api/v1/orders/SO-20260212-7a3f9b/cancel', { method: 'POST' })\n          .then(r => r.json())\n          .then(data => {\n            alert(`Order cancelled successfully. Refund initiated.`);\n            document.querySelector('.status-badge').textContent = 'Cancelled';\n            document.querySelector('.status-badge').className = 'status-badge status-cancelled';\n            this.disabled = true;\n          });\n      }\n    });\n  </script>\n</body>\n</html>"}]}-->