"""
Task Manager - Handles different task types (CLASSIFY, UI_GEN_UI, FLOWCHART, etc.)
"""
import json
import re
from typing import AsyncIterator, Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass
from enum import Enum

from core.llm_client import LLMClient, Message, llm_client
from core.prompts import task_prompts
from core.logger import get_logger

logger = get_logger("task_manager")


class TaskType(str, Enum):
    """Supported task types"""
    # P0 - Core
    CLASSIFY = "CLASSIFY"
    UI_GEN_UI = "UI_GEN_UI"
    SCREENSHOT_UI = "SCREENSHOT_UI"
    FLOWCHART = "FLOWCHART"
    FIX_MERMAID = "FIX_MERMAID"
    
    # P1 - Important
    TRANSLATE = "TRANSLATE"
    COMMENT_EDIT = "COMMENT_EDIT"
    UI_EDIT = "UI_EDIT"
    POLISH_TEXT = "POLISH_TEXT"  # 润色/修改选中的文字
    
    # Additional
    GENERAL = "GENERAL"
    COLLECT = "COLLECT"
    GEN_TITLE = "GEN_TITLE"
    SEARCHING_ANSWER = "SEARCHING_ANSWER"
    
    # Document types
    BRD = "BRD"
    FSD = "FSD"
    FSD_EN = "FSD_EN"


@dataclass
class ClassifyResult:
    """Result of classification"""
    classification: str
    confidence: float = 1.0


@dataclass
class TaskRequest:
    """Task request structure"""
    task_type: TaskType
    user_input: str
    context: Optional[Dict[str, Any]] = None
    images: Optional[List[Dict[str, Any]]] = None
    session_id: Optional[str] = None


class TaskManager:
    """Manages different task types"""
    
    def __init__(self, llm_client: LLMClient = None):
        self.llm_client = llm_client or LLMClient()
    
    async def classify_intent(self, user_input: str, conversation_history: List[Dict] = None) -> ClassifyResult:
        """
        Classify user intent into task types
        
        Returns:
            ClassifyResult with classification and confidence
        """
        messages = [
            Message(role="system", content=task_prompts.get_classify_prompt()),
            Message(role="user", content=user_input)
        ]
        
        # Add conversation history if provided
        if conversation_history:
            for msg in conversation_history[-3:]:  # Only use last 3 messages for context
                role = msg.get("role", "user")
                content = msg.get("content", "")
                messages.insert(-1, Message(role=role, content=content))
        
        try:
            response = await self.llm_client.generate(messages)
            
            # Extract JSON from response
            json_match = re.search(r'\{[^}]+\}', response)
            if json_match:
                result = json.loads(json_match.group())
                classification = result.get("classification", "PROCESS")
            else:
                # Fallback: try to find classification directly
                for task_type in ["UI", "BRD", "PROCESS", "COLLECT", "SEARCHING"]:
                    if task_type in response.upper():
                        classification = task_type
                        break
                else:
                    classification = "PROCESS"
            
            logger.info(f"Classified intent: {classification} for input: {user_input[:50]}...")
            return ClassifyResult(classification=classification)
            
        except Exception as e:
            logger.error(f"Classification error: {e}")
            return ClassifyResult(classification="PROCESS")
    
    async def generate_ui(
        self, 
        user_input: str,
        images: Optional[List[Dict[str, Any]]] = None,
        is_screenshot: bool = False
    ) -> AsyncIterator[str]:
        """
        Generate UI using Tailwind CSS
        
        Args:
            user_input: User requirements
            images: Optional images for screenshot-based generation
            is_screenshot: Whether to use screenshot UI prompt
        """
        if is_screenshot and images:
            system_prompt = task_prompts.get_screenshot_ui_prompt()
        else:
            system_prompt = task_prompts.get_ui_gen_ui_prompt()
        
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_input, images=images)
        ]
        
        logger.info(f"Generating UI (screenshot={is_screenshot})...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def generate_flowchart(
        self, 
        user_input: str,
        validate: bool = True,
        max_retries: int = 3
    ) -> AsyncIterator[str]:
        """
        Generate Mermaid flowchart with validation and auto-retry using online API
        
        Args:
            user_input: Process description
            validate: Whether to validate the generated code
            max_retries: Maximum number of retries if validation fails
        """
        from core.mermaid_validator import mermaid_validator
        
        logger.info(f"Generating flowchart (validate={validate}, max_retries={max_retries})...")
        
        for attempt in range(max_retries):
            full_response = ""
            
            messages = [
                Message(role="system", content=task_prompts.get_flowchart_prompt()),
                Message(role="user", content=user_input)
            ]
            
            # Add retry context if this is a retry
            if attempt > 0:
                prev_errors = full_response  # Store previous errors
                messages.append(Message(
                    role="system", 
                    content=f"""Previous attempt failed validation.
Common syntax errors to avoid:
- Unmatched brackets: (), [], {{}}
- Invalid arrow syntax: use --> for arrows
- Empty node definitions: nodes need text like [text] or (text)
- Missing direction in flowchart: use flowchart TD or flowchart LR
- Invalid characters in node IDs

Please fix these issues and try again."""
                ))
            
            async for chunk in self.llm_client.generate_stream(messages):
                full_response += chunk
                yield chunk
            
            # Extract mermaid code
            mermaid_match = re.search(r'```mermaid\n(.*?)```', full_response, re.DOTALL)
            if not mermaid_match:
                logger.warning(f"Attempt {attempt + 1}: No mermaid code block found")
                if attempt == max_retries - 1:
                    yield "\n\n[Warning: Could not extract valid Mermaid code]"
                    return
                continue
            
            code = mermaid_match.group(1).strip()
            
            # Validate if requested
            if validate:
                logger.info(f"Validating mermaid code (attempt {attempt + 1})...")
                is_valid, error_msg = await mermaid_validator.validate_async(code)
                
                if is_valid:
                    logger.info(f"Flowchart generated and validated successfully on attempt {attempt + 1}")
                    return
                else:
                    logger.warning(f"Attempt {attempt + 1} failed validation: {error_msg}")
                    
                    if attempt < max_retries - 1:
                        # Get fix suggestions
                        suggestions = mermaid_validator.get_quick_fix_suggestions(error_msg, code)
                        
                        # Add validation error to context for next attempt
                        user_input = f"""{user_input}

VALIDATION ERROR (Attempt {attempt + 1}/{max_retries}):
{error_msg}

SUGGESTIONS:
{suggestions}

PREVIOUS CODE:
```mermaid
{code}
```

Please fix the syntax errors and regenerate. Make sure to test the syntax mentally before outputting."""
                        yield f"\n\n[Validation failed, retrying... ({attempt + 1}/{max_retries})]\n\n"
                    else:
                        yield f"\n\n[Warning: Validation failed after {max_retries} attempts: {error_msg}]"
            else:
                return
        
        logger.error(f"Failed to generate valid flowchart after {max_retries} attempts")
    
    async def fix_mermaid(
        self, 
        error_message: str, 
        mermaid_code: str,
        validate: bool = True,
        max_retries: int = 2
    ) -> AsyncIterator[str]:
        """
        Fix Mermaid syntax errors with validation using online API
        
        Args:
            error_message: The error message from Mermaid renderer
            mermaid_code: The original Mermaid code
            validate: Whether to validate the fixed code
            max_retries: Maximum number of fix attempts
        """
        from core.mermaid_validator import mermaid_validator
        
        logger.info(f"Fixing Mermaid code (validate={validate}, max_retries={max_retries})...")
        
        for attempt in range(max_retries):
            full_response = ""
            
            # Get fix suggestions
            suggestions = mermaid_validator.get_quick_fix_suggestions(error_message, mermaid_code)
            
            prompt = f"""Error: {error_message}

Original Code:
```mermaid
{mermaid_code}
```

Fix Suggestions:
{suggestions}"""
            
            if attempt > 0:
                prompt += f"""

Previous fix attempt {attempt} failed with new errors.
Please try a completely different approach - perhaps simplify the diagram or use a different diagram type."""
            
            messages = [
                Message(role="system", content=task_prompts.get_fix_mermaid_prompt()),
                Message(role="user", content=prompt)
            ]
            
            async for chunk in self.llm_client.generate_stream(messages):
                full_response += chunk
                yield chunk
            
            # Extract fixed code
            mermaid_match = re.search(r'```mermaid\n(.*?)```', full_response, re.DOTALL)
            if mermaid_match:
                code = mermaid_match.group(1).strip()
            else:
                # Assume the entire response is the fixed code
                code = full_response.strip()
            
            # Validate if requested
            if validate:
                logger.info(f"Validating fixed code (attempt {attempt + 1})...")
                is_valid, new_error = await mermaid_validator.validate_async(code)
                
                if is_valid:
                    logger.info(f"Mermaid code fixed successfully on attempt {attempt + 1}")
                    return
                else:
                    logger.warning(f"Fix attempt {attempt + 1} still has errors: {new_error}")
                    error_message = new_error
                    mermaid_code = code
                    
                    if attempt < max_retries - 1:
                        yield f"\n\n[Fix validation failed, trying different approach...]\n\n"
            else:
                return
        
        logger.error(f"Failed to fix Mermaid code after {max_retries} attempts")
    
    async def test_render_flowchart(self, mermaid_code: str) -> Tuple[bool, Optional[str], Optional[bytes]]:
        """
        Test render mermaid code to PNG
        
        Returns:
            (success, error_message, png_bytes)
        """
        from core.mermaid_validator import mermaid_validator
        return await mermaid_validator.test_render(mermaid_code)
    
    async def translate_document(
        self, 
        document_content: str, 
        target_lang: str = "English"
    ) -> AsyncIterator[str]:
        """
        Translate document to target language
        
        Args:
            document_content: The document to translate
            target_lang: Target language (English or Chinese)
        """
        messages = [
            Message(role="system", content=task_prompts.get_translate_prompt(target_lang)),
            Message(role="user", content=document_content)
        ]
        
        logger.info(f"Translating document to {target_lang}...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def edit_by_comment(
        self,
        selected_text: str,
        user_comment: str,
        doc_context: Optional[str] = None
    ) -> AsyncIterator[str]:
        """
        Edit document based on user comment on selected text
        
        Args:
            selected_text: The text selected by user
            user_comment: User's modification request
            doc_context: Optional surrounding context
        """
        prompt = f"""【Selected Text】
{selected_text}

【User Comment/Instruction】
{user_comment}"""
        
        if doc_context:
            prompt += f"""

【Surrounding Context for Reference】
{doc_context}"""
        
        messages = [
            Message(role="system", content=task_prompts.get_comment_edit_prompt()),
            Message(role="user", content=prompt)
        ]
        
        logger.info("Editing by comment...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def polish_text(
        self,
        selected_text: str,
        user_instruction: str,
        before_context: str = "",
        after_context: str = "",
        full_document: Optional[str] = None
    ) -> AsyncIterator[str]:
        """
        Polish/rewrite selected text while keeping surrounding context unchanged
        
        Args:
            selected_text: The text selected by user for polishing
            user_instruction: User's polishing requirements (e.g., "make it more formal", "simplify")
            before_context: Text before the selection (for context)
            after_context: Text after the selection (for context)
            full_document: Optional full document content for broader context
        """
        # Build context-aware prompt
        prompt_parts = []
        
        prompt_parts.append("【TEXT TO POLISH/REWRITE】")
        prompt_parts.append(selected_text)
        prompt_parts.append("")
        prompt_parts.append("【USER REQUIREMENT】")
        prompt_parts.append(user_instruction)
        
        if before_context or after_context:
            prompt_parts.append("")
            prompt_parts.append("【SURROUNDING CONTEXT】")
            if before_context:
                prompt_parts.append("Before selection:")
                prompt_parts.append(before_context[-500:] if len(before_context) > 500 else before_context)
            if after_context:
                prompt_parts.append("")
                prompt_parts.append("After selection:")
                prompt_parts.append(after_context[:500] if len(after_context) > 500 else after_context)
        
        if full_document:
            prompt_parts.append("")
            prompt_parts.append("【FULL DOCUMENT CONTEXT (for reference)】")
            # Include document summary or first part
            doc_preview = full_document[:1000] if len(full_document) > 1000 else full_document
            prompt_parts.append(doc_preview)
        
        prompt = "\n".join(prompt_parts)
        
        system_prompt = """You are an expert editor and writing assistant. Your task is to polish or rewrite the selected text according to the user's requirements.

IMPORTANT RULES:
1. ONLY modify the 【TEXT TO POLISH/REWRITE】 section
2. Keep the tone, style, and terminology consistent with the surrounding context
3. Maintain the original meaning while improving clarity, flow, and style
4. Do NOT add explanations or comments - output ONLY the polished text
5. Do NOT change the fundamental meaning or technical accuracy
6. Match the document's overall style and tone
7. If the text is technical, preserve all technical details and specifications

Your output should be the polished version of the selected text, ready to replace the original."""
        
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=prompt)
        ]
        
        logger.info(f"Polishing text: {user_instruction[:50]}...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def edit_ui(
        self,
        original_html: str,
        user_instruction: str
    ) -> AsyncIterator[str]:
        """
        Edit UI based on user feedback
        
        Args:
            original_html: Original HTML code
            user_instruction: User's modification request
        """
        prompt = f"""Original HTML:
{original_html}

User Feedback:
{user_instruction}"""
        
        messages = [
            Message(role="system", content=task_prompts.get_ui_edit_prompt()),
            Message(role="user", content=prompt)
        ]
        
        logger.info("Editing UI...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def general_chat(self, user_input: str) -> AsyncIterator[str]:
        """
        General chat for PROCESS type conversations
        
        Args:
            user_input: User message
        """
        messages = [
            Message(role="system", content=task_prompts.get_general_prompt()),
            Message(role="user", content=user_input)
        ]
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def collect_info(self, user_input: str) -> AsyncIterator[str]:
        """
        Information collection mode
        
        Args:
            user_input: User message
        """
        messages = [
            Message(role="system", content=task_prompts.get_collect_prompt()),
            Message(role="user", content=user_input)
        ]
        
        logger.info("Collecting information...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def generate_title(self, user_input: str) -> str:
        """
        Generate session title from user input
        
        Args:
            user_input: First user message
            
        Returns:
            Generated title
        """
        messages = [
            Message(role="system", content=task_prompts.get_gen_title_prompt()),
            Message(role="user", content=user_input)
        ]
        
        try:
            response = await self.llm_client.generate(messages)
            # Clean up the response
            title = response.strip().strip('"').strip("'")
            if len(title) > 20:
                title = title[:20]
            logger.info(f"Generated title: {title}")
            return title
        except Exception as e:
            logger.error(f"Title generation error: {e}")
            return "New Session"
    
    async def search_answer(
        self,
        user_question: str,
        search_results: List[Dict[str, Any]]
    ) -> AsyncIterator[str]:
        """
        Answer user question based on search results
        
        Args:
            user_question: User's question
            search_results: Results from knowledge base search
        """
        # Format search results
        formatted_results = "\n\n---\n\n".join([
            f"[{i+1}] Title: {r.get('title', 'Untitled')}\nScore: {r.get('score', 'N/A')}\nContent: {r.get('content', '')}"
            for i, r in enumerate(search_results)
        ])
        
        prompt = task_prompts.get_searching_answer_prompt()
        prompt = prompt.replace("{{SEARCH_RESULTS}}", formatted_results or "No relevant results found.")
        prompt = prompt.replace("{{USER_QUESTION}}", user_question)
        
        messages = [
            Message(role="system", content=prompt),
            Message(role="user", content=user_question)
        ]
        
        logger.info(f"Answering search query: {user_question[:50]}...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def execute_task(self, request: TaskRequest) -> AsyncIterator[str]:
        """
        Execute a task based on request
        
        Args:
            request: TaskRequest with task details
            
        Yields:
            Response chunks
        """
        task_type = request.task_type
        user_input = request.user_input
        context = request.context or {}
        
        logger.info(f"Executing task: {task_type}")
        
        if task_type == TaskType.CLASSIFY:
            result = await self.classify_intent(user_input)
            yield json.dumps({"classification": result.classification})
            
        elif task_type == TaskType.UI_GEN_UI:
            images = request.images
            async for chunk in self.generate_ui(user_input, images, is_screenshot=False):
                yield chunk
                
        elif task_type == TaskType.SCREENSHOT_UI:
            images = request.images
            async for chunk in self.generate_ui(user_input, images, is_screenshot=True):
                yield chunk
                
        elif task_type == TaskType.FLOWCHART:
            async for chunk in self.generate_flowchart(user_input):
                yield chunk
                
        elif task_type == TaskType.FIX_MERMAID:
            error_msg = context.get("error_message", "")
            mermaid_code = context.get("mermaid_code", "")
            async for chunk in self.fix_mermaid(error_msg, mermaid_code):
                yield chunk
                
        elif task_type == TaskType.TRANSLATE:
            target_lang = context.get("target_lang", "English")
            async for chunk in self.translate_document(user_input, target_lang):
                yield chunk
                
        elif task_type == TaskType.COMMENT_EDIT:
            selected_text = context.get("selected_text", "")
            user_comment = context.get("user_comment", "")
            doc_context = context.get("doc_context")
            async for chunk in self.edit_by_comment(selected_text, user_comment, doc_context):
                yield chunk
                
        elif task_type == TaskType.UI_EDIT:
            original_html = context.get("original_html", "")
            user_instruction = context.get("user_instruction", "")
            async for chunk in self.edit_ui(original_html, user_instruction):
                yield chunk
        
        elif task_type == TaskType.POLISH_TEXT:
            selected_text = context.get("selected_text", "")
            user_instruction = user_input  # The instruction is in user_input
            before_context = context.get("before_context", "")
            after_context = context.get("after_context", "")
            full_document = context.get("full_document")
            async for chunk in self.polish_text(
                selected_text, 
                user_instruction, 
                before_context, 
                after_context, 
                full_document
            ):
                yield chunk
                
        elif task_type == TaskType.COLLECT:
            async for chunk in self.collect_info(user_input):
                yield chunk
                
        elif task_type == TaskType.GEN_TITLE:
            title = await self.generate_title(user_input)
            yield title
            
        elif task_type == TaskType.SEARCHING_ANSWER:
            search_results = context.get("search_results", [])
            async for chunk in self.search_answer(user_input, search_results):
                yield chunk
        
        elif task_type == TaskType.GENERAL:
            async for chunk in self.general_chat(user_input):
                yield chunk
                
        else:
            # Default to general chat for unknown types
            logger.warning(f"Unknown task type: {task_type}, defaulting to GENERAL")
            async for chunk in self.general_chat(user_input):
                yield chunk


# Global task manager instance
task_manager = TaskManager()
