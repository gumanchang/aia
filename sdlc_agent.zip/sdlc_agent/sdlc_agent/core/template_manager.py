"""
Template Manager - Handles document templates
"""
import os
import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from config import settings


@dataclass
class TemplateSection:
    """Represents a section in a template"""
    title: str
    level: int
    content: str
    placeholder_count: int
    can_have_flowchart: bool = False
    can_have_ui_design: bool = False
    subsections: List['TemplateSection'] = None
    
    def __post_init__(self):
        if self.subsections is None:
            self.subsections = []


@dataclass
class DocumentTemplate:
    """Represents a document template"""
    name: str
    doc_type: str
    file_path: str
    content: str
    sections: List[TemplateSection]
    placeholders: Dict[str, str]
    structure: Dict[str, Any]


class TemplateManager:
    """Manages document templates"""
    
    # Sections that typically need flowcharts
    FLOWCHART_SECTIONS = [
        "flow", "process", "workflow", "sequence", "state", 
        "algorithm", "logic", "main flow", "business process",
        "system overview", "architecture"
    ]
    
    # Sections that typically need UI designs
    UI_DESIGN_SECTIONS = [
        "user interface", "ui", "screen", "page", "layout",
        "mockup", "prototype", "wireframe", "dashboard", "form"
    ]
    
    def __init__(self, templates_dir: str = None):
        self.templates_dir = templates_dir or settings.TEMPLATES_DIR
        self.templates: Dict[str, DocumentTemplate] = {}
        self._load_templates()
    
    def _load_templates(self):
        """Load all templates from the templates directory"""
        if not os.path.exists(self.templates_dir):
            print(f"Templates directory not found: {self.templates_dir}")
            return
        
        for filename in os.listdir(self.templates_dir):
            if filename.endswith('.md'):
                file_path = os.path.join(self.templates_dir, filename)
                try:
                    template = self._parse_template(file_path, filename)
                    self.templates[template.doc_type] = template
                    print(f"Loaded template: {template.doc_type}")
                except Exception as e:
                    print(f"Error loading template {filename}: {e}")
    
    def _parse_template(self, file_path: str, filename: str) -> DocumentTemplate:
        """Parse a template file"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Determine document type from filename
        doc_type = self._extract_doc_type(filename)
        
        # Extract placeholders
        placeholders = self._extract_placeholders(content)
        
        # Parse sections
        sections = self._parse_sections(content)
        
        # Build structure
        structure = self._build_structure(sections)
        
        return DocumentTemplate(
            name=filename.replace('_template.md', '').upper(),
            doc_type=doc_type,
            file_path=file_path,
            content=content,
            sections=sections,
            placeholders=placeholders,
            structure=structure
        )
    
    def _extract_doc_type(self, filename: str) -> str:
        """Extract document type from filename"""
        mapping = {
            'brd': 'BRD',
            'fds': 'FDS', 
            'srs': 'SRS',
            'prd': 'PRD',
            'feature': 'FEATURE'
        }
        
        for key, value in mapping.items():
            if key in filename.lower():
                return value
        
        # Default: extract first part before underscore
        return filename.split('_')[0].upper()
    
    def _extract_placeholders(self, content: str) -> Dict[str, str]:
        """Extract all placeholders in the format {{placeholder}}"""
        pattern = r'\{\{(\w+)\}\}'
        matches = re.findall(pattern, content)
        return {match: f"{{{{{match}}}}}" for match in set(matches)}
    
    def _parse_sections(self, content: str) -> List[TemplateSection]:
        """Parse markdown content into sections"""
        lines = content.split('\n')
        sections = []
        current_section = None
        section_stack = []
        
        for line in lines:
            # Check for headers
            header_match = re.match(r'^(#{1,6})\s+(.+)$', line)
            
            if header_match:
                level = len(header_match.group(1))
                title = header_match.group(2).strip()
                
                # Determine if this section can have visual elements
                title_lower = title.lower()
                can_have_flowchart = any(keyword in title_lower for keyword in self.FLOWCHART_SECTIONS)
                can_have_ui_design = any(keyword in title_lower for keyword in self.UI_DESIGN_SECTIONS)
                
                section = TemplateSection(
                    title=title,
                    level=level,
                    content="",
                    placeholder_count=0,
                    can_have_flowchart=can_have_flowchart,
                    can_have_ui_design=can_have_ui_design,
                    subsections=[]
                )
                
                # Build section hierarchy
                if not section_stack or level <= section_stack[-1].level:
                    # Pop sections until we find the parent or stack is empty
                    while section_stack and section_stack[-1].level >= level:
                        section_stack.pop()
                    
                    if section_stack:
                        section_stack[-1].subsections.append(section)
                    else:
                        sections.append(section)
                else:
                    # This is a subsection
                    if section_stack:
                        section_stack[-1].subsections.append(section)
                
                section_stack.append(section)
                current_section = section
            
            elif current_section is not None:
                current_section.content += line + '\n'
                # Count placeholders
                placeholders = re.findall(r'\{\{(\w+)\}\}', line)
                current_section.placeholder_count += len(placeholders)
        
        return sections
    
    def _build_structure(self, sections: List[TemplateSection]) -> Dict[str, Any]:
        """Build a hierarchical structure of the template"""
        def section_to_dict(section: TemplateSection) -> Dict[str, Any]:
            return {
                "title": section.title,
                "level": section.level,
                "can_have_flowchart": section.can_have_flowchart,
                "can_have_ui_design": section.can_have_ui_design,
                "placeholder_count": section.placeholder_count,
                "subsections": [section_to_dict(sub) for sub in section.subsections]
            }
        
        return {
            "sections": [section_to_dict(section) for section in sections]
        }
    
    def get_template(self, doc_type: str) -> Optional[DocumentTemplate]:
        """Get a template by document type"""
        return self.templates.get(doc_type.upper())
    
    def list_templates(self) -> List[Dict[str, str]]:
        """List all available templates"""
        return [
            {
                "doc_type": t.doc_type,
                "name": t.name,
                "description": settings.DOC_TYPES.get(t.doc_type, t.name)
            }
            for t in self.templates.values()
        ]
    
    def get_template_structure(self, doc_type: str) -> Optional[Dict[str, Any]]:
        """Get the structure of a template"""
        template = self.get_template(doc_type)
        return template.structure if template else None
    
    def get_sections_with_visuals(self, doc_type: str) -> List[Dict[str, Any]]:
        """Get sections that can have visual elements (flowcharts or UI designs)"""
        template = self.get_template(doc_type)
        if not template:
            return []
        
        visual_sections = []
        
        def collect_visual_sections(section: TemplateSection):
            if section.can_have_flowchart or section.can_have_ui_design:
                visual_sections.append({
                    "title": section.title,
                    "can_have_flowchart": section.can_have_flowchart,
                    "can_have_ui_design": section.can_have_ui_design,
                    "level": section.level
                })
            for sub in section.subsections:
                collect_visual_sections(sub)
        
        for section in template.sections:
            collect_visual_sections(section)
        
        return visual_sections
    
    def upload_template(self, file_content: str, filename: str) -> bool:
        """Upload a new template"""
        try:
            file_path = os.path.join(self.templates_dir, filename)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(file_content)
            
            # Reload templates
            template = self._parse_template(file_path, filename)
            self.templates[template.doc_type] = template
            return True
        except Exception as e:
            print(f"Error uploading template: {e}")
            return False


# Global template manager instance
template_manager = TemplateManager()
