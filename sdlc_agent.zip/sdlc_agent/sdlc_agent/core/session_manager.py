"""
Session Manager - Manages multi-turn conversations and history
"""
import os
import json
import uuid
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

from config import settings


class MessageType(Enum):
    """Types of messages in a session"""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    DOCUMENT = "document"  # Generated document
    MODIFICATION = "modification"


@dataclass
class SessionMessage:
    """A message in a session"""
    id: str
    type: MessageType
    content: str
    timestamp: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    attachments: List[str] = field(default_factory=list)


@dataclass
class Session:
    """A user session"""
    id: str
    title: str
    doc_type: str
    created_at: str
    updated_at: str
    messages: List[SessionMessage]
    current_document: Optional[str] = None
    document_version: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "doc_type": self.doc_type,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "messages": [
                {
                    "id": m.id,
                    "type": m.type.value,
                    "content": m.content,
                    "timestamp": m.timestamp,
                    "metadata": m.metadata,
                    "attachments": m.attachments
                }
                for m in self.messages
            ],
            "current_document": self.current_document,
            "document_version": self.document_version,
            "metadata": self.metadata
        }


class SessionManager:
    """Manages user sessions for multi-turn document generation"""
    
    def __init__(self, sessions_dir: str = None):
        self.sessions_dir = sessions_dir or os.path.join(settings.BASE_DIR, "sessions")
        os.makedirs(self.sessions_dir, exist_ok=True)
        
        # In-memory cache of active sessions
        self.active_sessions: Dict[str, Session] = {}
    
    def create_session(
        self,
        title: str,
        doc_type: str,
        initial_requirements: str = "",
        metadata: Dict[str, Any] = None
    ) -> Session:
        """Create a new session"""
        session_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        
        session = Session(
            id=session_id,
            title=title,
            doc_type=doc_type,
            created_at=now,
            updated_at=now,
            messages=[],
            metadata=metadata or {}
        )
        
        # Add initial user message if provided
        if initial_requirements:
            session.messages.append(SessionMessage(
                id=str(uuid.uuid4()),
                type=MessageType.USER,
                content=initial_requirements,
                timestamp=now,
                metadata={"is_initial": True}
            ))
        
        # Save session
        self._save_session(session)
        self.active_sessions[session_id] = session
        
        return session
    
    def get_session(self, session_id: str) -> Optional[Session]:
        """Get a session by ID"""
        # Check cache first
        if session_id in self.active_sessions:
            return self.active_sessions[session_id]
        
        # Load from disk
        session_file = os.path.join(self.sessions_dir, f"{session_id}.json")
        if not os.path.exists(session_file):
            return None
        
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            session = Session(
                id=data["id"],
                title=data["title"],
                doc_type=data["doc_type"],
                created_at=data["created_at"],
                updated_at=data["updated_at"],
                messages=[
                    SessionMessage(
                        id=m["id"],
                        type=MessageType(m["type"]),
                        content=m["content"],
                        timestamp=m["timestamp"],
                        metadata=m.get("metadata", {}),
                        attachments=m.get("attachments", [])
                    )
                    for m in data["messages"]
                ],
                current_document=data.get("current_document"),
                document_version=data.get("document_version", 1),
                metadata=data.get("metadata", {})
            )
            
            self.active_sessions[session_id] = session
            return session
        
        except Exception as e:
            print(f"Error loading session {session_id}: {e}")
            return None
    
    def add_message(
        self,
        session_id: str,
        message_type: MessageType,
        content: str,
        metadata: Dict[str, Any] = None,
        attachments: List[str] = None
    ) -> Optional[SessionMessage]:
        """Add a message to a session"""
        session = self.get_session(session_id)
        if not session:
            return None
        
        message = SessionMessage(
            id=str(uuid.uuid4()),
            type=message_type,
            content=content,
            timestamp=datetime.now().isoformat(),
            metadata=metadata or {},
            attachments=attachments or []
        )
        
        session.messages.append(message)
        session.updated_at = message.timestamp
        
        # If it's a document, update current document
        if message_type == MessageType.DOCUMENT:
            session.current_document = content
            session.document_version += 1
        
        self._save_session(session)
        
        return message
    
    def update_document(
        self,
        session_id: str,
        document_content: str,
        modification_request: str = ""
    ) -> bool:
        """Update the current document in a session"""
        session = self.get_session(session_id)
        if not session:
            return False
        
        # Add modification request as user message
        if modification_request:
            session.messages.append(SessionMessage(
                id=str(uuid.uuid4()),
                type=MessageType.USER,
                content=modification_request,
                timestamp=datetime.now().isoformat(),
                metadata={"is_modification": True}
            ))
        
        # Add document as assistant message
        session.messages.append(SessionMessage(
            id=str(uuid.uuid4()),
            type=MessageType.DOCUMENT,
            content=document_content,
            timestamp=datetime.now().isoformat(),
            metadata={
                "version": session.document_version + 1,
                "is_update": True
            }
        ))
        
        session.current_document = document_content
        session.document_version += 1
        session.updated_at = datetime.now().isoformat()
        
        self._save_session(session)
        return True
    
    def get_conversation_history(
        self,
        session_id: str,
        include_documents: bool = True,
        max_messages: int = None
    ) -> List[Dict[str, Any]]:
        """Get conversation history for a session"""
        session = self.get_session(session_id)
        if not session:
            return []
        
        history = []
        for msg in session.messages:
            # Skip document messages if not included
            if msg.type == MessageType.DOCUMENT and not include_documents:
                continue
            
            history.append({
                "id": msg.id,
                "role": "user" if msg.type in [MessageType.USER, MessageType.MODIFICATION] else "assistant",
                "content": msg.content,
                "timestamp": msg.timestamp,
                "type": msg.type.value,
                "metadata": msg.metadata
            })
        
        if max_messages:
            history = history[-max_messages:]
        
        return history
    
    def get_context_for_generation(
        self,
        session_id: str,
        include_full_history: bool = True
    ) -> Dict[str, Any]:
        """
        Get context for document generation/modification
        
        Returns:
            Dict with previous_document, history, and doc_type
        """
        session = self.get_session(session_id)
        if not session:
            return {
                "previous_document": None,
                "history": [],
                "doc_type": None
            }
        
        context = {
            "doc_type": session.doc_type,
            "previous_document": session.current_document,
            "document_version": session.document_version,
            "history": []
        }
        
        if include_full_history:
            # Get all messages except the current document
            for msg in session.messages:
                if msg.type == MessageType.DOCUMENT:
                    # Only include the most recent document content
                    continue
                
                context["history"].append({
                    "role": "user" if msg.type in [MessageType.USER, MessageType.MODIFICATION] else "assistant",
                    "content": msg.content,
                    "timestamp": msg.timestamp
                })
        
        return context
    
    def list_sessions(
        self,
        doc_type: str = None,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """List all sessions"""
        sessions = []
        
        for filename in os.listdir(self.sessions_dir):
            if filename.endswith('.json'):
                session_id = filename[:-5]
                session = self.get_session(session_id)
                
                if session:
                    if doc_type and session.doc_type != doc_type:
                        continue
                    
                    sessions.append({
                        "id": session.id,
                        "title": session.title,
                        "doc_type": session.doc_type,
                        "created_at": session.created_at,
                        "updated_at": session.updated_at,
                        "message_count": len(session.messages),
                        "document_version": session.document_version
                    })
        
        # Sort by updated_at desc
        sessions.sort(key=lambda x: x["updated_at"], reverse=True)
        
        return sessions[:limit]
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        session_file = os.path.join(self.sessions_dir, f"{session_id}.json")
        
        if os.path.exists(session_file):
            os.remove(session_file)
        
        if session_id in self.active_sessions:
            del self.active_sessions[session_id]
        
        return True
    
    def rename_session(self, session_id: str, new_title: str) -> bool:
        """Rename a session"""
        session = self.get_session(session_id)
        if not session:
            return False
        
        session.title = new_title
        session.updated_at = datetime.now().isoformat()
        self._save_session(session)
        
        return True
    
    def _save_session(self, session: Session):
        """Save session to disk"""
        session_file = os.path.join(self.sessions_dir, f"{session.id}.json")
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session.to_dict(), f, indent=2, ensure_ascii=False)


# Global session manager instance
session_manager = SessionManager()
