"""
LLM Client - Handles multimodal LLM interactions with streaming using OpenAI client
"""
import os
from typing import AsyncIterator, Dict, List, Optional, Any, Callable
from dataclasses import dataclass
import httpx
from openai import AsyncOpenAI
from config import settings


@dataclass
class Message:
    """A message in the conversation"""
    role: str  # system, user, assistant
    content: str
    images: Optional[List[Dict[str, Any]]] = None
    attachments: Optional[List[Dict[str, Any]]] = None


@dataclass
class LLMResponse:
    """Response from LLM"""
    content: str
    is_complete: bool = False
    usage: Optional[Dict[str, int]] = None


class LLMClient:
    """Client for multimodal LLM with streaming support using OpenAI client"""
    
    def __init__(self, api_key: str = None, api_url: str = None, model: str = None):
        self.api_key = api_key or settings.LLM_API_KEY
        self.api_url = api_url or settings.LLM_API_URL
        self.model = model or settings.LLM_MODEL
        self.temperature = settings.LLM_TEMPERATURE
        self.max_tokens = settings.LLM_MAX_TOKENS
        
        # Initialize OpenAI async client
        # Only set base_url if it's not the default OpenAI URL
        base_url = self.api_url if self.api_url and self.api_url != "https://api.openai.com/v1" else None
        
        # Create custom httpx client to avoid proxies issue
        http_client = httpx.AsyncClient(
            timeout=120.0,
            follow_redirects=True
        )
        
        self.client = AsyncOpenAI(
            api_key=self.api_key,
            base_url=base_url,
            http_client=http_client
        )
    
    async def generate_stream(
        self,
        messages: List[Message],
        callback: Optional[Callable[[str], None]] = None
    ) -> AsyncIterator[str]:
        """
        Generate streaming response from LLM
        
        Args:
            messages: List of messages for context
            callback: Optional callback function for each chunk
            
        Yields:
            String chunks of the response
        """
        formatted_messages = self._format_messages(messages)
        
        try:
            stream = await self.client.chat.completions.create(
                model=self.model,
                messages=formatted_messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=True
            )
            
            async for chunk in stream:
                delta = chunk.choices[0].delta
                if delta.content:
                    content = delta.content
                    if callback:
                        callback(content)
                    yield content
        
        except Exception as e:
            yield f"\n\n[Error: {str(e)}]"
    
    async def generate(
        self,
        messages: List[Message]
    ) -> str:
        """Generate non-streaming response"""
        formatted_messages = self._format_messages(messages)
        
        try:
            completion = await self.client.chat.completions.create(
                model=self.model,
                messages=formatted_messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=False
            )
            
            return completion.choices[0].message.content or ""
        
        except Exception as e:
            return f"[Error: {str(e)}]"
    
    def _format_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """Format messages for LLM API"""
        formatted = []
        
        for msg in messages:
            content_parts = []
            
            # Add text content
            if msg.content:
                content_parts.append({
                    "type": "text",
                    "text": msg.content
                })
            
            # Add images (multimodal)
            if msg.images:
                for img in msg.images:
                    content_parts.append(img)
            
            # Handle different content formats
            if len(content_parts) == 1 and content_parts[0]["type"] == "text":
                # Simple text message
                formatted.append({
                    "role": msg.role,
                    "content": content_parts[0]["text"]
                })
            else:
                # Multimodal message
                formatted.append({
                    "role": msg.role,
                    "content": content_parts
                })
        
        return formatted
    
    async def close(self):
        """Close the client"""
        await self.client.close()
        # Close the underlying httpx client
        if hasattr(self.client, '_client') and self.client._client:
            await self.client._client.aclose()


class DocumentGenerationPrompt:
    """Builds prompts for document generation"""
    
    @staticmethod
    def build_system_prompt(doc_type: str, template_content: str) -> str:
        """Build system prompt for document generation"""
        from datetime import datetime
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        return f"""You are an expert technical writer specializing in creating high-quality {doc_type} documents.

Your task is to generate a complete {doc_type} document based on the user's requirements, following the template structure provided.

TEMPLATE STRUCTURE:
{template_content}

CURRENT DATE: {current_date}

GUIDELINES:
1. Follow the template structure exactly - maintain all sections and hierarchy
2. Fill in all placeholder content with detailed, professional information
3. Replace {{date}} placeholder with the current date: {current_date}
4. Use clear, concise, and technical language appropriate for the document type
5. When generating visual elements:
   - For flowcharts: Use Mermaid syntax (flowchart TD, flowchart LR, etc.)
   - For UI designs: Use HTML syntax with inline CSS
   - Insert visual elements at appropriate sections where marked with comments
6. Maintain consistency in formatting and terminology throughout the document
7. Generate comprehensive content - do not leave sections empty or with placeholder text
8. Use markdown format for the final document

OUTPUT FORMAT:
Return the complete document in markdown format, ready for export."""

    @staticmethod
    def build_generation_prompt(
        user_requirements: str,
        doc_type: str,
        attachments_summary: str = "",
        previous_document: str = None
    ) -> str:
        """Build the user prompt for document generation"""
        prompt = f"""Generate a {doc_type} document based on the following requirements:

USER REQUIREMENTS:
{user_requirements}
"""
        
        if attachments_summary:
            prompt += f"""
ATTACHMENTS CONTENT:
{attachments_summary}
"""
        
        if previous_document:
            prompt += f"""
PREVIOUS DOCUMENT (to be modified):
{previous_document}

INSTRUCTION: Modify the above document according to the new requirements while maintaining the template structure.
"""
        
        prompt += """
Please generate the complete document now. Insert flowcharts (using Mermaid syntax) and UI designs (using HTML) where appropriate in relevant sections.
"""
        
        return prompt

    @staticmethod
    def build_modification_prompt(
        current_document: str,
        modification_request: str,
        doc_type: str
    ) -> str:
        """Build prompt for document modification"""
        return f"""You have previously generated the following {doc_type} document:

CURRENT DOCUMENT:
{current_document}

MODIFICATION REQUEST:
{modification_request}

Please provide the COMPLETE updated document with the requested modifications applied. Maintain the same structure and formatting, only apply the requested changes."""

    @staticmethod
    def build_flowchart_prompt(section_title: str, section_content: str) -> str:
        """Build prompt for generating a flowchart"""
        return f"""Generate a Mermaid flowchart for the following section:

Section: {section_title}
Content: {section_content}

Generate a flowchart that visualizes the process/flow described. Use appropriate Mermaid syntax (flowchart TD for top-down, flowchart LR for left-right).

Return ONLY the Mermaid code block, like:
```mermaid
flowchart TD
    A[Start] --> B[Process]
    B --> C[End]
```"""

    @staticmethod
    def build_ui_design_prompt(section_title: str, requirements: str) -> str:
        """Build prompt for generating UI design"""
        return f"""Generate an HTML UI design mockup for the following:

Section: {section_title}
Requirements: {requirements}

Generate a clean, professional HTML mockup with inline CSS. The design should be responsive and modern.

Return ONLY the HTML code block, like:
```html
<div style="...">
    <!-- UI elements -->
</div>
```"""


# Global LLM client instance
llm_client = LLMClient()
