"""
Document Generator - Main engine for generating documents with visuals
"""
import re
import json
import os
import io
import base64
import tempfile
from typing import AsyncIterator, Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime

from config import settings
from core.template_manager import template_manager, DocumentTemplate
from core.llm_client import llm_client, Message, DocumentGenerationPrompt
from core.file_processor import ProcessedFile

# Optional imports for Word export
try:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

# Check if Chrome/Edge is available for rendering
def _check_browser_available():
    """Check if Chrome or Edge browser is available for rendering"""
    import platform
    system = platform.system()
    
    possible_paths = []
    if system == 'Windows':
        # Windows paths
        possible_paths = [
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
            r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        ]
        # Also check registry
        try:
            import winreg
            for key_path in [
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'
            ]:
                try:
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path)
                    value, _ = winreg.QueryValueEx(key, None)
                    if value and os.path.exists(value):
                        print(f"[DocumentGenerator] Found browser via registry: {value}")
                        return True, value
                except:
                    pass
        except:
            pass
    elif system == 'Darwin':  # macOS
        possible_paths = [
            '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
            '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
        ]
    else:  # Linux
        possible_paths = [
            '/usr/bin/google-chrome',
            '/usr/bin/chromium-browser',
            '/usr/bin/chromium',
            '/usr/bin/microsoft-edge',
        ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"[DocumentGenerator] Found browser at: {path}")
            return True, path
    
    return False, None

BROWSER_AVAILABLE, BROWSER_PATH = _check_browser_available()

if BROWSER_AVAILABLE:
    print(f"[DocumentGenerator] Browser available for Word export: {BROWSER_PATH}")
else:
    print(f"[DocumentGenerator] WARNING: No Chrome/Edge browser found. Word export will show code instead of images.")

try:
    import markdown2
    MARKDOWN2_AVAILABLE = True
except ImportError:
    MARKDOWN2_AVAILABLE = False


@dataclass
class GeneratedSection:
    """A generated section of the document"""
    title: str
    level: int
    content: str
    has_flowchart: bool = False
    has_ui_design: bool = False
    flowchart_code: Optional[str] = None
    ui_design_code: Optional[str] = None


@dataclass
class GeneratedDocument:
    """A complete generated document"""
    doc_type: str
    title: str
    content: str
    sections: List[GeneratedSection]
    metadata: Dict[str, Any] = field(default_factory=dict)
    flowcharts: List[Dict[str, str]] = field(default_factory=list)
    ui_designs: List[Dict[str, str]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_type": self.doc_type,
            "title": self.title,
            "content": self.content,
            "sections": [
                {
                    "title": s.title,
                    "level": s.level,
                    "content": s.content,
                    "has_flowchart": s.has_flowchart,
                    "has_ui_design": s.has_ui_design,
                    "flowchart_code": s.flowchart_code,
                    "ui_design_code": s.ui_design_code
                }
                for s in self.sections
            ],
            "metadata": self.metadata,
            "flowcharts": self.flowcharts,
            "ui_designs": self.ui_designs
        }


class DocumentGenerator:
    """Generates documents with flowcharts and UI designs"""
    
    def __init__(self):
        self.template_manager = template_manager
        self.llm = llm_client
    
    async def generate_document(
        self,
        doc_type: str,
        user_requirements: str,
        attachments: List[ProcessedFile] = None,
        previous_document: str = None,
        custom_prompt: str = None
    ) -> AsyncIterator[str]:
        """
        Generate a document with streaming output
        
        Yields:
            Chunks of the generated document
        """
        # Get template
        template = self.template_manager.get_template(doc_type)
        if not template:
            yield f"Error: Template for {doc_type} not found"
            return
        
        # Build system prompt
        system_prompt = DocumentGenerationPrompt.build_system_prompt(
            doc_type, template.content
        )
        
        # Build attachments summary
        attachments_summary = self._build_attachments_summary(attachments or [])
        
        # Build user prompt
        if custom_prompt:
            user_prompt = custom_prompt
        else:
            user_prompt = DocumentGenerationPrompt.build_generation_prompt(
                user_requirements=user_requirements,
                doc_type=doc_type,
                attachments_summary=attachments_summary,
                previous_document=previous_document
            )
        
        # Prepare messages
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt)
        ]
        
        # Add images from attachments if any
        all_images = []
        for attachment in (attachments or []):
            if attachment.images:
                all_images.extend(attachment.images)
        
        if all_images:
            messages.append(Message(
                role="user",
                content="[Reference images from attachments]",
                images=all_images[:5]  # Limit to 5 images
            ))
        
        # Stream generate
        full_content = ""
        async for chunk in self.llm.generate_stream(messages):
            full_content += chunk
            yield chunk
        
        # Post-process the document
        processed_doc = self._post_process_document(full_content, doc_type)
        
        # Yield metadata at the end
        metadata = json.dumps({
            "type": "metadata",
            "doc_type": doc_type,
            "flowcharts": processed_doc.flowcharts,
            "ui_designs": processed_doc.ui_designs
        }, ensure_ascii=False)  # 关键：防止中文被转义
        yield f"\n\n<!--METADATA:{metadata}-->"
    
    async def modify_document(
        self,
        current_document: str,
        modification_request: str,
        doc_type: str
    ) -> AsyncIterator[str]:
        """
        Modify an existing document based on user request
        
        Yields:
            Chunks of the modified document
        """
        # Get template
        template = self.template_manager.get_template(doc_type)
        
        # Build prompts
        system_prompt = DocumentGenerationPrompt.build_system_prompt(
            doc_type, template.content if template else ""
        )
        
        user_prompt = DocumentGenerationPrompt.build_modification_prompt(
            current_document=current_document,
            modification_request=modification_request,
            doc_type=doc_type
        )
        
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt)
        ]
        
        # Stream generate
        full_content = ""
        async for chunk in self.llm.generate_stream(messages):
            full_content += chunk
            yield chunk
        
        # Post-process
        processed_doc = self._post_process_document(full_content, doc_type)
        
        metadata = json.dumps({
            "type": "metadata",
            "doc_type": doc_type,
            "flowcharts": processed_doc.flowcharts,
            "ui_designs": processed_doc.ui_designs
        })
        yield f"\n\n<!--METADATA:{metadata}-->"
    
    async def generate_flowchart(
        self,
        section_title: str,
        section_content: str
    ) -> str:
        """Generate a flowchart for a specific section"""
        prompt = DocumentGenerationPrompt.build_flowchart_prompt(
            section_title, section_content
        )
        
        messages = [
            Message(role="system", content="You are an expert in creating Mermaid diagrams."),
            Message(role="user", content=prompt)
        ]
        
        result = await self.llm.generate(messages)
        
        # Extract mermaid code block
        mermaid_match = re.search(r'```mermaid\n(.*?)```', result, re.DOTALL)
        if mermaid_match:
            return mermaid_match.group(1).strip()
        
        return result
    
    async def generate_ui_design(
        self,
        section_title: str,
        requirements: str
    ) -> str:
        """Generate a UI design for a specific section"""
        prompt = DocumentGenerationPrompt.build_ui_design_prompt(
            section_title, requirements
        )
        
        messages = [
            Message(role="system", content="You are an expert UI/UX designer."),
            Message(role="user", content=prompt)
        ]
        
        result = await self.llm.generate(messages)
        
        # Extract HTML code block
        html_match = re.search(r'```html\n(.*?)```', result, re.DOTALL)
        if html_match:
            return html_match.group(1).strip()
        
        return result
    
    def _build_attachments_summary(self, attachments: List[ProcessedFile]) -> str:
        """Build a summary of all attachments"""
        if not attachments:
            return ""
        
        summaries = []
        for att in attachments:
            summary = f"""
---
File: {att.filename}
Type: {att.file_type}
Content:
{att.content[:5000] if len(att.content) > 5000 else att.content}
"""
            summaries.append(summary)
        
        return "\n".join(summaries)
    
    def _post_process_document(
        self,
        content: str,
        doc_type: str
    ) -> GeneratedDocument:
        """Post-process the generated document"""
        # Extract mermaid diagrams
        flowcharts = self._extract_flowcharts(content)
        
        # Extract HTML designs
        ui_designs = self._extract_ui_designs(content)
        
        # Parse sections
        sections = self._parse_sections(content)
        
        # Extract title
        title = self._extract_title(content) or f"{doc_type} Document"
        
        return GeneratedDocument(
            doc_type=doc_type,
            title=title,
            content=content,
            sections=sections,
            metadata={
                "generated_at": datetime.now().isoformat(),
                "doc_type": doc_type,
                "title": title
            },
            flowcharts=flowcharts,
            ui_designs=ui_designs
        )
    
    def _extract_flowcharts(self, content: str) -> List[Dict[str, str]]:
        """Extract all mermaid flowcharts from content"""
        flowcharts = []
        pattern = r'```mermaid\n(.*?)```'
        matches = re.finditer(pattern, content, re.DOTALL)
        
        for i, match in enumerate(matches):
            code = match.group(1).strip()
            # Determine type
            chart_type = "flowchart"
            if "sequenceDiagram" in code:
                chart_type = "sequence"
            elif "classDiagram" in code:
                chart_type = "class"
            elif "erDiagram" in code:
                chart_type = "er"
            elif "gantt" in code:
                chart_type = "gantt"
            
            flowcharts.append({
                "id": f"flowchart_{i}",
                "type": chart_type,
                "code": code
            })
        
        return flowcharts
    
    def _extract_ui_designs(self, content: str) -> List[Dict[str, str]]:
        """Extract all HTML UI designs from content"""
        ui_designs = []
        pattern = r'```html\n(.*?)```'
        matches = re.finditer(pattern, content, re.DOTALL)
        
        for i, match in enumerate(matches):
            ui_designs.append({
                "id": f"ui_design_{i}",
                "code": match.group(1).strip()
            })
        
        return ui_designs
    
    def _parse_sections(self, content: str) -> List[GeneratedSection]:
        """Parse content into sections"""
        sections = []
        lines = content.split('\n')
        current_section = None
        section_content = []
        
        for line in lines:
            header_match = re.match(r'^(#{1,6})\s+(.+)$', line)
            
            if header_match:
                # Save previous section
                if current_section:
                    current_section.content = '\n'.join(section_content)
                    sections.append(current_section)
                
                # Start new section
                level = len(header_match.group(1))
                title = header_match.group(2).strip()
                
                # Check if this section has visual elements
                section_text = '\n'.join(section_content).lower()
                has_flowchart = '```mermaid' in section_text
                has_ui_design = '```html' in section_text
                
                current_section = GeneratedSection(
                    title=title,
                    level=level,
                    content="",
                    has_flowchart=has_flowchart,
                    has_ui_design=has_ui_design
                )
                section_content = [line]
            
            elif current_section is not None:
                section_content.append(line)
        
        # Don't forget the last section
        if current_section:
            current_section.content = '\n'.join(section_content)
            sections.append(current_section)
        
        return sections
    
    def _extract_title(self, content: str) -> Optional[str]:
        """Extract document title from content"""
        # Try to find H1
        h1_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
        if h1_match:
            return h1_match.group(1).strip()
        
        # Try to find title in metadata
        title_match = re.search(r'[Tt]itle:\s*(.+)$', content, re.MULTILINE)
        if title_match:
            return title_match.group(1).strip()
        
        return None
    
    def export_document(
        self,
        document: GeneratedDocument,
        format: str = "markdown"
    ) -> str:
        """Export document to different formats"""
        if format == "markdown":
            return document.content
        
        elif format == "html":
            return self._convert_to_html(document)
        
        elif format == "json":
            return json.dumps(document.to_dict(), indent=2)
        
        return document.content
    
    def _convert_to_html(self, document: GeneratedDocument) -> str:
        """Convert document to HTML format"""
        # Simple markdown to HTML conversion
        content = document.content
        
        # Convert headers
        for i in range(6, 0, -1):
            pattern = f'^{"#" * i}\\s+(.+)$'
            replacement = f'<h{i}>\\1</h{i}>'
            content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
        
        # Convert mermaid blocks
        content = re.sub(
            r'```mermaid\n(.*?)```',
            r'<div class="mermaid">\1</div>',
            content,
            flags=re.DOTALL
        )
        
        # Convert HTML blocks
        content = re.sub(
            r'```html\n(.*?)```',
            r'\1',
            content,
            flags=re.DOTALL
        )
        
        # Wrap in HTML template
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>{document.title}</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #333; border-bottom: 2px solid #007acc; }}
        h2 {{ color: #444; border-bottom: 1px solid #ddd; }}
        .mermaid {{ background: #f5f5f5; padding: 20px; border-radius: 8px; }}
    </style>
</head>
<body>
    {content}
    <script>mermaid.initialize({{startOnLoad: true}});</script>
</body>
</html>"""
        
        return html

    def export_to_word(
        self,
        document: GeneratedDocument,
        output_path: Optional[str] = None
    ) -> str:
        """
        Export document to Word format with rendered flowcharts and UI
        
        Args:
            document: The document to export
            output_path: Optional output file path
            
        Returns:
            Path to the generated Word file
        """
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx is required for Word export. Install: pip install python-docx")
        
        # Check browser availability for rendering
        if not BROWSER_AVAILABLE:
            print("[Word Export] WARNING: Chrome/Edge browser not found. Flowcharts and UI will be shown as code.")
            print("[Word Export] Please install Chrome or Edge browser for image rendering.")
        else:
            print(f"[Word Export] Using browser: {BROWSER_PATH}")
        
        print(f"[Word Export] Starting export for document: {document.title}")
        
        # Create Word document
        doc = Document()
        
        # Add title
        title = doc.add_heading(document.title, 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Process content
        content = document.content
        
        # Extract and count visual elements
        mermaid_blocks = re.findall(r'```mermaid\n(.*?)```', content, re.DOTALL)
        html_blocks = re.findall(r'```html\n(.*?)```', content, re.DOTALL)
        print(f"[Word Export] Found {len(mermaid_blocks)} mermaid blocks and {len(html_blocks)} HTML blocks")
        
        # Split content by code blocks
        parts = self._split_content_by_blocks(content)
        print(f"[Word Export] Processing {len(parts)} content parts")
        
        rendered_count = 0
        fallback_count = 0
        
        for i, part in enumerate(parts):
            block_type = part.get('type')
            block_content = part.get('content', '')
            
            if block_type == 'mermaid':
                print(f"[Word Export] Part {i+1}: Rendering mermaid flowchart...")
                # Render mermaid to image and add to document
                image_path = self._render_mermaid_to_image(block_content)
                if image_path and os.path.exists(image_path):
                    try:
                        doc.add_picture(image_path, width=Inches(6))
                        # Clean up temp file
                        os.unlink(image_path)
                        rendered_count += 1
                        print(f"[Word Export] Part {i+1}: Flowchart rendered successfully")
                    except Exception as e:
                        # If image insertion fails, add as code block
                        print(f"[Word Export] Part {i+1}: Failed to insert image: {e}")
                        doc.add_paragraph(f"[Flowchart rendering failed]")
                        fallback_count += 1
                else:
                    # Fallback: add as text
                    print(f"[Word Export] Part {i+1}: Could not render flowchart, adding as text")
                    p = doc.add_paragraph()
                    p.add_run("Flowchart (rendering failed - install Chrome/Edge for image export):").bold = True
                    doc.add_paragraph(block_content, style='Quote')
                    fallback_count += 1
                    
            elif block_type == 'html':
                print(f"[Word Export] Part {i+1}: Rendering HTML UI...")
                # Render HTML to image and add to document
                image_path = self._render_html_to_image(block_content)
                if image_path and os.path.exists(image_path):
                    try:
                        doc.add_picture(image_path, width=Inches(6))
                        # Clean up temp file
                        os.unlink(image_path)
                        rendered_count += 1
                        print(f"[Word Export] Part {i+1}: UI rendered successfully")
                    except Exception as e:
                        # If image insertion fails, add as code block
                        print(f"[Word Export] Part {i+1}: Failed to insert image: {e}")
                        doc.add_paragraph(f"[UI Design rendering failed]")
                        fallback_count += 1
                else:
                    # Fallback: add as text
                    print(f"[Word Export] Part {i+1}: Could not render UI, adding as text")
                    p = doc.add_paragraph()
                    p.add_run("UI Design (rendering failed - install Chrome/Edge for image export):").bold = True
                    doc.add_paragraph(block_content[:500] + "...", style='Quote')
                    fallback_count += 1
                    
            elif block_type == 'heading':
                # Add heading
                level = part.get('level', 1)
                if level <= 6:
                    doc.add_heading(block_content, level=level)
                else:
                    doc.add_heading(block_content, level=6)
                    
            elif block_type == 'paragraph':
                # Add paragraph
                if block_content.strip():
                    # Convert markdown to plain text for Word
                    plain_text = self._markdown_to_plain_text(block_content)
                    if plain_text.strip():
                        doc.add_paragraph(plain_text)
        
        print(f"[Word Export] Export complete: {rendered_count} images rendered, {fallback_count} fallbacks")
        
        # Save document
        if output_path is None:
            output_path = os.path.join(tempfile.gettempdir(), f"{document.doc_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx")
        
        doc.save(output_path)
        print(f"[Word Export] Document saved to: {output_path}")
        return output_path
    
    def _split_content_by_blocks(self, content: str) -> List[Dict[str, Any]]:
        """Split content by code blocks and other elements"""
        parts = []
        
        # Pattern to match mermaid and html code blocks
        pattern = r'(```mermaid\n(.*?)```|```html\n(.*?)```|^(#{1,6})\s+(.+)$)'
        
        last_end = 0
        for match in re.finditer(pattern, content, re.MULTILINE | re.DOTALL):
            # Add text before this block
            if match.start() > last_end:
                text = content[last_end:match.start()].strip()
                if text:
                    parts.append({'type': 'paragraph', 'content': text})
            
            if match.group(2):  # Mermaid block
                parts.append({'type': 'mermaid', 'content': match.group(2).strip()})
            elif match.group(3):  # HTML block
                parts.append({'type': 'html', 'content': match.group(3).strip()})
            elif match.group(4):  # Heading
                level = len(match.group(4))
                parts.append({'type': 'heading', 'level': level, 'content': match.group(5).strip()})
            
            last_end = match.end()
        
        # Add remaining text
        if last_end < len(content):
            text = content[last_end:].strip()
            if text:
                parts.append({'type': 'paragraph', 'content': text})
        
        return parts
    
    def _markdown_to_plain_text(self, markdown_text: str) -> str:
        """Convert markdown to plain text"""
        # Remove bold and italic markers
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', markdown_text)
        text = re.sub(r'\*(.*?)\*', r'\1', markdown_text)
        text = re.sub(r'__(.*?)__', r'\1', markdown_text)
        text = re.sub(r'_(.*?)_', r'\1', markdown_text)
        
        # Remove code inline markers
        text = re.sub(r'`(.*?)`', r'\1', text)
        
        # Remove links, keep text
        text = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', text)
        
        # Remove images
        text = re.sub(r'!\[.*?\]\(.*?\)', '', text)
        
        return text.strip()
    
    def _render_mermaid_to_image(self, mermaid_code: str) -> Optional[str]:
        """
        Render mermaid code to image using Chrome headless
        
        Returns:
            Path to the generated image file
        """
        if not BROWSER_AVAILABLE:
            print("[Word Export] Chrome/Edge browser not available for rendering")
            return None
        
        try:
            import subprocess
            import time
            
            # Create HTML with mermaid
            html_content = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    <style>
        body {{ 
            margin: 0; 
            padding: 20px; 
            background: white;
            font-family: Arial, sans-serif;
            min-height: 400px;
        }}
        .mermaid {{ 
            display: flex;
            justify-content: center;
            align-items: center;
        }}
    </style>
</head>
<body>
    <div class="mermaid">
{mermaid_code}
    </div>
    <script>
        mermaid.initialize({{ 
            startOnLoad: true,
            theme: 'default',
            securityLevel: 'loose'
        }});
    </script>
</body>
</html>'''
            
            # Create temporary directory for output
            temp_dir = tempfile.mkdtemp()
            output_file = os.path.join(temp_dir, 'mermaid.png')
            html_file = os.path.join(temp_dir, 'mermaid.html')
            
            # Save HTML to temp file
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            print(f"[Word Export] Rendering mermaid with Chrome headless...")
            print(f"[Word Export] Browser: {BROWSER_PATH}")
            
            # Call Chrome in headless mode to take screenshot
            cmd = [
                BROWSER_PATH,
                '--headless',
                '--disable-gpu',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                f'--screenshot={output_file}',
                '--window-size=1400,1000',
                '--hide-scrollbars',
                '--virtual-time-budget=10000',  # Wait up to 10 seconds for mermaid to render
                html_file
            ]
            
            print(f"[Word Export] Running: {' '.join(cmd[:3])} ...")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode != 0:
                print(f"[Word Export] Chrome error: {result.stderr}")
                return None
            
            # Wait for file to be written
            time.sleep(0.5)
            
            # Check if file exists and has content
            if os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                if file_size > 0:
                    print(f"[Word Export] Mermaid rendered successfully: {output_file} ({file_size} bytes)")
                    return output_file
                else:
                    print(f"[Word Export] Mermaid render failed: output file is empty")
                    return None
            else:
                print(f"[Word Export] Mermaid render failed: output file not found")
                return None
            
        except subprocess.TimeoutExpired:
            print("[Word Export] Mermaid render timeout")
            return None
        except Exception as e:
            print(f"[Word Export] Error rendering mermaid: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _render_html_to_image(self, html_code: str) -> Optional[str]:
        """
        Render HTML UI code to image using Chrome headless
        
        Returns:
            Path to the generated image file
        """
        if not BROWSER_AVAILABLE:
            print("[Word Export] Chrome/Edge browser not available for rendering")
            return None
        
        try:
            import subprocess
            import time
            
            # Wrap HTML in proper document
            if '<html' not in html_code.lower():
                html_content = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {{ 
            margin: 0; 
            padding: 20px; 
            background: white;
            min-height: 400px;
        }}
    </style>
</head>
<body>
{html_code}
</body>
</html>'''
            else:
                html_content = html_code
            
            # Create temporary directory for output
            temp_dir = tempfile.mkdtemp()
            output_file = os.path.join(temp_dir, 'ui_design.png')
            html_file = os.path.join(temp_dir, 'ui.html')
            
            # Save HTML to temp file
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            print(f"[Word Export] Rendering HTML with Chrome headless...")
            print(f"[Word Export] Browser: {BROWSER_PATH}")
            
            # Call Chrome in headless mode to take screenshot
            cmd = [
                BROWSER_PATH,
                '--headless',
                '--disable-gpu',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                f'--screenshot={output_file}',
                '--window-size=1400,1000',
                '--hide-scrollbars',
                '--virtual-time-budget=10000',
                html_file
            ]
            
            print(f"[Word Export] Running: {' '.join(cmd[:3])} ...")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode != 0:
                print(f"[Word Export] Chrome error: {result.stderr}")
                return None
            
            # Wait for file to be written
            time.sleep(0.5)
            
            # Check if file exists and has content
            if os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                if file_size > 0:
                    print(f"[Word Export] HTML rendered successfully: {output_file} ({file_size} bytes)")
                    return output_file
                else:
                    print(f"[Word Export] HTML render failed: output file is empty")
                    return None
            else:
                print(f"[Word Export] HTML render failed: output file not found")
                return None
            
        except subprocess.TimeoutExpired:
            print("[Word Export] HTML render timeout")
            return None
        except Exception as e:
            print(f"[Word Export] Error rendering HTML: {e}")
            import traceback
            traceback.print_exc()
            return None


# Global document generator instance
document_generator = DocumentGenerator()
