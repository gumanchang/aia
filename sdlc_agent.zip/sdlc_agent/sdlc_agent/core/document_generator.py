"""
Document Generator - Main engine for generating documents with visuals
"""
import re
import json
from typing import AsyncIterator, Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime

from config import settings
from core.template_manager import template_manager, DocumentTemplate
from core.llm_client import llm_client, Message, DocumentGenerationPrompt
from core.file_processor import ProcessedFile


@dataclass
class GeneratedSection:
    """A generated section of the document"""
    title: str
    level: int
    content: str
    has_flowchart: bool = False
    has_ui_design: bool = False
    flowchart_code: Optional[str] = None
    ui_design_code: Optional[str] = None


@dataclass
class GeneratedDocument:
    """A complete generated document"""
    doc_type: str
    title: str
    content: str
    sections: List[GeneratedSection]
    metadata: Dict[str, Any] = field(default_factory=dict)
    flowcharts: List[Dict[str, str]] = field(default_factory=list)
    ui_designs: List[Dict[str, str]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_type": self.doc_type,
            "title": self.title,
            "content": self.content,
            "sections": [
                {
                    "title": s.title,
                    "level": s.level,
                    "content": s.content,
                    "has_flowchart": s.has_flowchart,
                    "has_ui_design": s.has_ui_design,
                    "flowchart_code": s.flowchart_code,
                    "ui_design_code": s.ui_design_code
                }
                for s in self.sections
            ],
            "metadata": self.metadata,
            "flowcharts": self.flowcharts,
            "ui_designs": self.ui_designs
        }


class DocumentGenerator:
    """Generates documents with flowcharts and UI designs"""
    
    def __init__(self):
        self.template_manager = template_manager
        self.llm = llm_client
    
    async def generate_document(
        self,
        doc_type: str,
        user_requirements: str,
        attachments: List[ProcessedFile] = None,
        previous_document: str = None,
        custom_prompt: str = None
    ) -> AsyncIterator[str]:
        """
        Generate a document with streaming output
        
        Yields:
            Chunks of the generated document
        """
        # Get template
        template = self.template_manager.get_template(doc_type)
        if not template:
            yield f"Error: Template for {doc_type} not found"
            return
        
        # Build system prompt
        system_prompt = DocumentGenerationPrompt.build_system_prompt(
            doc_type, template.content
        )
        
        # Build attachments summary
        attachments_summary = self._build_attachments_summary(attachments or [])
        
        # Build user prompt
        if custom_prompt:
            user_prompt = custom_prompt
        else:
            user_prompt = DocumentGenerationPrompt.build_generation_prompt(
                user_requirements=user_requirements,
                doc_type=doc_type,
                attachments_summary=attachments_summary,
                previous_document=previous_document
            )
        
        # Prepare messages
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt)
        ]
        
        # Add images from attachments if any
        all_images = []
        for attachment in (attachments or []):
            if attachment.images:
                all_images.extend(attachment.images)
        
        if all_images:
            messages.append(Message(
                role="user",
                content="[Reference images from attachments]",
                images=all_images[:5]  # Limit to 5 images
            ))
        
        # Stream generate
        full_content = ""
        async for chunk in self.llm.generate_stream(messages):
            full_content += chunk
            yield chunk
        
        # Post-process the document
        processed_doc = self._post_process_document(full_content, doc_type)
        
        # Yield metadata at the end
        metadata = json.dumps({
            "type": "metadata",
            "doc_type": doc_type,
            "flowcharts": processed_doc.flowcharts,
            "ui_designs": processed_doc.ui_designs
        }, ensure_ascii=False)  # 关键：防止中文被转义
        yield f"\n\n<!--METADATA:{metadata}-->"
    
    async def modify_document(
        self,
        current_document: str,
        modification_request: str,
        doc_type: str
    ) -> AsyncIterator[str]:
        """
        Modify an existing document based on user request
        
        Yields:
            Chunks of the modified document
        """
        # Get template
        template = self.template_manager.get_template(doc_type)
        
        # Build prompts
        system_prompt = DocumentGenerationPrompt.build_system_prompt(
            doc_type, template.content if template else ""
        )
        
        user_prompt = DocumentGenerationPrompt.build_modification_prompt(
            current_document=current_document,
            modification_request=modification_request,
            doc_type=doc_type
        )
        
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_prompt)
        ]
        
        # Stream generate
        full_content = ""
        async for chunk in self.llm.generate_stream(messages):
            full_content += chunk
            yield chunk
        
        # Post-process
        processed_doc = self._post_process_document(full_content, doc_type)
        
        metadata = json.dumps({
            "type": "metadata",
            "doc_type": doc_type,
            "flowcharts": processed_doc.flowcharts,
            "ui_designs": processed_doc.ui_designs
        })
        yield f"\n\n<!--METADATA:{metadata}-->"
    
    async def generate_flowchart(
        self,
        section_title: str,
        section_content: str
    ) -> str:
        """Generate a flowchart for a specific section"""
        prompt = DocumentGenerationPrompt.build_flowchart_prompt(
            section_title, section_content
        )
        
        messages = [
            Message(role="system", content="You are an expert in creating Mermaid diagrams."),
            Message(role="user", content=prompt)
        ]
        
        result = await self.llm.generate(messages)
        
        # Extract mermaid code block
        mermaid_match = re.search(r'```mermaid\n(.*?)```', result, re.DOTALL)
        if mermaid_match:
            return mermaid_match.group(1).strip()
        
        return result
    
    async def generate_ui_design(
        self,
        section_title: str,
        requirements: str
    ) -> str:
        """Generate a UI design for a specific section"""
        prompt = DocumentGenerationPrompt.build_ui_design_prompt(
            section_title, requirements
        )
        
        messages = [
            Message(role="system", content="You are an expert UI/UX designer."),
            Message(role="user", content=prompt)
        ]
        
        result = await self.llm.generate(messages)
        
        # Extract HTML code block
        html_match = re.search(r'```html\n(.*?)```', result, re.DOTALL)
        if html_match:
            return html_match.group(1).strip()
        
        return result
    
    def _build_attachments_summary(self, attachments: List[ProcessedFile]) -> str:
        """Build a summary of all attachments"""
        if not attachments:
            return ""
        
        summaries = []
        for att in attachments:
            summary = f"""
---
File: {att.filename}
Type: {att.file_type}
Content:
{att.content[:5000] if len(att.content) > 5000 else att.content}
"""
            summaries.append(summary)
        
        return "\n".join(summaries)
    
    def _post_process_document(
        self,
        content: str,
        doc_type: str
    ) -> GeneratedDocument:
        """Post-process the generated document"""
        # Extract mermaid diagrams
        flowcharts = self._extract_flowcharts(content)
        
        # Extract HTML designs
        ui_designs = self._extract_ui_designs(content)
        
        # Parse sections
        sections = self._parse_sections(content)
        
        # Extract title
        title = self._extract_title(content) or f"{doc_type} Document"
        
        return GeneratedDocument(
            doc_type=doc_type,
            title=title,
            content=content,
            sections=sections,
            metadata={
                "generated_at": datetime.now().isoformat(),
                "doc_type": doc_type,
                "title": title
            },
            flowcharts=flowcharts,
            ui_designs=ui_designs
        )
    
    def _extract_flowcharts(self, content: str) -> List[Dict[str, str]]:
        """Extract all mermaid flowcharts from content"""
        flowcharts = []
        pattern = r'```mermaid\n(.*?)```'
        matches = re.finditer(pattern, content, re.DOTALL)
        
        for i, match in enumerate(matches):
            code = match.group(1).strip()
            # Determine type
            chart_type = "flowchart"
            if "sequenceDiagram" in code:
                chart_type = "sequence"
            elif "classDiagram" in code:
                chart_type = "class"
            elif "erDiagram" in code:
                chart_type = "er"
            elif "gantt" in code:
                chart_type = "gantt"
            
            flowcharts.append({
                "id": f"flowchart_{i}",
                "type": chart_type,
                "code": code
            })
        
        return flowcharts
    
    def _extract_ui_designs(self, content: str) -> List[Dict[str, str]]:
        """Extract all HTML UI designs from content"""
        ui_designs = []
        pattern = r'```html\n(.*?)```'
        matches = re.finditer(pattern, content, re.DOTALL)
        
        for i, match in enumerate(matches):
            ui_designs.append({
                "id": f"ui_design_{i}",
                "code": match.group(1).strip()
            })
        
        return ui_designs
    
    def _parse_sections(self, content: str) -> List[GeneratedSection]:
        """Parse content into sections"""
        sections = []
        lines = content.split('\n')
        current_section = None
        section_content = []
        
        for line in lines:
            header_match = re.match(r'^(#{1,6})\s+(.+)$', line)
            
            if header_match:
                # Save previous section
                if current_section:
                    current_section.content = '\n'.join(section_content)
                    sections.append(current_section)
                
                # Start new section
                level = len(header_match.group(1))
                title = header_match.group(2).strip()
                
                # Check if this section has visual elements
                section_text = '\n'.join(section_content).lower()
                has_flowchart = '```mermaid' in section_text
                has_ui_design = '```html' in section_text
                
                current_section = GeneratedSection(
                    title=title,
                    level=level,
                    content="",
                    has_flowchart=has_flowchart,
                    has_ui_design=has_ui_design
                )
                section_content = [line]
            
            elif current_section is not None:
                section_content.append(line)
        
        # Don't forget the last section
        if current_section:
            current_section.content = '\n'.join(section_content)
            sections.append(current_section)
        
        return sections
    
    def _extract_title(self, content: str) -> Optional[str]:
        """Extract document title from content"""
        # Try to find H1
        h1_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
        if h1_match:
            return h1_match.group(1).strip()
        
        # Try to find title in metadata
        title_match = re.search(r'[Tt]itle:\s*(.+)$', content, re.MULTILINE)
        if title_match:
            return title_match.group(1).strip()
        
        return None
    
    def export_document(
        self,
        document: GeneratedDocument,
        format: str = "markdown"
    ) -> str:
        """Export document to different formats"""
        if format == "markdown":
            return document.content
        
        elif format == "html":
            return self._convert_to_html(document)
        
        elif format == "json":
            return json.dumps(document.to_dict(), indent=2)
        
        return document.content
    
    def _convert_to_html(self, document: GeneratedDocument) -> str:
        """Convert document to HTML format"""
        # Simple markdown to HTML conversion
        content = document.content
        
        # Convert headers
        for i in range(6, 0, -1):
            pattern = f'^{"#" * i}\\s+(.+)$'
            replacement = f'<h{i}>\\1</h{i}>'
            content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
        
        # Convert mermaid blocks
        content = re.sub(
            r'```mermaid\n(.*?)```',
            r'<div class="mermaid">\1</div>',
            content,
            flags=re.DOTALL
        )
        
        # Convert HTML blocks
        content = re.sub(
            r'```html\n(.*?)```',
            r'\1',
            content,
            flags=re.DOTALL
        )
        
        # Wrap in HTML template
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>{document.title}</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #333; border-bottom: 2px solid #007acc; }}
        h2 {{ color: #444; border-bottom: 1px solid #ddd; }}
        .mermaid {{ background: #f5f5f5; padding: 20px; border-radius: 8px; }}
    </style>
</head>
<body>
    {content}
    <script>mermaid.initialize({{startOnLoad: true}});</script>
</body>
</html>"""
        
        return html


# Global document generator instance
document_generator = DocumentGenerator()
