/**
 * SDLC Agent - Frontend Application
 */

// ===== Global State =====
const state = {
    currentSession: null,
    currentDocument: '',
    docType: 'FDS',
    isGenerating: false,
    files: [],
    templates: [],
    sessions: [],
    flowcharts: [],
    uiDesigns: [],
    ws: null
};

// Expose state to window for integration with other scripts
window.state = state;

// ===== Initialization =====
document.addEventListener('DOMContentLoaded', () => {
    init();
});

async function init() {
    console.log('SDLC Agent initializing...');
    
    try {
        mermaid.initialize({
            startOnLoad: false,
            theme: 'default',
            securityLevel: 'loose'
        });
        console.log('Mermaid initialized');
        
        await loadTemplates();
        console.log('Templates loaded:', state.templates.length);
        
        await loadSessions();
        console.log('Sessions loaded:', state.sessions.length);
        
        setupEventListeners();
        console.log('Event listeners setup complete');
        
        // Select default template
        const templateSelect = document.getElementById('templateSelect');
        if (templateSelect && templateSelect.options.length > 1) {
            templateSelect.selectedIndex = 1;
            state.docType = templateSelect.value;
            console.log('Default template selected:', state.docType);
        }
        
        console.log('SDLC Agent initialized successfully');
    } catch (error) {
        console.error('Initialization error:', error);
        alert('Error initializing application. Please check console.');
    }
}

function setupEventListeners() {
    // File input
    document.getElementById('fileInput').addEventListener('change', handleFileSelect);
    
    // Message input - Enter to send
    document.getElementById('messageInput').addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Template selector - handled by inline onchange in index.html
}

// ===== API Functions =====

async function apiGet(endpoint) {
    const response = await fetch(`/api${endpoint}`);
    return response.json();
}

async function apiPost(endpoint, data) {
    const response = await fetch(`/api${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    return response.json();
}

// ===== Template Management =====

async function loadTemplates() {
    try {
        console.log('Loading templates...');
        const response = await apiGet('/templates');
        console.log('Templates response:', response);
        if (response.status === 'success') {
            state.templates = response.templates;
            renderTemplateSelect();
        }
    } catch (error) {
        console.error('Error loading templates:', error);
    }
}

function renderTemplateSelect() {
    const select = document.getElementById('templateSelect');
    select.innerHTML = '<option value="">Select Template...</option>';
    
    state.templates.forEach(template => {
        const option = document.createElement('option');
        option.value = template.doc_type;
        option.textContent = `${template.doc_type} - ${template.description}`;
        select.appendChild(option);
    });
}

function openTemplateModal() {
    document.getElementById('templateModal').classList.remove('hidden');
    loadTemplateList();
}

function closeTemplateModal() {
    document.getElementById('templateModal').classList.add('hidden');
}

async function loadTemplateList() {
    const container = document.getElementById('templateListModal');
    container.innerHTML = '';
    
    state.templates.forEach(template => {
        const item = document.createElement('div');
        item.className = 'template-item';
        item.innerHTML = `
            <h4>${template.doc_type}</h4>
            <p>${template.description}</p>
        `;
        container.appendChild(item);
    });
}

async function uploadTemplate() {
    const name = document.getElementById('newTemplateName').value;
    const content = document.getElementById('newTemplateContent').value;
    
    if (!name || !content) {
        alert('Please fill in all fields');
        return;
    }
    
    try {
        const response = await apiPost('/templates/upload', {
            name: name,
            content: content,
            doc_type: name.toUpperCase()
        });
        
        if (response.status === 'success') {
            alert('Template uploaded successfully');
            await loadTemplates();
            closeTemplateModal();
        }
    } catch (error) {
        console.error('Error uploading template:', error);
        alert('Failed to upload template');
    }
}

// ===== Session Management =====

async function loadSessions() {
    try {
        console.log('[loadSessions] Fetching sessions...');
        const response = await apiGet('/sessions');
        console.log('[loadSessions] Response:', response);
        if (response.status === 'success') {
            state.sessions = response.sessions;
            console.log('[loadSessions] Loaded', state.sessions.length, 'sessions');
            renderSessionList();
        } else {
            console.warn('[loadSessions] Unexpected response status:', response.status);
        }
    } catch (error) {
        console.error('[loadSessions] Error loading sessions:', error);
    }
}

function renderSessionList() {
    const list = document.getElementById('sessionList');
    list.innerHTML = '';
    
    state.sessions.forEach(session => {
        const li = document.createElement('li');
        li.className = session.id === state.currentSession ? 'active' : '';
        li.innerHTML = `
            <span onclick="loadSession('${session.id}')">${session.title}</span>
            <i class="fas fa-times delete-btn" onclick="deleteSession('${session.id}', event)"></i>
        `;
        list.appendChild(li);
    });
}

function createNewSession() {
    state.currentSession = null;
    state.currentDocument = '';
    state.files = [];
    
    document.getElementById('chatMessages').innerHTML = `
        <div class="welcome-message">
            <h2>Welcome to SDLC Agent</h2>
            <p>Select a template and describe your requirements to get started.</p>
        </div>
    `;
    
    document.getElementById('previewContent').innerHTML = `
        <div class="empty-state">
            <i class="fas fa-file-alt"></i>
            <p>Document preview will appear here</p>
        </div>
    `;
    
    document.getElementById('fileList').innerHTML = '';
    renderSessionList();
}

async function loadSession(sessionId) {
    try {
        const response = await apiGet(`/sessions/${sessionId}`);
        if (response.status === 'success') {
            state.currentSession = sessionId;
            state.docType = response.session.doc_type;
            state.currentDocument = response.session.current_document || '';
            
            // Update template selector
            document.getElementById('templateSelect').value = state.docType;
            
            // Render messages
            renderMessages(response.session.messages);
            
            // Update preview
            if (state.currentDocument) {
                updatePreview(state.currentDocument);
                extractVisuals(state.currentDocument);
            }
            
            renderSessionList();
        }
    } catch (error) {
        console.error('Error loading session:', error);
    }
}

async function deleteSession(sessionId, event) {
    event.stopPropagation();
    
    if (!confirm('Delete this session?')) return;
    
    try {
        const response = await fetch(`/api/sessions/${sessionId}`, {
            method: 'DELETE'
        });
        const data = await response.json();
        
        if (data.status === 'success') {
            if (state.currentSession === sessionId) {
                createNewSession();
            }
            await loadSessions();
        }
    } catch (error) {
        console.error('Error deleting session:', error);
    }
}

// ===== File Handling =====

function handleFileSelect(event) {
    const files = Array.from(event.target.files);
    files.forEach(file => {
        state.files.push(file);
        renderFileList();
    });
}

function renderFileList() {
    const container = document.getElementById('fileList');
    container.innerHTML = '';
    
    state.files.forEach((file, index) => {
        const tag = document.createElement('div');
        tag.className = 'file-tag';
        tag.innerHTML = `
            <i class="fas fa-file"></i>
            <span>${file.name}</span>
            <span class="remove" onclick="removeFile(${index})">&times;</span>
        `;
        container.appendChild(tag);
    });
}

function removeFile(index) {
    state.files.splice(index, 1);
    renderFileList();
}

// ===== Message Handling =====

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message && state.files.length === 0) return;
    if (state.isGenerating) return;
    if (!state.docType) {
        alert('Please select a template first');
        return;
    }
    
    // Add user message to chat
    addMessageToChat('user', message);
    input.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Start generation
    state.isGenerating = true;
    document.querySelector('.btn-send').disabled = true;
    
    try {
        if (state.currentSession && state.currentDocument) {
            // This is a modification request
            await generateModification(message);
        } else {
            // This is a new document request
            await generateDocument(message);
        }
    } catch (error) {
        console.error('Error generating document:', error);
        addMessageToChat('assistant', 'Error: ' + error.message);
    } finally {
        state.isGenerating = false;
        document.querySelector('.btn-send').disabled = false;
        hideTypingIndicator();
    }
}

function addMessageToChat(role, content, attachments = []) {
    const container = document.getElementById('chatMessages');
    
    // Remove welcome message if exists
    const welcome = container.querySelector('.welcome-message');
    if (welcome) welcome.remove();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    let html = marked.parse(content);
    
    if (attachments.length > 0) {
        html += '<div class="attachments">';
        attachments.forEach(file => {
            html += `<div><i class="fas fa-paperclip"></i> ${file.name}</div>`;
        });
        html += '</div>';
    }
    
    messageDiv.innerHTML = html;
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
}

function showTypingIndicator() {
    const container = document.getElementById('chatMessages');
    const indicator = document.createElement('div');
    indicator.className = 'message assistant typing-indicator-container';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    container.appendChild(indicator);
    container.scrollTop = container.scrollHeight;
}

function hideTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function renderMessages(messages) {
    const container = document.getElementById('chatMessages');
    container.innerHTML = '';
    
    messages.forEach(msg => {
        const role = msg.type === 'user' ? 'user' : 
                     msg.type === 'document' ? 'assistant' : 'system';
        addMessageToChat(role, msg.content);
    });
}

// ===== Document Generation =====

async function generateDocument(requirements) {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket(`ws://${window.location.host}/ws/generate`);
        
        let fullContent = '';
        let isResolved = false; // Track if already resolved/rejected
        
        const safeResolve = (value) => {
            if (!isResolved) {
                isResolved = true;
                resolve(value);
            }
        };
        
        const safeReject = (error) => {
            if (!isResolved) {
                isResolved = true;
                reject(error);
            }
        };
        
        ws.onopen = () => {
            // Prepare files
            const filePromises = state.files.map(file => {
                return new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onload = () => {
                        const base64 = reader.result.split(',')[1];
                        resolve({
                            filename: file.name,
                            content_type: file.type || 'application/octet-stream',
                            content: base64
                        });
                    };
                    reader.readAsDataURL(file);
                });
            });
            
            Promise.all(filePromises).then(filesData => {
                ws.send(JSON.stringify({
                    doc_type: state.docType,
                    requirements: requirements,
                    session_id: state.currentSession,
                    files: filesData
                }));
            });
        };
        
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            // Decode Unicode and HTML entities in content
            if (data.content) {
                data.content = decodeUnicode(data.content);
                // Also decode any HTML entities that might have been escaped
                if (data.content.includes('&lt;') || data.content.includes('&gt;') || data.content.includes('&amp;')) {
                    data.content = decodeHtmlEntities(data.content);
                }
            }
            
            switch (data.type) {
                case 'session_created':
                    state.currentSession = data.session_id;
                    console.log('[WebSocket] Session created:', data.session_id, 'title:', data.title);
                    if (data.title) {
                        // Update chat title if provided
                        const titleEl = document.getElementById('chatTitle');
                        if (titleEl) titleEl.textContent = data.title;
                    }
                    // Refresh session list to show new session
                    loadSessions().then(() => {
                        console.log('[WebSocket] Session list refreshed');
                    }).catch(err => {
                        console.error('[WebSocket] Failed to refresh session list:', err);
                    });
                    break;
                    
                case 'chunk':
                    fullContent += data.content;
                    updatePreview(fullContent);
                    break;
                    
                case 'complete':
                    // Use accumulated fullContent to ensure we have all content
                    state.currentDocument = fullContent || data.content;
                    updatePreview(state.currentDocument);
                    extractVisuals(state.currentDocument);
                    addMessageToChat('assistant', 'Document generated successfully!');
                    loadSessions();
                    ws.close();
                    safeResolve();
                    break;
                    
                case 'error':
                    ws.close();
                    safeReject(new Error(data.message));
                    break;
            }
        };
        
        ws.onerror = (error) => {
            console.error('[DEBUG] WebSocket error:', error);
            safeReject(new Error('WebSocket connection error'));
            ws.close();
        };
        
        ws.onclose = (event) => {
            if (event.code !== 1000 && !isResolved) {
                // Abnormal closure
                safeReject(new Error(`Connection closed unexpectedly (code: ${event.code})`));
            }
        };
    });
}

async function generateModification(modificationRequest) {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket(`ws://${window.location.host}/ws/modify`);
        
        let fullContent = '';
        
        ws.onopen = () => {
            ws.send(JSON.stringify({
                session_id: state.currentSession,
                modification_request: modificationRequest
            }));
        };
        
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            if (data.content) {
                data.content = decodeUnicode(data.content);
                // Also decode any HTML entities that might have been escaped
                if (data.content.includes('&lt;') || data.content.includes('&gt;') || data.content.includes('&amp;')) {
                    data.content = decodeHtmlEntities(data.content);
                }
            }
            
            switch (data.type) {
                case 'chunk':
                    fullContent += data.content;
                    updatePreview(fullContent);
                    break;
                    
                case 'complete':
                    // Use accumulated fullContent to ensure we have all content
                    state.currentDocument = fullContent || data.content;
                    updatePreview(state.currentDocument);
                    extractVisuals(state.currentDocument);
                    addMessageToChat('assistant', 'Document updated successfully!');
                    loadSessions();
                    ws.close();
                    resolve();
                    break;
                    
                case 'error':
                    ws.close();
                    reject(new Error(data.message));
                    break;
            }
        };
        
        ws.onerror = (error) => {
            reject(error);
        };
    });
}

// ===== Unicode and HTML Entity Decode Helper =====

function decodeUnicode(str) {
    if (!str) return str;
    
    // Decode Unicode escape sequences like \uXXXX to actual characters
    str = str.replace(/\\u([0-9a-fA-F]{4})/g, function(match, grp) {
        return String.fromCharCode(parseInt(grp, 16));
    });
    
    return str;
}

function decodeHtmlEntities(str) {
    if (!str) return str;
    
    const textarea = document.createElement('textarea');
    textarea.innerHTML = str;
    return textarea.value;
}

// ===== Preview and Visualization =====

function updatePreview(content) {
    const preview = document.getElementById('previewContent');
    if (!preview) return;
    
    // First decode any HTML entities in the content
    if (content.includes('&lt;') || content.includes('&gt;') || content.includes('&amp;')) {
        content = decodeHtmlEntities(content);
    }
    
    // Extract metadata if present (before decoding unicode to preserve JSON structure)
    // Use lazy match to find properly closed metadata tag
    const metadataMatch = content.match(/<!--METADATA:([\s\S]*?)-->/);
    let cleanContent = content;
    
    if (metadataMatch) {
        try {
            // Decode unicode in the metadata part
            const metadataStr = decodeUnicode(metadataMatch[1]);
            // Try to find complete JSON object (ending with })
            const jsonMatch = metadataStr.match(/(\{[\s\S]*\})/);
            if (jsonMatch) {
                const metadata = JSON.parse(jsonMatch[1]);
                
                // Process flowcharts: unescape newlines
                if (metadata.flowcharts) {
                    state.flowcharts = metadata.flowcharts.map(chart => ({
                        ...chart,
                        code: chart.code ? chart.code.replace(/\\n/g, '\n').replace(/\\t/g, '\t') : ''
                    }));
                }
                if (metadata.ui_designs) {
                    state.uiDesigns = metadata.ui_designs.map(design => ({
                        ...design,
                        code: design.code ? design.code.replace(/\\n/g, '\n').replace(/\\t/g, '\t') : ''
                    }));
                }
                
                console.log('Loaded flowcharts:', state.flowcharts.length);
                console.log('Loaded UI designs:', state.uiDesigns.length);
            }
        } catch (e) {
            console.error('Error parsing metadata:', e);
        }
        // Remove the entire metadata block
        cleanContent = content.replace(/<!--METADATA:[\s\S]*?-->/, '');
    }
    
    // Clean up trailing artifacts that may appear after "End of Document"
    // Remove everything after "End of Document" line except the line itself
    cleanContent = cleanContent.replace(/(End of\s+\w+\s+Document)\s*[\s\S]*$/i, '$1');
    
    // Remove trailing JSON-like artifacts or metadata fragments that may appear before "End of Document"
    cleanContent = cleanContent.replace(/,\s*"flowcharts"\s*:\s*\[[\s\S]*$/g, '');
    cleanContent = cleanContent.replace(/,\s*"ui_designs"\s*:\s*\[[\s\S]*$/g, '');
    
    // Remove any raw mermaid code fragments that appear outside code blocks
    // These are typically sequences like "B{...}" or arrow diagrams
    cleanContent = cleanContent.replace(/\n\s*B\{[\s\S]*?\n\s*(?:\n|$)/g, '\n');
    
    // Decode Unicode escape sequences in content
    cleanContent = decodeUnicode(cleanContent);
    
    // Clean up extra blank lines
    cleanContent = cleanContent.replace(/\n{3,}/g, '\n\n');
    
    // Render markdown
    preview.innerHTML = marked.parse(cleanContent);
    
    // Initialize mermaid diagrams with error handling
    setTimeout(async () => {
        const elements = preview.querySelectorAll('.language-mermaid');
        console.log(`[updatePreview] Found ${elements.length} mermaid elements`);
        
        for (let i = 0; i < elements.length; i++) {
            const el = elements[i];
            const rawCode = el.textContent.trim();
            let code = cleanMermaidCode(rawCode);
            
            console.log(`[updatePreview] Processing mermaid ${i + 1}, raw length: ${rawCode.length}, cleaned length: ${code.length}`);
            
            // Debug: check if code contains escaped HTML
            if (code.includes('&lt;') || code.includes('&gt;') || code.includes('&amp;')) {
                console.warn('[updatePreview] Code still contains HTML entities, decoding again...');
                const textarea = document.createElement('textarea');
                textarea.innerHTML = code;
                code = textarea.value;
            }
            
            // Debug: check if code contains problematic characters
            if (code.includes('[Error:') || code.includes('peer closed')) {
                console.error('[updatePreview] Code appears corrupted:', code.substring(0, 200));
                continue;
            }
            
            // Skip empty or very short codes
            if (code.length < 10) {
                console.warn('[updatePreview] Code too short, skipping');
                continue;
            }
            
            try {
                // Validate syntax first
                await mermaid.parse(code);
                
                // Generate unique ID
                const id = 'mermaid-doc-' + Math.random().toString(36).substr(2, 9);
                
                // Render the chart
                const { svg } = await mermaid.render(id, code);
                
                // Replace the code block with the rendered SVG
                const wrapper = document.createElement('div');
                wrapper.className = 'mermaid-diagram';
                wrapper.style.cssText = 'text-align: center; padding: 15px; background: #f8f9fa; border-radius: 8px; margin: 10px 0;';
                wrapper.innerHTML = svg;
                
                // Replace the pre/code block with the rendered diagram
                const preBlock = el.closest('pre');
                if (preBlock) {
                    preBlock.parentNode.replaceChild(wrapper, preBlock);
                } else {
                    el.parentNode.replaceChild(wrapper, el);
                }
                
                console.log(`[updatePreview] Mermaid ${i + 1} rendered successfully`);
            } catch (error) {
                console.error(`[updatePreview] Mermaid rendering error for element ${i + 1}:`, error);
                console.error('[updatePreview] Problematic code:', code.substring(0, 500));
                
                // Show error in the UI with fix button
                const preBlock = el.closest('pre');
                if (preBlock) {
                    const errorDiv = document.createElement('div');
                    errorDiv.style.cssText = 'color: #c41e3a; padding: 10px; background: #fff5f5; border-radius: 4px; margin-top: 10px;';
                    errorDiv.innerHTML = `
                        <i class="fas fa-exclamation-triangle"></i> 
                        <strong>渲染失败</strong>
                        <p style="margin: 5px 0; font-size: 11px;">${escapeHtml(error.message)}</p>
                    `;
                    preBlock.style.border = '1px solid #c41e3a';
                    preBlock.style.background = '#fff5f5';
                    preBlock.parentNode.insertBefore(errorDiv, preBlock.nextSibling);
                }
            }
        }
        
        // Render HTML code blocks as UI preview
        const htmlElements = preview.querySelectorAll('.language-html');
        
        for (const el of htmlElements) {
            let code = el.textContent.trim();
            
            // Skip empty or very short codes
            if (code.length < 20) continue;
            
            try {
                // Create UI preview wrapper
                const wrapper = document.createElement('div');
                wrapper.className = 'ui-preview-inline';
                wrapper.style.cssText = 'margin: 15px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;';
                
                // Add label
                const label = document.createElement('div');
                label.style.cssText = 'background: #f3f4f6; padding: 8px 12px; font-size: 12px; color: #6b7280; border-bottom: 1px solid #e5e7eb;';
                label.innerHTML = '<i class="fas fa-desktop"></i> UI Preview';
                wrapper.appendChild(label);
                
                // Create iframe for HTML preview
                const iframe = document.createElement('iframe');
                iframe.style.cssText = 'width: 100%; height: 400px; border: none; background: white;';
                iframe.srcdoc = code;
                wrapper.appendChild(iframe);
                
                // Replace the pre/code block with the UI preview
                const preBlock = el.closest('pre');
                if (preBlock) {
                    preBlock.parentNode.replaceChild(wrapper, preBlock);
                } else {
                    el.parentNode.replaceChild(wrapper, el);
                }
            } catch (error) {
                console.error('HTML preview rendering error:', error);
            }
        }
    }, 100);
}

function extractVisuals(content) {
    // Extract from raw content before decoding unicode
    // This handles content directly from LLM (with actual newlines)
    
    // First decode any HTML entities
    if (content.includes('&lt;') || content.includes('&gt;') || content.includes('&amp;')) {
        content = decodeHtmlEntities(content);
    }
    
    // First, clean up any trailing JSON artifacts that may have been included
    let cleanContent = content;
    
    // Remove trailing JSON metadata if present (from incomplete metadata blocks)
    cleanContent = cleanContent.replace(/,\s*"flowcharts"\s*:\s*\[[\s\S]*$/, '');
    cleanContent = cleanContent.replace(/,\s*"ui_designs"\s*:\s*\[[\s\S]*$/, '');
    
    // Extract mermaid diagrams
    const mermaidRegex = /```mermaid\n([\s\S]*?)```/g;
    let match;
    state.flowcharts = [];
    let index = 0;
    
    while ((match = mermaidRegex.exec(cleanContent)) !== null) {
        let code = match[1].trim();
        
        // Clean up the code: decode unicode and unescape
        code = decodeUnicode(code);
        code = code.replace(/\\n/g, '\n').replace(/\\t/g, '\t');
        
        // Skip if code is too short or doesn't look like valid mermaid
        if (code.length < 10) continue;
        
        state.flowcharts.push({
            id: `flowchart_${index}`,
            code: code,
            type: 'flowchart'
        });
        index++;
    }
    
    // Extract HTML designs
    const htmlRegex = /```html\n([\s\S]*?)```/g;
    state.uiDesigns = [];
    index = 0;
    
    while ((match = htmlRegex.exec(cleanContent)) !== null) {
        let code = match[1].trim();
        
        // Clean up the code: decode unicode and unescape
        code = decodeUnicode(code);
        code = code.replace(/\\n/g, '\n').replace(/\\t/g, '\t');
        
        // Skip if code is too short
        if (code.length < 20) continue;
        
        state.uiDesigns.push({
            id: `ui_${index}`,
            code: code
        });
        index++;
    }
    
    console.log(`Extracted ${state.flowcharts.length} flowcharts, ${state.uiDesigns.length} UI designs`);
    
    renderFlowcharts();
    renderUIDesigns();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function cleanMermaidCode(code) {
    // First decode HTML entities
    const textarea = document.createElement('textarea');
    textarea.innerHTML = code;
    let cleaned = textarea.value;
    
    // Replace Chinese punctuation with English punctuation
    cleaned = cleaned
        .replace(/：/g, ':')   // Chinese colon to English colon
        .replace(/，/g, ',')   // Chinese comma to English comma
        .replace(/；/g, ';')   // Chinese semicolon to English semicolon
        .replace(/（/g, '(')   // Chinese left parenthesis to English
        .replace(/）/g, ')')   // Chinese right parenthesis to English
        .replace(/【/g, '[')   // Chinese left bracket to English
        .replace(/】/g, ']')   // Chinese right bracket to English
        .replace(/"/g, '"')   // Chinese quotes to English
        .replace(/"/g, '"')
        .replace(/'/g, "'")
        .replace(/'/g, "'")
        .replace(/……/g, '...')
        .replace(/——/g, '--');
    
    return cleaned;
}

function renderFlowcharts() {
    const container = document.getElementById('flowchartList');
    
    if (!container) {
        console.error('flowchartList element not found');
        return;
    }
    
    if (!state.flowcharts || state.flowcharts.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-project-diagram"></i>
                <p>No flowcharts in this document</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    state.flowcharts.forEach((chart, index) => {
        const item = document.createElement('div');
        item.className = 'flowchart-item';
        
        // Process the code: decode unicode and unescape
        let processedCode = chart.code || '';
        
        // Replace literal \n with actual newlines
        processedCode = processedCode.replace(/\\n/g, '\n');
        processedCode = processedCode.replace(/\\t/g, '\t');
        
        // Clean Chinese punctuation
        processedCode = cleanMermaidCode(processedCode);
        
        // Validate mermaid code
        const hasValidSyntax = processedCode.includes('flowchart') || 
                               processedCode.includes('graph') ||
                               processedCode.includes('sequenceDiagram') ||
                               processedCode.includes('classDiagram') ||
                               processedCode.includes('erDiagram') ||
                               processedCode.includes('gantt');
        
        console.log(`Flowchart ${index + 1} code:`, processedCode.substring(0, 200));
        
        // Create title element
        const title = document.createElement('h4');
        title.textContent = `Flowchart ${index + 1}`;
        item.appendChild(title);
        
        if (!hasValidSyntax) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-state';
            errorDiv.style.cssText = 'color: #c41e3a; padding: 10px; background: #fff5f5; border-radius: 4px;';
            errorDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Invalid Mermaid syntax`;
            
            const pre = document.createElement('pre');
            pre.style.cssText = 'margin-top: 10px; font-size: 12px; overflow-x: auto;';
            pre.textContent = processedCode.substring(0, 200) + '...';
            errorDiv.appendChild(pre);
            
            item.appendChild(errorDiv);
        } else {
            // Use mermaid.render instead of mermaid.run for better control
            const mermaidDiv = document.createElement('div');
            mermaidDiv.className = 'flowchart-rendered';
            item.appendChild(mermaidDiv);
            
            // Store code for rendering
            item.dataset.mermaidCode = processedCode;
        }
        
        container.appendChild(item);
    });
    
    // Initialize mermaid with a delay to ensure DOM is ready
    setTimeout(async () => {
        const items = container.querySelectorAll('.flowchart-item');
        for (const item of items) {
            const code = item.dataset.mermaidCode;
            if (!code) continue;
            
            try {
                // Validate syntax first
                await mermaid.parse(code);
                
                // Generate unique ID for this chart
                const id = 'mermaid-' + Math.random().toString(36).substr(2, 9);
                
                // Render the chart
                const { svg } = await mermaid.render(id, code);
                
                // Insert the SVG
                const renderDiv = item.querySelector('.flowchart-rendered');
                if (renderDiv) {
                    renderDiv.innerHTML = svg;
                }
            } catch (error) {
                console.error(`Error rendering flowchart:`, error);
                const renderDiv = item.querySelector('.flowchart-rendered');
                const errorMsg = error.message || 'Syntax error in text';
                const chartId = `chart-${index}`;
                
                if (renderDiv) {
                    renderDiv.innerHTML = `
                        <div style="color: #c41e3a; padding: 10px; background: #fff5f5; border-radius: 4px;" id="${chartId}">
                            <i class="fas fa-exclamation-triangle"></i> 
                            <strong>Syntax Error</strong>
                            <p style="margin: 5px 0; font-size: 12px; color: #666;">${escapeHtml(errorMsg)}</p>
                            <button class="btn btn-sm" onclick="fixMermaidCode('${chartId}', ${index})" 
                                    style="margin-top: 8px; padding: 4px 12px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">
                                <i class="fas fa-wrench"></i> 尝试修复
                            </button>
                            <details style="margin-top: 10px;">
                                <summary style="font-size: 11px; color: #666; cursor: pointer;">查看代码</summary>
                                <pre style="margin-top: 10px; font-size: 11px; overflow-x: auto; background: #f5f5f5; padding: 10px; border-radius: 4px;">${escapeHtml(code)}</pre>
                            </details>
                        </div>
                    `;
                    // Store code in parent element for fixing
                    document.getElementById(chartId).dataset.code = code;
                    document.getElementById(chartId).dataset.error = errorMsg;
                }
            }
        }
    }, 300);
}

async function fixMermaidCode(chartId, chartIndex) {
    const chartDiv = document.getElementById(chartId);
    const code = chartDiv.dataset.code;
    const error = chartDiv.dataset.error;
    
    chartDiv.innerHTML = `
        <div style="padding: 20px; text-align: center;">
            <div class="typing-indicator" style="display: inline-flex;">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
            <p style="margin-top: 10px; font-size: 12px; color: #666;">正在修复语法错误...</p>
        </div>
    `;
    
    try {
        const response = await fetch('/api/tasks/execute', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                task_type: 'FIX_MERMAID',
                user_input: `Fix this mermaid code: ${error}`,
                context: {
                    error_message: error,
                    mermaid_code: code
                }
            })
        });
        
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fixedCode = '';
        
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            fixedCode += decoder.decode(value);
        }
        
        // Extract mermaid code block
        const mermaidMatch = fixedCode.match(/```mermaid\n([\s\S]*?)```/);
        if (mermaidMatch) {
            fixedCode = mermaidMatch[1].trim();
        }
        
        // Try to render the fixed code
        try {
            await mermaid.parse(fixedCode);
            const id = 'mermaid-fixed-' + Math.random().toString(36).substr(2, 9);
            const { svg } = await mermaid.render(id, fixedCode);
            
            chartDiv.innerHTML = svg;
            
            // Update the stored code
            state.flowcharts[chartIndex].code = fixedCode;
            
            // Show success message
            addMessageToChat('assistant', '✅ 流程图语法已修复', { showActions: true });
        } catch (renderError) {
            chartDiv.innerHTML = `
                <div style="color: #c41e3a; padding: 10px; background: #fff5f5; border-radius: 4px;">
                    <i class="fas fa-exclamation-triangle"></i> 修复后仍有语法错误
                    <pre style="margin-top: 10px; font-size: 11px; overflow-x: auto; background: #f5f5f5; padding: 10px; border-radius: 4px;">${escapeHtml(fixedCode.substring(0, 200))}</pre>
                </div>
            `;
        }
    } catch (apiError) {
        console.error('API error:', apiError);
        chartDiv.innerHTML = `
            <div style="color: #c41e3a; padding: 10px; background: #fff5f5; border-radius: 4px;">
                <i class="fas fa-exclamation-circle"></i> 修复请求失败: ${escapeHtml(apiError.message)}
            </div>
        `;
    }
}

function renderUIDesigns() {
    const container = document.getElementById('uiList');
    
    if (!container) {
        console.error('uiList element not found');
        return;
    }
    
    if (!state.uiDesigns || state.uiDesigns.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-desktop"></i>
                <p>No UI designs in this document</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    state.uiDesigns.forEach((design, index) => {
        const item = document.createElement('div');
        item.className = 'ui-item';
        item.innerHTML = `
            <h4>UI Design ${index + 1}</h4>
            <div class="ui-preview">
                <iframe srcdoc="${design.code.replace(/"/g, '&quot;')}" 
                        style="width:100%;height:300px;border:1px solid #ddd;border-radius:4px;">
                </iframe>
            </div>
        `;
        container.appendChild(item);
    });
}

// ===== Tab Switching =====

function switchDocumentTab(tab) {
    // Update tab buttons
    document.querySelectorAll('.document-tabs .tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`.document-tabs .tab-btn[data-tab="${tab}"]`).classList.add('active');
    
    // Hide all views
    document.getElementById('documentPreview').classList.add('hidden');
    document.getElementById('flowchartView').classList.add('hidden');
    document.getElementById('uiView').classList.add('hidden');
    document.getElementById('knowledgeView').classList.add('hidden');
    
    // Show selected view
    if (tab === 'document') {
        document.getElementById('documentPreview').classList.remove('hidden');
        // Mermaid diagrams are already rendered by updatePreview
    } else if (tab === 'flowchart') {
        document.getElementById('flowchartView').classList.remove('hidden');
        // Re-render flowcharts when tab is shown
        renderFlowcharts();
    } else if (tab === 'ui') {
        document.getElementById('uiView').classList.remove('hidden');
        renderUIDesigns();
    } else if (tab === 'knowledge') {
        document.getElementById('knowledgeView').classList.remove('hidden');
        loadKnowledgeBase();
    }
}

// ===== Knowledge Base =====

async function loadKnowledgeBase() {
    try {
        const response = await apiGet('/knowledge-base/documents');
        if (response.status === 'success') {
            renderKnowledgeList(response.documents);
        }
    } catch (error) {
        console.error('Error loading knowledge base:', error);
    }
}

async function loadDocumentFromKB(docId) {
    try {
        const response = await apiGet(`/documents/${docId}`);
        if (response.status === 'success') {
            updatePreview(response.document.content);
            extractVisuals(response.document.content);
            switchDocumentTab('document');
        }
    } catch (error) {
        console.error('Error loading document:', error);
    }
}

function renderKnowledgeList(documents) {
    const container = document.getElementById('knowledgeList');
    container.innerHTML = '';
    
    if (documents.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-book"></i>
                <p>No documents in knowledge base</p>
            </div>
        `;
        return;
    }
    
    documents.forEach(doc => {
        const item = document.createElement('div');
        item.className = 'knowledge-item';
        item.onclick = () => loadDocumentFromKB(doc.id);
        item.innerHTML = `
            <h4>${doc.title}</h4>
            <div class="meta">
                <span>${doc.entry_type}</span> • 
                <span>${new Date(doc.created_at).toLocaleDateString()}</span>
            </div>
        `;
        container.appendChild(item);
    });
}

function searchKnowledgeBase() {
    const query = document.getElementById('kbSearch').value;
    // Implement search
    loadKnowledgeBase();
}

// ===== Utility Functions =====

function copyDocument() {
    if (!state.currentDocument) {
        alert('No document to copy');
        return;
    }
    
    navigator.clipboard.writeText(state.currentDocument).then(() => {
        alert('Document copied to clipboard');
    }).catch(err => {
        console.error('Error copying document:', err);
    });
}

function refreshPreview() {
    if (state.currentDocument) {
        updatePreview(state.currentDocument);
    }
}

function enableEdit() {
    alert('Edit mode - This feature will allow direct editing of the document');
}

function switchView(view) {
    console.log('Switching to view:', view);
}

async function downloadDocument(format) {
    if (!state.currentSession) {
        alert('No document to download');
        return;
    }
    
    // Get the latest document from the session
    try {
        const response = await apiGet(`/sessions/${state.currentSession}`);
        if (response.status === 'success' && response.session.current_document) {
            const content = response.session.current_document;
            
            if (format === 'md') {
                downloadFile(content, `document.md`, 'text/markdown');
            } else if (format === 'html') {
                const htmlContent = convertToHTML(content);
                downloadFile(htmlContent, `document.html`, 'text/html');
            }
        }
    } catch (error) {
        console.error('Error downloading document:', error);
    }
}

function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function convertToHTML(markdown) {
    // First, convert markdown to HTML
    let htmlContent = marked.parse(markdown);
    
    // Debug: log what we're converting
    console.log('[convertToHTML] Input markdown length:', markdown.length);
    console.log('[convertToHTML] Has mermaid code:', markdown.includes('```mermaid'));
    console.log('[convertToHTML] Has HTML code:', markdown.includes('```html'));
    
    // Replace mermaid code blocks with mermaid divs for rendering
    // Try multiple patterns as different marked versions generate different HTML
    const mermaidPatterns = [
        /<pre><code class="language-mermaid">([\s\S]*?)<\/code><\/pre>/g,
        /<pre><code class="mermaid">([\s\S]*?)<\/code><\/pre>/g,
        /<pre class="mermaid"><code>([\s\S]*?)<\/code><\/pre>/g
    ];
    
    let mermaidCount = 0;
    for (const pattern of mermaidPatterns) {
        htmlContent = htmlContent.replace(pattern, (match, code) => {
            mermaidCount++;
            // Clean up HTML entities
            const cleanCode = code.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
            return `<div class="mermaid">${cleanCode}</div>`;
        });
    }
    console.log('[convertToHTML] Replaced', mermaidCount, 'mermaid blocks');
    
    // Replace HTML code blocks with iframe previews
    const htmlPatterns = [
        /<pre><code class="language-html">([\s\S]*?)<\/code><\/pre>/g,
        /<pre><code class="html">([\s\S]*?)<\/code><\/pre>/g
    ];
    
    let uiIndex = 0;
    for (const pattern of htmlPatterns) {
        htmlContent = htmlContent.replace(pattern, (match, code) => {
            uiIndex++;
            // Clean up HTML entities
            const cleanCode = code.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
            const escapedCode = cleanCode.replace(/"/g, '&quot;');
            return `
                <div class="ui-preview-container" style="margin: 20px 0; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
                    <div style="background: #f3f4f6; padding: 8px 12px; font-size: 12px; color: #6b7280; border-bottom: 1px solid #e5e7eb;">
                        <i class="fas fa-desktop"></i> UI Design ${uiIndex}
                    </div>
                    <iframe srcdoc="${escapedCode}" style="width: 100%; height: 400px; border: none; background: white;"></iframe>
                </div>
            `;
        });
    }
    console.log('[convertToHTML] Replaced', uiIndex, 'HTML UI blocks');
    
    return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; line-height: 1.6; color: #333; }
        h1 { color: #333; border-bottom: 2px solid #c41e3a; padding-bottom: 10px; }
        h2 { color: #444; border-bottom: 1px solid #ddd; margin-top: 30px; padding-bottom: 8px; }
        h3 { color: #555; margin-top: 25px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #f5f5f5; font-weight: 600; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-family: monospace; }
        .mermaid { background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; }
        ul, ol { padding-left: 25px; }
        li { margin: 5px 0; }
        blockquote { border-left: 4px solid #ddd; margin: 0; padding-left: 20px; color: #666; }
        img { max-width: 100%; height: auto; }
        .ui-preview-container { box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    ${htmlContent}
    <script>
        mermaid.initialize({
            startOnLoad: true,
            theme: 'default',
            securityLevel: 'loose'
        });
    </script>
</body>
</html>`;
}

function downloadFlowchart(chartId) {
    const chart = state.flowcharts.find(c => c.id === chartId);
    if (!chart) return;
    
    const blob = new Blob([chart.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'flowchart.mmd';
    a.click();
    URL.revokeObjectURL(url);
}

function downloadUI(uiId) {
    const design = state.uiDesigns.find(d => d.id === uiId);
    if (!design) return;
    
    const blob = new Blob([design.code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ui-design.html';
    a.click();
    URL.revokeObjectURL(url);
}

// ===== Expose functions to window for index.html integration =====

// Function to update current document from external scripts
window.setCurrentDocument = function(content) {
    state.currentDocument = content;
};

window.state = state;
window.apiGet = apiGet;
window.apiPost = apiPost;
window.addMessageToChat = addMessageToChat;
window.showTypingIndicator = showTypingIndicator;
window.hideTypingIndicator = hideTypingIndicator;
window.updatePreview = updatePreview;
window.extractVisuals = extractVisuals;
window.loadSessions = loadSessions;
window.renderSessionList = renderSessionList;
window.switchDocumentTab = switchDocumentTab;
window.createNewSession = createNewSession;
window.loadTemplates = loadTemplates;
window.openTemplateModal = openTemplateModal;
window.closeTemplateModal = closeTemplateModal;
window.uploadTemplate = uploadTemplate;
window.downloadDocument = downloadDocument;
window.copyDocument = copyDocument;
window.refreshPreview = refreshPreview;
window.enableEdit = enableEdit;
window.switchView = switchView;
window.handleFileSelect = handleFileSelect;
window.renderFileList = renderFileList;
window.removeFile = removeFile;
window.searchKnowledgeBase = searchKnowledgeBase;
window.downloadFlowchart = downloadFlowchart;
window.downloadUI = downloadUI;
window.loadSession = loadSession;
window.deleteSession = deleteSession;
window.sendMessage = sendMessage;
window.fixMermaidCode = fixMermaidCode;

// Placeholder for onTemplateChange - will be overridden by index.html if defined
window.onTemplateChange = window.onTemplateChange || function() { 
    console.log('[app.js] onTemplateChange called but not yet defined'); 
};

console.log('[app.js] Application loaded, functions exposed to window');
