"""
Test script for Task API
测试 P0/P1 功能
"""
import asyncio
import httpx
import json
from typing import Optional

BASE_URL = "http://localhost:8000"


async def test_classify(client: httpx.AsyncClient) -> bool:
    """Test CLASSIFY endpoint"""
    print("\n🎯 Testing CLASSIFY...")
    
    test_cases = [
        ("帮我设计一个保险理赔的页面", "UI"),
        ("写一个业务需求文档", "BRD"),
        ("这个流程怎么走？", "PROCESS"),
        ("我该怎么开始？", "COLLECT"),
        ("BRD文档通常包含哪些内容？", "SEARCHING"),
    ]
    
    all_passed = True
    for user_input, expected in test_cases:
        response = await client.post(
            f"{BASE_URL}/api/tasks/classify",
            json={"user_input": user_input}
        )
        
        if response.status_code == 200:
            result = response.json()
            classification = result.get("classification")
            status = "✅" if classification == expected else "⚠️"
            print(f"  {status} Input: {user_input[:30]}... -> {classification} (expected: {expected})")
        else:
            print(f"  ❌ Failed: {response.status_code}")
            all_passed = False
    
    return all_passed


async def test_ui_generate(client: httpx.AsyncClient) -> bool:
    """Test UI_GEN_UI endpoint"""
    print("\n🎨 Testing UI_GEN_UI...")
    
    response = await client.post(
        f"{BASE_URL}/api/tasks/ui-generate",
        json={
            "user_input": "设计一个简单的登录表单，包含用户名和密码输入框",
            "is_screenshot": False
        },
        timeout=60.0
    )
    
    if response.status_code == 200:
        content = ""
        async for chunk in response.aiter_text():
            content += chunk
        
        # Check if HTML is generated
        if "<html" in content and "tailwind" in content.lower():
            print(f"  ✅ UI generated successfully ({len(content)} chars)")
            # Save to file for inspection
            with open("test_output_ui.html", "w", encoding="utf-8") as f:
                f.write(content)
            print(f"  📝 Saved to test_output_ui.html")
            return True
        else:
            print(f"  ⚠️ UI generated but may be incomplete")
            return False
    else:
        print(f"  ❌ Failed: {response.status_code}")
        return False


async def test_flowchart(client: httpx.AsyncClient) -> bool:
    """Test FLOWCHART endpoint"""
    print("\n📊 Testing FLOWCHART...")
    
    response = await client.post(
        f"{BASE_URL}/api/tasks/flowchart",
        json={
            "user_input": "保险理赔流程：客户提交申请 -> 系统初审 -> 人工审核 -> 批准或拒绝 -> 通知客户"
        },
        timeout=60.0
    )
    
    if response.status_code == 200:
        content = ""
        async for chunk in response.aiter_text():
            content += chunk
        
        # Check if Mermaid code is generated
        if "graph TD" in content or "flowchart" in content:
            print(f"  ✅ Flowchart generated successfully ({len(content)} chars)")
            # Save to file
            with open("test_output_flowchart.mmd", "w", encoding="utf-8") as f:
                f.write(content)
            print(f"  📝 Saved to test_output_flowchart.mmd")
            return True
        else:
            print(f"  ⚠️ Flowchart generated but may be incomplete")
            return False
    else:
        print(f"  ❌ Failed: {response.status_code}")
        return False


async def test_translate(client: httpx.AsyncClient) -> bool:
    """Test TRANSLATE endpoint"""
    print("\n🌐 Testing TRANSLATE...")
    
    test_content = """# 业务需求文档

## 1. 概述
本文档描述保险理赔系统的业务需求。

## 2. 流程
```mermaid
graph TD
    A[客户提交] --> B[系统审核]
    B --> C[完成]
```
"""
    
    response = await client.post(
        f"{BASE_URL}/api/tasks/translate",
        json={
            "document_content": test_content,
            "target_lang": "English"
        },
        timeout=60.0
    )
    
    if response.status_code == 200:
        content = ""
        async for chunk in response.aiter_text():
            content += chunk
        
        # Check if translation looks like English
        if "Business" in content or "Overview" in content or "Flow" in content:
            print(f"  ✅ Translation completed ({len(content)} chars)")
            with open("test_output_translate.md", "w", encoding="utf-8") as f:
                f.write(content)
            print(f"  📝 Saved to test_output_translate.md")
            return True
        else:
            print(f"  ⚠️ Translation may be incomplete")
            return False
    else:
        print(f"  ❌ Failed: {response.status_code}")
        return False


async def test_comment_edit(client: httpx.AsyncClient) -> bool:
    """Test COMMENT_EDIT endpoint"""
    print("\n✏️ Testing COMMENT_EDIT...")
    
    response = await client.post(
        f"{BASE_URL}/api/tasks/comment-edit",
        json={
            "selected_text": "系统将在3个工作日内完成审核",
            "user_comment": "改成1个工作日，体现效率",
            "doc_context": "# 审核流程\n系统将在3个工作日内完成审核，并通知用户结果。"
        },
        timeout=60.0
    )
    
    if response.status_code == 200:
        content = ""
        async for chunk in response.aiter_text():
            content += chunk
        
        if "1个工作日" in content or "1個工作日" in content:
            print(f"  ✅ Comment edit successful")
            print(f"  📝 Result: {content[:100]}...")
            return True
        else:
            print(f"  ⚠️ Edit may not have applied correctly")
            print(f"  📝 Result: {content[:100]}...")
            return False
    else:
        print(f"  ❌ Failed: {response.status_code}")
        return False


async def test_ui_edit(client: httpx.AsyncClient) -> bool:
    """Test UI_EDIT endpoint"""
    print("\n🖌️ Testing UI_EDIT...")
    
    original_html = """<div class="bg-blue-500 p-4 rounded">
    <button class="bg-white text-blue-500 px-4 py-2 rounded">提交</button>
</div>"""
    
    response = await client.post(
        f"{BASE_URL}/api/tasks/ui-edit",
        json={
            "original_html": original_html,
            "user_instruction": "把背景色改成红色，按钮改成大号"
        },
        timeout=60.0
    )
    
    if response.status_code == 200:
        content = ""
        async for chunk in response.aiter_text():
            content += chunk
        
        if "red" in content.lower() or "bg-red" in content:
            print(f"  ✅ UI edit successful")
            with open("test_output_ui_edit.html", "w", encoding="utf-8") as f:
                f.write(content)
            print(f"  📝 Saved to test_output_ui_edit.html")
            return True
        else:
            print(f"  ⚠️ UI edit may not have applied correctly")
            return False
    else:
        print(f"  ❌ Failed: {response.status_code}")
        return False


async def test_generate_title(client: httpx.AsyncClient) -> bool:
    """Test GEN_TITLE endpoint"""
    print("\n📌 Testing GEN_TITLE...")
    
    response = await client.post(
        f"{BASE_URL}/api/tasks/generate-title",
        json={
            "user_input": "帮我设计一个保险理赔的审批流程，需要包含初审和复审环节"
        }
    )
    
    if response.status_code == 200:
        result = response.json()
        title = result.get("title", "")
        print(f"  ✅ Title generated: {title}")
        return len(title) > 0 and len(title) <= 20
    else:
        print(f"  ❌ Failed: {response.status_code}")
        return False


async def test_websocket() -> bool:
    """Test WebSocket endpoint"""
    print("\n🔌 Testing WebSocket /ws/task...")
    
    try:
        import websockets
        
        uri = f"ws://localhost:8000/ws/task"
        
        async with websockets.connect(uri) as websocket:
            # Send task request
            await websocket.send(json.dumps({
                "task_type": "CLASSIFY",
                "user_input": "帮我画一个流程图"
            }))
            
            # Receive response
            response = await websocket.recv()
            data = json.loads(response)
            
            if data.get("type") == "complete":
                print(f"  ✅ WebSocket task completed")
                print(f"  📝 Result: {data.get('content', '')[:50]}...")
                return True
            else:
                print(f"  ⚠️ Unexpected response: {data}")
                return False
                
    except ImportError:
        print("  ⚠️ websockets library not installed, skipping WebSocket test")
        return True
    except Exception as e:
        print(f"  ❌ WebSocket test failed: {e}")
        return False


async def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("SDLC Agent Task API Test Suite")
    print("=" * 60)
    
    # First check if server is running
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{BASE_URL}/api/health")
            if response.status_code == 200:
                print(f"\n✅ Server is running: {response.json()}")
            else:
                print(f"\n⚠️ Server health check returned: {response.status_code}")
        except Exception as e:
            print(f"\n❌ Cannot connect to server at {BASE_URL}: {e}")
            print("Please start the server first: python -m web.app")
            return
    
    # Run tests
    results = {}
    
    async with httpx.AsyncClient(timeout=120.0) as client:
        # P0 Tests
        results["classify"] = await test_classify(client)
        results["ui_generate"] = await test_ui_generate(client)
        results["flowchart"] = await test_flowchart(client)
        
        # P1 Tests
        results["translate"] = await test_translate(client)
        results["comment_edit"] = await test_comment_edit(client)
        results["ui_edit"] = await test_ui_edit(client)
        results["generate_title"] = await test_generate_title(client)
        
    # WebSocket test
    results["websocket"] = await test_websocket()
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed!")
    else:
        print(f"\n⚠️ {total - passed} test(s) failed")


if __name__ == "__main__":
    asyncio.run(run_all_tests())
