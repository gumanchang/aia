export const fsdTemplateCN = `# 功能详细说明书 (FSD) - [项目名称]

**文档版本：** v1.0
**状态：** 草案 / 已评审 / 已批准
**项目负责人：** [姓名]
**日期：** 2026-01-22

---

## 1. 引言 (Introduction)

### 1.1 文档目的

描述 [项目名称] 的功能需求、用户界面设计及业务逻辑，为开发人员和测试人员提供执行准则。

### 1.2 背景与范围

本项目旨在为保险公司开发 [系统名称]（如：智能理赔辅助系统、代理人 RAG 知识库等），覆盖从投保/报案到 [闭环节点] 的全流程。

---

## 2. 业务流程与架构 (Business Process & Architecture)

### 2.1 业务流程图 (Workflow)

使用泳道图描述保险业务部门（如：核保部、理赔部、精算部）与系统之间的交互。

### 2.2 系统集成架构

描述本软件与保险公司现有系统（如：核心保单系统 Core System、客户关系管理 CRM、支付网关）的对接关系。

---

## 3. 功能需求详述 (Functional Requirements)

*建议使用表格形式，确保每一个功能点都有唯一的 ID 以供追踪。*

| 功能 ID | 功能模块 | 功能名称 | 详细描述 | 优先级 |
| --- | --- | --- | --- | --- |
| F01 | 身份核验 | KYC 自动化 | 集成 OCR 识别身份证/保单号，并对接内部数据库校验身份。 | 高 |
| F02 | 知识检索 | RAG 问答 | 基于 Azure AI Search 和企业内部条款文档，提供智能问答。 | 高 |
| F03 | 工作流 | Agent 自动分发 | 根据理赔类型（意外/医疗/重疾）自动路由给对应的调查员。 | 中 |

### 3.1 核心业务逻辑 (Core Business Rules)

这是 FSD 的灵魂，特别是保险领域：

* **核保/理赔规则：** 描述免赔额计算、等待期判断、保费计算公式。
* **AI Agent 逻辑：** 如果涉及 Agentic Flow，需定义每个节点的 Input/Output 规范、提示词策略（Prompt Strategy）及降级方案。

---

## 4. 数据需求 (Data Requirements)

### 4.1 数据字典

| 字段名称 | 类型 | 长度 | 约束/枚举值 | 说明 |
| --- | --- | --- | --- | --- |
| policy_no | String | 20 | 唯一，非空 | 保单号格式：POL-XXXXXX |
| claim_amount | Decimal | (18,2) | > 0 | 理赔申请金额 |

### 4.2 数据安全与隐私 (Privacy)

* **脱敏要求：** 对姓名、证件号、银行卡号在界面显示时进行掩码处理（如：3101**********1234）。
* **存储加密：** 遵循公司 Azure 环境的安全规范，对敏感 PII 数据进行静态加密。

---

## 5. 用户界面设计 (User Interface Design)

### 5.1 页面流转图

描述用户从登录页到核心操作页的操作路径。

### 5.2 关键界面原型

*此处应粘贴 UI 截图或 Wireframes。*

> **注：** 由于你正在研究使用 AI 生成 UI，建议在此处标注：**“该界面由 AI 辅助生成，遵循保险公司企业 VI 规范”**。

---

## 6. 接口与集成需求 (Interface Requirements)

### 6.1 内部接口 (Internal APIs)

* **核心系统调用：** 通过 RESTful API 获取实时保单状态。
* **向量数据库：** 与 Milvus 或 Azure AI Search 的数据同步频率及接口协议。

### 6.2 外部接口 (External APIs)

* **三立医院直连：** 获取电子病历数据。
* **银联/支付宝：** 理赔款秒到账接口。

---

## 7. 非功能性需求 (Non-Functional Requirements)

### 7.1 性能要求

* **响应时间：** RAG 问答首字返回时间（TTFT）需小于 2s，完整响应小于 10s。
* **并发：** 支持同时 500 名理赔员在线处理业务。

### 7.2 合规与审计 (Compliance & Audit)

* **操作审计：** 记录所有对保单数据的修改日志（Who, When, What）。
* **监管合规：** 满足当地保监会对自动化决策的可解释性要求。

---

## 8. 错误处理与日志 (Error Handling & Logging)

* **业务报错：** 针对“保单不存在”、“重复报案”等给出友好的中文提示。
* **技术报错：** LLM 幻觉检测失败或接口超时时的 fallback 机制（例如：转人工服务）。

---

## 9. 签署确认 (Sign-off)

* **业务方 (Business Owner)：** __________
* **架构师 (Architect)：** __________
* **合规官 (Compliance Officer)：** `;

export const fsdTemplateEN = `# Functional Specification Document (FSD) - [Project Name]

**Document Version:** v1.0
**Status:** Draft / Reviewed / Approved
**Project Lead:** [Name]
**Date:** 2026-01-22

---

## 1. Introduction

### 1.1 Document Purpose

Describe the functional requirements, user interface design, and business logic of [Project Name] to provide execution guidelines for developers and testers.

### 1.2 Background & Scope

This project aims to develop [System Name] (e.g., Intelligent Claims Assistant, Agent RAG Knowledge Base, etc.) for insurance companies, covering the entire process from application/report to [End Node].

---

## 2. Business Process & Architecture

### 2.1 Workflow Diagram

Describe the interaction between insurance business departments (e.g., Underwriting, Claims, Actuarial) and the system using swimlane diagrams.

### 2.2 System Integration Architecture

Describe the interface relationship between this software and existing insurance company systems (e.g., Core Policy System, CRM, Payment Gateway).

---

## 3. Functional Requirements

*It is recommended to use table format ensuring each functional point has a unique ID for tracking.*

| Func ID | Module | Name | Detailed Description | Priority |
| --- | --- | --- | --- | --- |
| F01 | ID Verification | Auto KYC | Integrate OCR for ID/Policy number recognition and verify identity against internal database. | High |
| F02 | Knowledge Retrieval | RAG Q&A | Provide intelligent Q&A based on Azure AI Search and internal policy documents. | High |
| F03 | Workflow | Agent Auto-dispatch | Automatically route to corresponding investigators based on claim type (Accident/Medical/Critical Illness). | Medium |

### 3.1 Core Business Logic

This is the soul of the FSD, especially in the insurance domain:

* **Underwriting/Claims Rules:** Describe deductible calculation, waiting period determination, premium calculation formulas.
* **AI Agent Logic:** If Agentic Flow is involved, define Input/Output specs, Prompt Strategy, and fallback plans for each node.

---

## 4. Data Requirements

### 4.1 Data Dictionary

| Field Name | Type | Length | Constraints / Enum | Description |
| --- | --- | --- | --- | --- |
| policy_no | String | 20 | Unique, Not Null | Policy format: POL-XXXXXX |
| claim_amount | Decimal | (18,2) | > 0 | Claim application amount |

### 4.2 Data Security & Privacy

* **Masking Requirements:** Mask names, ID numbers, and bank card numbers on the UI (e.g., 3101**********1234).
* **Storage Encryption:** Follow Azure security standards for encrypting sensitive PII data at rest.

---

## 5. User Interface Design

### 5.1 Page Flow Diagram

Describe the user operation path from login to core operation pages.

### 5.2 Key Interface Prototypes

*Paste UI screenshots or Wireframes here.*

> **Note:** Since you are using AI to generate UI, consider adding: **"This interface is AI-assisted and follows the insurance company's enterprise VI standards."**

---

## 6. Interface & Integration Requirements

### 6.1 Internal APIs

* **Core System Calls:** Retrieve real-time policy status via RESTful API.
* **Vector Database:** Data sync frequency and protocol with Milvus or Azure AI Search.

### 6.2 External APIs

* **Hospital Direct Link:** Retrieve electronic medical record data.
* **Payment Gateways:** Claims payout interface for instant arrival.

---

## 7. Non-Functional Requirements

### 7.1 Performance Requirements

* **Response Time:** RAG TTFT should be < 2s, full response < 10s.
* **Concurrency:** Support at least 500 online claims adjusters simultaneously.

### 7.2 Compliance & Audit

* **Operation Audit:** Log all modifications to policy data (Who, When, What).
* **Regulatory Compliance:** Meet local insurance regulatory requirements for explainable automated decision-making.

---

## 10. Error Handling & Logging

* **Business Errors:** Friendly error messages for "Policy not found", "Duplicate report", etc.
* **Technical Errors:** Fallback mechanisms for LLM hallucination or API timeout (e.g., transfer to human agent).

---

## 11. Sign-off

* **Business Owner:** __________
* **Architect:** __________
* **Compliance Officer:** __________ `;
