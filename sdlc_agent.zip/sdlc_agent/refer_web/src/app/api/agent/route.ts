import { NextResponse } from 'next/server';
import OpenAI from 'openai';
import promptsEnUS from '../../../lib/locales/prompts-en-US';
import promptsZhCN from '../../../lib/locales/prompts-zh-CN';
import { agentPromptsEnUS, agentPromptsZhCN } from '../../../lib/locales/agent-prompts';

// Initialize OpenAI client lazily to prevent build-time errors when env vars are missing
const isAzureOpenAI = !!process.env.AZURE_OPENAI_ENDPOINT;

const getClient = () => {
  if (isAzureOpenAI) {
    const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
    const apiKey = process.env.AZURE_OPENAI_API_KEY;
    const deployment = process.env.AZURE_OPENAI_DEPLOYMENT_NAME;
    const apiVersion = process.env.AZURE_OPENAI_API_VERSION;

    if (!endpoint || !apiKey || !deployment || !apiVersion) {
      console.warn('[API] Azure OpenAI environment variables are incomplete. Falling back to default OpenAI config.');
    } else {
      return new OpenAI({
        apiKey: apiKey || 'dummy-key-for-build',
        baseURL: `${endpoint}/openai/deployments/${deployment}`,
        defaultQuery: { 'api-version': apiVersion },
        defaultHeaders: { 'api-key': apiKey },
      });
    }
  }

  const apiKey = process.env.API_KEY;
  return new OpenAI({
    apiKey: apiKey || 'dummy-key-for-build',
    baseURL: process.env.BASE_URL,
  });
};

const MODEL_ID = isAzureOpenAI
  ? (process.env.AZURE_OPENAI_DEPLOYMENT_NAME || 'azure-deployment')
  : (process.env.MODEL_ID || 'gpt-3.5-turbo');

// System Prompts (loaded from i18n resources, switch by language)
export async function POST(request: Request) {
  try {
    const { userInput, messages, taskType, mermaidCode, originalHtml, userInstruction, targetLang, agentType, selectedText, userComment, docContext, searchResults, userQuestion, existingDocContent } = await request.json();

    // Detect language from targetLang or fallback to English
    const lang = (targetLang || '').toLowerCase();
    const useZh = lang.startsWith('zh') || lang === 'chinese' || lang === 'zh-cn';
    const PROMPTS = useZh ? promptsZhCN : promptsEnUS;
    const agentPrompts = useZh ? agentPromptsZhCN : agentPromptsEnUS;

    if (taskType !== 'UI_EDIT' && taskType !== 'COMMENT_EDIT' && taskType !== 'SEARCHING_ANSWER' && !userInput && (!messages || messages.length === 0)) {
      return NextResponse.json({ error: 'User input or messages are required' }, { status: 400 });
    }

    // Validate COMMENT_EDIT specific requirements
    if (taskType === 'COMMENT_EDIT' && (!selectedText || !userComment)) {
      return NextResponse.json({ error: 'Selected text and user comment are required for COMMENT_EDIT' }, { status: 400 });
    }

    // Determine if we need a Vision model
    const hasImages = messages?.some((m: any) =>
      Array.isArray(m.content) && m.content.some((c: any) => c.type === 'image_url')
    );

    let systemPrompt = PROMPTS[taskType as keyof typeof PROMPTS] || PROMPTS.GENERAL;

    // Determine language-specific FSD prompt
    if (taskType === 'BRD' && agentType === 'FSD') {
      const isEnglish = targetLang === 'English' || (messages && messages.length > 0 && messages[0].content?.includes('English'));
      console.log(`[API] Using FSD prompt. Language: ${isEnglish ? 'English' : 'Chinese'}`);
      systemPrompt = isEnglish ? PROMPTS.FSD_EN : PROMPTS.FSD;
    }

    // If we already have a BRD/FSD document on the page, inject it into the system prompt so the model refines/extends it
    if (taskType === 'BRD' && existingDocContent) {
      systemPrompt = `${systemPrompt}\n\n【Current Document Content】\n${existingDocContent}\n\n【Instruction】If the existing document already contains useful structure or content, refine and extend it instead of rewriting everything from scratch. Reuse headings and sections where appropriate.`;
    }

    // Use Screenshot Prompt if UI generation with images
    if (taskType === 'UI_GEN_UI' && hasImages) {
      console.log('[API] Using SCREENSHOT_UI prompt for Vision task');
      systemPrompt = PROMPTS.SCREENSHOT_UI;
    }

    // Use VISION_MODEL_ID if available and images are present, otherwise default model
    const selectedModel = (hasImages && process.env.VISION_MODEL_ID)
      ? process.env.VISION_MODEL_ID
      : MODEL_ID;

    console.log(`[API] Processing task: ${taskType} with model: ${selectedModel} (Vision: ${hasImages})`);

    // Construct messages for OpenAI
    let apiMessages: any[] = [];

    // Base System Prompt
    apiMessages.push({ role: 'system', content: systemPrompt });

    // Inject Mermaid Code Context for BRD task
    if (taskType === 'BRD' && mermaidCode) {
      apiMessages.push({
        role: 'system',
        content: `${agentPrompts.brdMermaidInstruction}\n\n\`\`\`mermaid\n${mermaidCode}\n\`\`\``
      });
    }

    // Inject Context for UI_EDIT task
    if (taskType === 'UI_EDIT') {
      apiMessages.push({
        role: 'user',
        content: `Original HTML:\n${originalHtml}\n\nUser Feedback:\n${userInstruction}`
      });
    }

    // Inject Context for COMMENT_EDIT task
    if (taskType === 'COMMENT_EDIT') {
      let editPrompt = `【Selected Text】\n${selectedText}\n\n【User Comment/Instruction】\n${userComment}`;
      if (docContext) {
        editPrompt += `\n\n【Surrounding Context for Reference】\n${docContext}`;
      }
      apiMessages.push({
        role: 'user',
        content: editPrompt
      });
    }

    if (taskType === 'TRANSLATE') {
      apiMessages[0].content += `\n\nTarget Language: ${targetLang || 'English'}`;
    }

    // Inject Context for SEARCHING_ANSWER task
    if (taskType === 'SEARCHING_ANSWER' && searchResults && userQuestion) {
      // Format search results for the prompt
      const formattedResults = searchResults
        .map((r: any, i: number) => `[${i + 1}] Title: ${r.title || 'Untitled'}\nScore: ${r.score?.toFixed(2) || 'N/A'}\nContent: ${r.content}`)
        .join('\n\n---\n\n');

      // Replace placeholders in the system prompt
      apiMessages[0].content = apiMessages[0].content
        .replace('{{SEARCH_RESULTS}}', formattedResults || 'No relevant results found.')
        .replace('{{USER_QUESTION}}', userQuestion);

      console.log(`[API] SEARCHING_ANSWER: ${searchResults.length} results for query: "${userQuestion.substring(0, 50)}..."`);
    }

    // Append history
    if (messages && messages.length > 0) {
      apiMessages = [...apiMessages, ...messages];
    } else if (userInput !== undefined) {
      const formattedInput = taskType === 'TRANSLATE' ? userInput : `需求描述：\n${userInput}`;
      apiMessages.push({ role: 'user', content: formattedInput });
    }

    // [FIX] For BRD task, ensure the last message is a USER instruction to trigger generation.
    // Since we pass the full history (ending with assistant), the model needs a specific command to start the BRD.
    if (taskType === 'BRD') {
      const docType = agentType === 'FSD' ? 'FSD' : 'BRD';
      const brdCommand = agentPrompts.brdGenerateDocCommand.replace('{docType}', docType);
      apiMessages.push({
        role: 'user',
        content: brdCommand
      });
    }

    // Stream for GENERAL (Chat), BRD (Document), UI_DESIGN (UI Pages), UI_EDIT, COLLECT, UI_GEN_UI, TRANSLATE, COMMENT_EDIT, and SEARCHING_ANSWER
    if (taskType === 'GENERAL' || taskType === 'BRD' || taskType === 'UI_DESIGN' || taskType === 'UI_EDIT' || taskType === 'UI_GEN_UI' || taskType === 'COLLECT' || taskType === 'TRANSLATE' || taskType === 'COMMENT_EDIT' || taskType === 'SEARCHING_ANSWER') {
      const encoder = new TextEncoder();
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const completion = await getClient().chat.completions.create({
              model: selectedModel,
              messages: apiMessages,
              temperature: 0.2, // Low temperature for precision
              stream: true,
            });

            for await (const chunk of completion) {
              const content = chunk.choices[0]?.delta?.content || '';
              if (content) {
                // console.log('[API] Chunk:', content.length, 'bytes'); // Debug log
                controller.enqueue(encoder.encode(content));
              }
            }
          } catch (error) {
            console.error('Stream error:', error);
            controller.error(error);
          } finally {
            controller.close();
          }
        },
      });

      return new NextResponse(stream, {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Transfer-Encoding': 'chunked',
        },
      });
    }

    // Non-streaming for Artifacts (FLOWCHART, RULES)
    const completion = await getClient().chat.completions.create({
      model: selectedModel,
      messages: apiMessages,
      temperature: 0.2,
    });

    const content = completion.choices[0]?.message?.content || '';

    return NextResponse.json({ content });

  } catch (error: any) {
    console.error('Error calling LLM:', error);
    return NextResponse.json({
      error: 'Failed to generate content',
      details: error.message
    }, { status: 500 });
  }
}