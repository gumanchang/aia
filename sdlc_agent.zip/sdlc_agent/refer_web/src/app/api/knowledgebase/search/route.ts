import { NextResponse } from 'next/server';

interface RetrievalRecord {
    content: string;
    title: string;
    score: number;
    metadata?: Record<string, any>;
}

interface RetrievalResponse {
    records: RetrievalRecord[];
}

// POST /api/knowledgebase/search - Search the external knowledge base
export async function POST(request: Request) {
    try {
        const { endpoint, apiKey, knowledgeId, query, topK = 5, scoreThreshold = 0.5 } = await request.json();

        if (!endpoint || !apiKey || !knowledgeId || !query) {
            return NextResponse.json(
                { error: 'Missing required fields: endpoint, apiKey, knowledgeId, query' },
                { status: 400 }
            );
        }

        // Call the external knowledge base API using Dify's External Knowledge API protocol
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                knowledge_id: knowledgeId,
                query: query,
                retrieval_setting: {
                    top_k: topK,
                    score_threshold: scoreThreshold,
                },
            }),
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('[Knowledgebase] External API error:', response.status, errorText);
            return NextResponse.json(
                { error: `External API returned ${response.status}: ${errorText}` },
                { status: response.status }
            );
        }

        const data: RetrievalResponse = await response.json();

        // Filter results by score threshold (in case external API doesn't filter)
        const filteredRecords = data.records?.filter(
            (record) => record.score >= scoreThreshold
        ) || [];

        console.log(`[Knowledgebase] Retrieved ${filteredRecords.length} records for query: "${query.substring(0, 50)}..."`);

        return NextResponse.json({
            records: filteredRecords,
            query,
            totalResults: filteredRecords.length,
        });

    } catch (error: any) {
        console.error('[Knowledgebase] Search error:', error);
        return NextResponse.json(
            { error: error.message || 'Failed to search knowledge base' },
            { status: 500 }
        );
    }
}
