import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// Helper to get API base URL at runtime
const getApiBase = () => `${process.env.BACKEND_URL || 'http://localhost:8000'}/api/v1`;

export async function GET(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session || !session.user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    const API_BASE = getApiBase();

    try {
        if (id) {
            // Fetch single item
            const res = await fetch(`${API_BASE}/brd/${id}`, { cache: 'no-store' });
            if (!res.ok) return NextResponse.json({ error: 'Not found' }, { status: 404 });

            const item = await res.json();

            // Re-inject ui_html into messages if it was stored externally
            let messagesData = JSON.parse(item.content_json || '{}');
            if (item.ui_html) {
                if (!messagesData.messages) {
                    // Fallback for old/simple formats
                    messagesData = { messages: messagesData, uiGenHtml: item.ui_html };
                } else {
                    messagesData.uiGenHtml = item.ui_html;
                }
            }

            return NextResponse.json({
                id: item.id,
                title: item.title,
                messages: JSON.stringify(messagesData),
                createdAt: item.created_at
            });
        }

        // Fetch user list
        const userId = (session.user as any).id || 1;
        const res = await fetch(`${API_BASE}/brd/user/${userId}`, {
            cache: 'no-store'
        });

        if (!res.ok) {
            console.error("Backend Error:", await res.text());
            return NextResponse.json([]);
        }

        const data = await res.json();

        // Map backend format to frontend expectation
        const history = data.map((item: any) => ({
            id: item.id,
            title: item.title,
            messages: item.content_json || '[]',
            createdAt: item.created_at
        }));

        return NextResponse.json(history);

    } catch (e) {
        console.error("History Fetch Error:", e);
        return NextResponse.json({ error: 'Failed' }, { status: 500 });
    }
}

export async function POST(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session || !session.user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const API_BASE = getApiBase();

    try {
        const { title, messages } = await req.json();
        const userId = (session.user as any).id || 1;

        const payload = {
            user_id: parseInt(userId),
            title: title || 'New Session',
            description: 'Saved from Web Agent',
            content_json: typeof messages === 'string' ? messages : JSON.stringify(messages)
        };

        const res = await fetch(`${API_BASE}/brd/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!res.ok) {
            throw new Error(await res.text());
        }

        const newBrd = await res.json();
        return NextResponse.json({
            id: newBrd.id,
            title: newBrd.title,
            messages: newBrd.content_json,
            createdAt: newBrd.created_at
        });

    } catch (e) {
        console.error("History Save Error:", e);
        return NextResponse.json({ error: 'Failed' }, { status: 500 });
    }
}

export async function PUT(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session || !session.user) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const API_BASE = getApiBase();

    try {
        const { id, title, messages } = await req.json();

        if (!id) {
            return NextResponse.json({ error: 'Missing session ID' }, { status: 400 });
        }

        const userId = (session.user as any).id || 1;

        const payload = {
            user_id: parseInt(userId),
            title: title || 'Updated Session',
            description: 'Saved from Web Agent',
            content_json: typeof messages === 'string' ? messages : JSON.stringify(messages)
        };

        const res = await fetch(`${API_BASE}/brd/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!res.ok) {
            throw new Error(await res.text());
        }

        const updatedBrd = await res.json();
        return NextResponse.json({
            id: updatedBrd.id,
            title: updatedBrd.title,
            messages: updatedBrd.content_json,
            createdAt: updatedBrd.created_at
        });

    } catch (e) {
        console.error("History Update Error:", e);
        return NextResponse.json({ error: 'Failed' }, { status: 500 });
    }
}