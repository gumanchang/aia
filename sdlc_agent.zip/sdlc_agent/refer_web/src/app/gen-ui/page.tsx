"use client";
import { CopilotProviderWrapper } from "@/components/CopilotProviderWrapper";
import { CopilotSidebar } from "@copilotkit/react-ui";
import { GenUiContainer } from "@/components/gen-ui/GenUiContainer";

export default function GenUiPage() {
    return (
        <CopilotProviderWrapper>
            <CopilotSidebar
                defaultOpen={true}
                instructions="You are an expert Insurance Dashboard Designer. Use the 'generateInsuranceDashboard' tool to build UIs."
                labels={{
                    title: "UI Designer Agent",
                    initial: "Hello! I can design dashboards for you. Try saying 'Create a sales dashboard'."
                }}
            >
                <div className="flex h-screen w-full bg-white">
                    {/* Main Content Area */}
                    <div className="flex-1 p-8 overflow-y-auto">
                        <div className="max-w-7xl mx-auto">
                            <h1 className="text-3xl font-bold text-slate-800 mb-2">Copilot Generative UI Demo</h1>
                            <p className="text-slate-500 mb-8">
                                This page demonstrates component-based UI generation. The AI modifies React state directly instead of writing HTML strings.
                            </p>

                            <GenUiContainer />
                        </div>
                    </div>
                </div>
            </CopilotSidebar>
        </CopilotProviderWrapper>
    );
}