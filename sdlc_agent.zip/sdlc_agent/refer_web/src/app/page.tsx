'use client';

import React, { useState, useRef, useEffect } from 'react';
import html2canvas from 'html2canvas';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useTranslation } from 'react-i18next';
import { findSourceRange, replaceByPosition } from '@/lib/markdownAstMapper';
import { cn, extractMermaidCode, svgToBase64Png } from '@/lib/utils';
import { Message, HistoryItem } from '@/types';
import { fsdTemplateCN, fsdTemplateEN } from '@/lib/templates';

// Components
import HistorySidebar from '@/components/HistorySidebar';
import ChatInterface from '@/components/Chat/ChatInterface';
import ArtifactsPanel from '@/components/Artifacts/ArtifactsPanel';
import { LayoutSchema } from "@/components/layout-ui";

import mermaid from 'mermaid'; // Needed for svgToBase64Png / download logic when calling verify/render


export default function Home() {
  const { t, i18n } = useTranslation();
  const { data: session, status } = useSession();
  const router = useRouter();

  // --- State ---
  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [agentType, setAgentType] = useState<'BRD' | 'FSD'>('BRD');

  // Artifacts State
  const [activeTab, setActiveTab] = useState<'doc' | 'flow' | 'ui' | 'kb' | 'audio'>('doc');
  const [docContent, setDocContent] = useState<string>(''); // Will be set in useEffect
  const [savedDocContent, setSavedDocContent] = useState<string>('');
  const [flowchart, setFlowchart] = useState<string>('');
  const [uiHtml, setUiHtml] = useState<string>('');
  const [uiPages, setUiPages] = useState<string[]>([]);
  const [uiGenHtml, setUiGenHtml] = useState<string>('');
  const [layoutSchema, setLayoutSchema] = useState<LayoutSchema | null>(null);
  const [isUiGenerating, setIsUiGenerating] = useState(false);
  const [uiGenCharCount, setUiGenCharCount] = useState(0); // Kept for potential progress bar
  const [mermaidAttempts, setMermaidAttempts] = useState<Record<string, number>>({});
  const globalMermaidRetryCount = useRef(0); // Global retry counter (max 3)
  const [audioUploadMessageIds, setAudioUploadMessageIds] = useState<Record<string, string>>({});
  const [sessionTranscriptIds, setSessionTranscriptIds] = useState<string[]>([]);

  // Doc Editing State
  const [isEditingDoc, setIsEditingDoc] = useState(false);
  const [commentEditMode, setCommentEditMode] = useState(false);
  const [selectedText, setSelectedText] = useState('');
  const [selectionRange, setSelectionRange] = useState<{ start: number; end: number } | null>(null);
  const [commentInput, setCommentInput] = useState('');
  const [isCommentEditing, setIsCommentEditing] = useState(false);
  const [showCommentPopup, setShowCommentPopup] = useState(false);
  const docContentRef = useRef<HTMLDivElement>(null);

  // History State
  const [showHistory, setShowHistory] = useState(false);
  const [historyList, setHistoryList] = useState<HistoryItem[]>([]);
  const [currentSessionTitle, setCurrentSessionTitle] = useState<string | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const lastSavedContentRef = useRef<string | null>(null);

  // Translate State
  const [isTranslating, setIsTranslating] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Toast 状态与工具函数
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<number | null>(null);

  const showToast = (message: string) => {
    if (toastTimeoutRef.current) {
      window.clearTimeout(toastTimeoutRef.current);
    }
    setToastMessage(message);
    toastTimeoutRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const fsdTemplate = i18n.language.startsWith('zh') ? fsdTemplateCN : fsdTemplateEN;

  const loadShortBrdTemplate = async () => {
    try {
      const res = await fetch('/brd_templates/brd_template_test.md');
      if (!res.ok) {
        console.error('Failed to load short BRD template', res.status);
        setDocContent(t('docs.defaultContent'));
        return;
      }
      const text = await res.text();
      setDocContent(text);
    } catch (e) {
      console.error('Error loading short BRD template', e);
      setDocContent(t('docs.defaultContent'));
    }
  };

  const isSessionEmpty = React.useMemo(() => {
    return (messages.length <= 1 &&
      docContent === t('docs.defaultContent')) ||
      (messages.length <= 1 && docContent === fsdTemplate && agentType === 'FSD') ||
      (!flowchart && !uiGenHtml && messages.length <= 1);
  }, [messages, docContent, flowchart, uiGenHtml, t, agentType, fsdTemplate]);

  // --- Effects ---

  // Auth check
  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
  }, [status, router]);

  // Fetch history
  useEffect(() => {
    if (session?.user) fetchHistory();
  }, [session]);

  // Scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  useEffect(scrollToBottom, [messages]);

  // Initial Message & Default Content
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ id: 'init-1', role: 'assistant', content: t('chat.welcome') }]);
    } else if (messages.length === 1 && messages[0].id === 'init-1') {
      setMessages([{ id: 'init-1', role: 'assistant', content: t('chat.welcome') }]);
    }
  }, [i18n.language, t]);

  useEffect(() => {
    if (isSessionEmpty) {
      if (agentType === 'FSD') {
        setDocContent(fsdTemplate);
        setSavedDocContent(fsdTemplate);
      } else {
        void loadShortBrdTemplate();

      }
    }
  }, [i18n.language, agentType, isSessionEmpty, t, fsdTemplate]);


  // Parse UI HTML
  useEffect(() => {
    if (uiHtml && !isLoading) {
      const parser = new DOMParser();
      const doc = parser.parseFromString(uiHtml, 'text/html');
      const pages = Array.from(doc.body.getElementsByClassName('page-container')).map(el => el.outerHTML);
      if (pages.length > 0) setUiPages(pages);
      else if (uiHtml.trim()) setUiPages([uiHtml]);
    }
  }, [uiHtml, isLoading]);

  // --- Handlers ---

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/history');
      if (res.ok) setHistoryList(await res.json());
    } catch (e) {
      console.error("Failed to fetch history");
    }
  };

  const handleSave = async () => {
    if (isSessionEmpty) return;

    // Build current content for comparison
    const currentContent = JSON.stringify({ messages, docContent, flowchart, uiHtml, uiGenHtml });

    // Check if there are any changes compared to last saved content
    if (lastSavedContentRef.current && lastSavedContentRef.current === currentContent) {
      alert(t('history.noChanges') || 'No changes to save');
      return;
    }

    setIsLoading(true);
    try {
      let title = currentSessionTitle || t('history.sessionDefault', { time: new Date().toLocaleString() });
      const firstUserMsg = messages.find(m => m.role === 'user');

      if (!currentSessionTitle && firstUserMsg) {
        try {
          const res = await fetch('/api/agent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ taskType: 'GEN_TITLE', userInput: firstUserMsg.content })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.content) title = data.content.trim().substring(0, 20);
          }
        } catch (e) { console.warn("Title Gen Error", e); }
      }

      const payload = {
        id: currentSessionId, // Include session ID if exists
        title,
        messages: { messages, docContent, flowchart, uiHtml, uiGenHtml }
      };

      // Use PUT if updating existing session, POST if creating new
      const method = currentSessionId ? 'PUT' : 'POST';
      const res = await fetch('/api/history', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Failed to save');

      const savedData = await res.json();

      // Update session ID and title from response
      if (savedData.id) {
        setCurrentSessionId(savedData.id);
      }

      // Update last saved content reference
      lastSavedContentRef.current = currentContent;

      fetchHistory();
      setCurrentSessionTitle(title);
    } catch (e: any) {
      alert(t('history.saveFailed', { error: e.message }));
    } finally {
      setIsLoading(false);
    }
  };

  const loadHistory = async (item: HistoryItem) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/history?id=${item.id}`);
      if (!res.ok) throw new Error("Failed");
      const fullItem = await res.json();
      const data = JSON.parse(fullItem.messages);

      if (data.messages && Array.isArray(data.messages)) {
        setMessages(data.messages);
        setDocContent(data.docContent || '');
        setSavedDocContent(data.docContent || '');
        setFlowchart(data.flowchart || '');
        setUiHtml(data.uiHtml || '');
        setUiGenHtml(data.uiGenHtml || data.uiHtml || '');
        setActiveTab('doc');
        setAudioUploadMessageIds({});
        setSessionTranscriptIds([]);

        // Store the loaded content as last saved reference
        lastSavedContentRef.current = JSON.stringify({
          messages: data.messages,
          docContent: data.docContent || '',
          flowchart: data.flowchart || '',
          uiHtml: data.uiHtml || '',
          uiGenHtml: data.uiGenHtml || data.uiHtml || ''
        });
      } else {
        setMessages(data);
        setAudioUploadMessageIds({});
        setSessionTranscriptIds([]);
        // For old format, just store the messages
        lastSavedContentRef.current = JSON.stringify({ messages: data, docContent: '', flowchart: '', uiHtml: '', uiGenHtml: '' });
      }

      // Set current session ID and title for future saves (update instead of create)
      setCurrentSessionId(fullItem.id);
      setCurrentSessionTitle(fullItem.title);
      setShowHistory(false);
    } catch (e) {
      alert(t('history.loadFailed'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewSession = () => {
    if (isSessionEmpty) return;
    if (confirm(t('chat.newSessionConfirm'))) {
      setMessages([{ id: 'init-1', role: 'assistant', content: t('chat.welcome') }]);
      if (agentType === 'FSD') {
        setDocContent(fsdTemplate);
      } else {
        void loadShortBrdTemplate();
      }

      setFlowchart('');
      setUiHtml('');
      setUiGenHtml('');
      setUiPages([]);
      setLayoutSchema(null);
      setInput('');
      setSelectedImage(null);
      setActiveTab('doc');
      setIsEditingDoc(false);
      setCurrentSessionTitle(null);
      setCurrentSessionId(null);  // Clear session ID so next save creates new record
      lastSavedContentRef.current = null;  // Clear last saved content reference
      setAudioUploadMessageIds({});
      setSessionTranscriptIds([]);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Check if it's a WAV file
    if (file.name.toLowerCase().endsWith('.wav') || file.type.startsWith('audio/')) {
      // Handle WAV file upload for transcription
      if (file.size > 50 * 1024 * 1024) {
        alert(t('messages.fileSizeError') || 'File size cannot exceed 50MB');
        return;
      }
      setIsLoading(true);
      const uploadingMsgId = Date.now().toString();
      setMessages(prev => [...prev, {
        id: uploadingMsgId,
        role: 'assistant',
        content: t('audioTranscript.transcribing')
      }]);
      try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('language', 'zh-CN');
        const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:8000';
        const res = await fetch(`${BACKEND_URL}/api/v1/audio/transcripts/upload`, {
          method: 'POST',
          body: formData,
        });
        if (res.ok) {
          const data = await res.json();
          setMessages(prev => prev.map(m =>
            m.id === uploadingMsgId
              ? { ...m, content: t('audioTranscript.transcribing') + `\n\n📁 ${file.name}` }
              : m
          ));
          if (data && (data as any).id) {
            const transcriptId = (data as any).id as string;
            setAudioUploadMessageIds(prev => ({
              ...prev,
              [transcriptId]: uploadingMsgId,
            }));
            setSessionTranscriptIds(prev => [...prev, transcriptId]);
          }
          // Switch to audio tab to see the result
          setActiveTab('audio');
        } else {
          const errorData = await res.json();
          setMessages(prev => prev.map(m =>
            m.id === uploadingMsgId
              ? { ...m, content: t('audioTranscript.transcribeFailed', { error: errorData.detail || 'Unknown error' }) }
              : m
          ));
        }
      } catch (error) {
        setMessages(prev => prev.map(m =>
          m.id === uploadingMsgId
            ? { ...m, content: t('audioTranscript.transcribeFailed', { error: String(error) }) }
            : m
        ));
      } finally {
        setIsLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
      return;
    }
    // Handle image files
    if (file.size > 5 * 1024 * 1024) {
      alert(t('messages.imageSizeError'));
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => setSelectedImage(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    for (const item of items) {
      if (item.type.indexOf('image') !== -1) {
        const file = item.getAsFile();
        if (file) {
          const reader = new FileReader();
          reader.onloadend = () => setSelectedImage(reader.result as string);
          reader.readAsDataURL(file);
        }
      }
    }
  };

  // --- Logic Handlers (Send, etc.) ---

  const handleMessageFeedbackChange = async (messageId: string | undefined, index: number, feedback: 'like' | 'dislike') => {
    // 1. 先更新本地 messages（保证 UI 立即响应）
    const newMessages = messages.map((m, i) =>
      i === index ? { ...m, feedback } : m
    );
    setMessages(newMessages);

    // 当前内容快照，用于后面更新 lastSavedContentRef
    const currentContent = JSON.stringify({
      messages: newMessages,
      docContent,
      flowchart,
      uiHtml,
      uiGenHtml,
    });

    try {
      // 2. 如果还没有 sessionId，说明是第一次保存：自动创建并保存 session
      if (!currentSessionId) {
        let title = currentSessionTitle || t('history.sessionDefault', { time: new Date().toLocaleString() });
        const firstUserMsg = newMessages.find(m => m.role === 'user');

        // 尝试自动生成一个更合适的标题（与 handleSave 保持一致）
        if (!currentSessionTitle && firstUserMsg) {
          try {
            const res = await fetch('/api/agent', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ taskType: 'GEN_TITLE', userInput: firstUserMsg.content })
            });
            if (res.ok) {
              const data = await res.json();
              if (data.content) title = data.content.trim().substring(0, 20);
            }
          } catch (e) {
            console.warn('Title Gen Error (auto-save on feedback)', e);
          }
        }

        const payload = {
          title,
          messages: {
            messages: newMessages,
            docContent,
            flowchart,
            uiHtml,
            uiGenHtml,
          },
        };

        const res = await fetch('/api/history', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (!res.ok) throw new Error('Failed to auto-save session on feedback');

        const savedData = await res.json();

        if (savedData.id) {
          setCurrentSessionId(savedData.id);
        }
        setCurrentSessionTitle(title);
        lastSavedContentRef.current = currentContent;

        // 轻量提示：自动保存成功，反馈已记录（非阻塞 toast）
        showToast(t('history.autoSavedOnFeedback', { defaultValue: 'Session auto-saved and feedback recorded.' }));

        // 刷新左侧历史列表
        fetchHistory();
        return;
      }

      // 3. 已经有 sessionId：更新当前 session，将 feedback 一并持久化
      const payload = {
        id: currentSessionId,
        title: currentSessionTitle || t('history.sessionDefault', { time: new Date().toLocaleString() }),
        messages: {
          messages: newMessages,
          docContent,
          flowchart,
          uiHtml,
          uiGenHtml,
        },
      };

      const res = await fetch('/api/history', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error('Failed to persist message feedback');
      }

      // 与手动保存行为保持一致，更新最后一次保存内容
      lastSavedContentRef.current = currentContent;
    } catch (e) {
      console.error('Failed to persist message feedback', e);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && !selectedImage) || isLoading) return;
    const userMsg = input;
    const currentImage = selectedImage;

    setInput('');
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';

    const newMsg: Message = { role: 'user', content: userMsg };
    if (currentImage) newMsg.imageUrl = currentImage;

    const newMessages = [...messages, newMsg];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const historyPayload = newMessages.map(m => {
        if (m.imageUrl) {
          return {
            role: m.role,
            content: [
              { type: 'text', text: typeof m.content === 'string' ? m.content : ' ' },
              { type: 'image_url', image_url: { url: m.imageUrl } }
            ]
          };
        }
        return { role: m.role, content: m.content };
      });

      // Classify
      console.log('[HandleSend] Classifying intent...');
      const thinkingId = Date.now().toString();
      setMessages(prev => [...prev, { id: thinkingId, role: 'assistant', content: t('chat.thinking') }]);

      const classifyPayload = historyPayload.slice(-2); // simplified

      const classifyRes = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userInput: userMsg,
          messages: classifyPayload,
          taskType: 'CLASSIFY'
        }),
      });

      const classifyJson = await classifyRes.json();
      let classification = 'PROCESS';
      try {
        const cleanJson = classifyJson.content.replace(/```json/g, '').replace(/```/g, '').trim();
        const result = JSON.parse(cleanJson);
        classification = result.classification || 'PROCESS';
      } catch (e) {
        if (classifyJson.content.includes('UI')) classification = 'UI';
        else if (classifyJson.content.includes('BRD')) classification = 'BRD';
      }

      console.log('[HandleSend] Intent:', classification);
      setMessages(prev => prev.filter(m => m.id !== thinkingId));

      const streamResponse = async (
        taskType: string,
        contextMessages: any[],
        onChunk: (text: string) => void,
        extraPayload: Record<string, any> = {}
      ) => {
        const response = await fetch('/api/agent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: contextMessages,
            taskType,
            agentType,
            ...extraPayload,
          }),
        });
        if (!response.body) throw new Error('No response body');
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullText = '';
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          fullText += chunk;
          onChunk(fullText);
        }
        return fullText;
      };

      if (classification === 'UI') {
        setActiveTab('ui');
        const ackId = Date.now().toString();
        setUiGenHtml('');
        setLayoutSchema(null);
        setMessages(prev => [...prev, { id: ackId, role: 'assistant', content: t('chat.generatingUi') }]);

        const uiContextMessages = [
          ...historyPayload,
          { role: 'system', content: `[Context Injection] Current BRD document content: \n\n${docContent}` }
        ];

        setIsUiGenerating(true);
        setUiGenCharCount(0);
        let finalHtml = '';

        await streamResponse('UI_GEN_UI', uiContextMessages, (text) => {
          setUiGenCharCount(text.length);
          const htmlStartIndex = text.search(/<!DOCTYPE|<html/i);
          if (htmlStartIndex !== -1) {
            let htmlContent = text.substring(htmlStartIndex);
            const htmlEndRegex = /<\/html>/i;
            const endMatch = htmlContent.match(htmlEndRegex);
            if (endMatch && endMatch.index !== undefined) {
              const endIndex = endMatch.index + endMatch[0].length;
              htmlContent = htmlContent.substring(0, endIndex);
            }
            // 仅保留完整的 HTML 文档给 UI 画布使用，<html> 标签外的内容全部丢弃
            finalHtml = htmlContent;
            // 更新一下提示语，但不再把 HTML 外的内容写回聊天框
            setMessages(prev => prev.map(m => m.id === ackId ? { ...m, content: t('chat.uiInProgress') } : m));
          }
        });

        setUiGenHtml(finalHtml);
        setUiHtml(finalHtml); // 同步更新 uiHtml，触发 useEffect 解析 UI 页面
        setIsUiGenerating(false);
        setMessages(prev => {
          const currentMsg = prev.find(m => m.id === ackId);
          const inProgressWording = [t('chat.uiInProgress'), t('chat.generatingUi'), t('genUi.generatingTitle')];
          const finalContent = (!currentMsg?.content || inProgressWording.includes(currentMsg.content as string))
            ? t('chat.uiComplete') : currentMsg.content;
          return prev.map(m => m.id === ackId ? { ...m, content: finalContent } : m);
        });

      } else if (classification === 'BRD') {
        setActiveTab('doc');
        const ackId = Date.now().toString();
        setMessages(prev => [...prev, { id: ackId, role: 'assistant', content: t('chat.generatingBrd') }]);

        const brdContextMessages = [
          ...historyPayload,
          { role: 'system', content: `[Context Injection] Current Mermaid flowchart: \n\n\`\`\`mermaid\n${flowchart}\n\`\`\`` }
        ];

        setDocContent(t('common.loading'));
        await streamResponse(
          'BRD',
          brdContextMessages,
          (text) => setDocContent(text),
          { existingDocContent: savedDocContent || docContent }
        );
        setMessages(prev => prev.map(m => m.id === ackId ? { ...m, content: t('chat.brdComplete') } : m));

      } else if (classification === 'SEARCHING') {
        const msgId = Date.now().toString();
        setMessages(prev => [...prev, { id: msgId, role: 'assistant', content: t('knowledgebase.searching') }]);
        const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:8000';

        const searchRes = await fetch(`${BACKEND_URL}/api/v1/knowledgebase/search`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: userMsg }),
        });
        const records = await searchRes.json();
        if (!searchRes.ok) throw new Error(records.detail || 'Search failed');

        if (records.length === 0) {
          setMessages(prev => prev.map(m => m.id === msgId ? { ...m, content: t('knowledgebase.noResults') } : m));
        } else {
          const response = await fetch('/api/agent', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ taskType: 'SEARCHING_ANSWER', searchResults: records, userQuestion: userMsg }),
          });
          const reader = response.body!.getReader();
          const decoder = new TextDecoder();
          let fullText = '';
          while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            fullText += decoder.decode(value, { stream: true });
            setMessages(prev => prev.map(m => m.id === msgId ? { ...m, content: fullText } : m));
          }
        }
      } else {
        // PROCESS
        setActiveTab('flow');
        const msgId = Date.now().toString();
        setMessages(prev => [...prev, { id: msgId, role: 'assistant', content: t('chat.generatingFlow') }]);

        let fullContent = '';
        await streamResponse('GENERAL', historyPayload, (text) => {
          fullContent = text;
          setMessages(prev => prev.map(m => m.id === msgId ? { ...m, content: text } : m));
        });

        const mermaid = extractMermaidCode(fullContent);
        if (mermaid) setFlowchart(mermaid);
      }

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'assistant', content: t('chat.errorOccurred') }]);
    } finally {
      setIsLoading(false);
    }
  };

  // --- Sub-component Handlers ---

  const handleUiUpdate = async (index: number, content: string, mode: 'instruction' | 'code' = 'instruction') => {
    if (mode === 'code') {
      setUiPages(prev => {
        const newPages = [...prev];
        newPages[index] = content;
        setUiHtml(newPages.join('\n\n'));
        return newPages;
      });
      return;
    }
    // AI instruction
    const originalHtml = uiPages[index];
    try {
      const res = await fetch('/api/agent', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskType: 'UI_EDIT', originalHtml, userInstruction: content, messages: [] })
      });
      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let fullText = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        fullText += decoder.decode(value, { stream: true });
        setUiPages(prev => {
          const newPages = [...prev];
          newPages[index] = fullText;
          return newPages;
        });
      }
      setUiHtml(prev => prev); // sync if needed, for save we use uiPages join mostly
      setUiPages(prev => {
        setUiHtml(prev.join('\n\n'));
        return prev;
      });

    } catch (e) {
      alert(t('operationFailed'));
    }
  };

  const handleMermaidError = async (errorMsg: string, failedCode: string) => {
    // Global limit: max 3 total attempts regardless of code changes
    if (globalMermaidRetryCount.current >= 3) return;
    globalMermaidRetryCount.current += 1;

    const currentAttempt = (mermaidAttempts[failedCode] || 0) + 1;
    if (currentAttempt > 5) return;

    try {
      const res = await fetch('/api/agent', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskType: 'FIX_MERMAID', userInput: `Error: ${errorMsg}\nCode: ${failedCode}` })
      });
      const data = await res.json();
      const fixedCode = extractMermaidCode(data.content);

      if (fixedCode && fixedCode !== failedCode) {
        setMermaidAttempts(prev => ({ ...prev, [fixedCode]: currentAttempt }));
        setDocContent(prev => prev.replace(failedCode, fixedCode));
        setFlowchart(prev => (prev === failedCode || prev.trim() === failedCode.trim()) ? fixedCode : prev);
      }
    } catch (e) { console.error(e); }
  };

  const handleTranslate = async (targetLang: 'Chinese' | 'English') => {
    if (!docContent || isLoading || isTranslating) return;

    setIsTranslating(true);
    const originalContent = docContent;

    // 显示“翻译中”占位文案
    setDocContent(t('docs.translating'));
    setSavedDocContent(t('docs.translating'));

    try {
      const res = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskType: 'TRANSLATE', userInput: originalContent, targetLang })
      });

      if (!res.body) {
        throw new Error('No response body');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      // 清空后开始流式写入结果
      setDocContent('');
      setSavedDocContent('');

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        fullText += chunk;

        // 实时更新编辑区和预览内容
        setDocContent(fullText);
        setSavedDocContent(fullText);
      }
    } catch (e) {
      // 出错时恢复原文，避免出现空白页面
      setDocContent(originalContent);
      setSavedDocContent(originalContent);
      alert(t('operationFailed'));
    } finally {
      setIsTranslating(false);
    }
  };

  const handleDownload = async (option: 'text' | 'image' | 'both') => {
    if (!docContent) { alert(t('docs.emptyDoc')); return; }
    setIsLoading(true);
    try {
      let imageBase64: string | null = null;
      if (option === 'image' || option === 'both') {
        const code = flowchart || extractMermaidCode(docContent);
        if (code) {
          mermaid.initialize({ startOnLoad: false, theme: 'neutral' });
          const id = `mermaid-export-${Date.now()}`;
          const { svg } = await mermaid.render(id, code);
          imageBase64 = await svgToBase64Png(svg);
        }
      }
      const res = await fetch('/api/convert', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markdown_content: docContent, flowchart_option: option, flowchart_image: imageBase64 })
      });
      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `requirements_${option}.docx`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      } else {
        alert(t('docs.generateDocError', { error: await res.text() }));
      }
    } catch (e: any) { alert(t('docs.downloadError', { error: e.message })); }
    finally { setIsLoading(false); }
  };

  const handleInsertUiToBrd = async () => {
    // Check for available UI content: uiGenHtml, uiHtml, or joined uiPages
    const htmlContent = uiGenHtml || uiHtml || (uiPages.length > 0 ? uiPages.join('\n\n') : '');
    if (!htmlContent) { alert(t('ui.insertFailed')); return; }
    setIsLoading(true);
    try {
      const CAPTURE_WIDTH = 1280; const CAPTURE_HEIGHT = 900;
      const tempContainer = document.createElement('div');
      tempContainer.style.cssText = `position: fixed; left: -9999px; top: 0; width: ${CAPTURE_WIDTH}px; height: ${CAPTURE_HEIGHT}px; overflow: hidden; z-index: -1; visibility: hidden;`;
      document.body.appendChild(tempContainer);

      const tempIframe = document.createElement('iframe');
      tempIframe.style.cssText = `width: ${CAPTURE_WIDTH}px; height: ${CAPTURE_HEIGHT}px; border: none;`;
      tempIframe.sandbox.add('allow-scripts', 'allow-same-origin');
      tempContainer.appendChild(tempIframe);

      await new Promise<void>((resolve, reject) => {
        tempIframe.onload = () => resolve();
        tempIframe.onerror = () => reject(new Error("Failed to load temp iframe"));
        tempIframe.srcdoc = htmlContent;
      });

      const tempDoc = tempIframe.contentDocument;
      if (!tempDoc) throw new Error(t('ui.accessError'));
      if (tempDoc.fonts?.ready) await tempDoc.fonts.ready;
      // Wait for fonts and any async rendering
      await new Promise(r => setTimeout(r, 500));
      // Get actual content dimensions from the iframe body
      const body = tempDoc.body;
      const actualHeight = Math.max(body.scrollHeight, body.offsetHeight, 600);
      const actualWidth = Math.max(body.scrollWidth, body.offsetWidth, CAPTURE_WIDTH);
      // Resize iframe to actual content size
      tempIframe.style.width = `${actualWidth}px`;
      tempIframe.style.height = `${actualHeight}px`;
      tempContainer.style.width = `${actualWidth}px`;
      tempContainer.style.height = `${actualHeight}px`;
      // Wait for resize to take effect
      await new Promise(r => setTimeout(r, 100));
      const canvas = await html2canvas(body, {
        useCORS: true, allowTaint: true, logging: false, backgroundColor: '#ffffff',
        width: actualWidth, height: actualHeight, windowWidth: actualWidth, windowHeight: actualHeight, scale: 2,
        onclone: (clonedDoc) => {
          const style = clonedDoc.createElement('style');
          style.innerHTML = `*, *::before, *::after { transition: none !important; animation: none !important; }`;
          clonedDoc.head.appendChild(style);
        }
      });
      document.body.removeChild(tempContainer);
      const dataUrl = canvas.toDataURL('image/png');
      const uploadRes = await fetch('/api/upload', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: dataUrl })
      });
      if (!uploadRes.ok) throw new Error(t('ui.uploadFailed'));
      const { url } = await uploadRes.json();

      setDocContent(prev => {
        const sectionHeader = t('ui.section2');
        const insertContent = `\n\n### ${t('ui.typicalUi')}\n\n![Typical UI](${url})`;
        if (prev.includes(sectionHeader)) {
          const sectionIndex = prev.indexOf(sectionHeader);
          const regex = /\n## /g;
          regex.lastIndex = sectionIndex + sectionHeader.length;
          const nextSectionMatch = regex.exec(prev);
          if (nextSectionMatch) {
            return prev.slice(0, nextSectionMatch.index) + insertContent + prev.slice(nextSectionMatch.index);
          }
          return prev + insertContent;
        }
        return prev + `\n\n${sectionHeader}${insertContent}`;
      });
      alert(t('ui.insertSuccess', { type: agentType }));
    } catch (e: any) {
      alert(t('ui.screenshotFailed', { error: e.message }));
    } finally { setIsLoading(false); }
  };

  // Comment Edit Handlers
  const handleTextSelection = () => {
    if (!commentEditMode) return;
    const selection = window.getSelection();
    const text = selection?.toString().trim();
    if (text && text.length >= 2) {
      setSelectedText(text); setShowCommentPopup(true); selection?.removeAllRanges();
    }
  };

  const handleCommentEdit = async () => {
    if (!selectedText || !commentInput.trim()) { alert(t('docs.noTextSelected')); return; }
    setIsCommentEditing(true);
    try {
      const sourceRange = findSourceRange(docContent, selectedText);
      if (!sourceRange) { alert(t('docs.commentEditError', { error: 'Could not locate text' })); return; }

      const res = await fetch('/api/agent', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskType: 'COMMENT_EDIT', selectedText: sourceRange.sourceText, userComment: commentInput, docContext: docContent })
      });
      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let editedText = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        editedText += decoder.decode(value, { stream: true });
      }

      const newDocContent = replaceByPosition(docContent, sourceRange.start, sourceRange.end, editedText.trim());
      setDocContent(newDocContent);
      cancelCommentEdit();
    } catch (e) {
      alert(t('docs.commentEditError', { error: String(e) }));
    } finally { setIsCommentEditing(false); }
  };

  const cancelCommentEdit = () => {
    setCommentEditMode(false); setSelectedText(''); setSelectionRange(null);
    setCommentInput(''); setShowCommentPopup(false);
  };

  if (status === 'loading') return <div className="flex h-screen w-full items-center justify-center bg-slate-50 text-slate-400">Loading...</div>;
  if (!session) return null;

  return (
    <main className={cn(
      "flex h-screen w-full font-sans overflow-hidden transition-colors duration-500",
      isDarkMode ? "bg-slate-950 text-slate-100 dark" : "bg-slate-50 text-slate-800"
    )}>
      <HistorySidebar
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        isDarkMode={isDarkMode}
        historyList={historyList}
        onLoadHistory={loadHistory}
      />

      {!(isEditingDoc && activeTab === 'doc') && (
        <ChatInterface
          isDarkMode={isDarkMode}
          messages={messages}
          input={input}
          setInput={setInput}
          onSend={handleSend}
          isLoading={isLoading}
          selectedImage={selectedImage}
          onRemoveImage={() => { setSelectedImage(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          onFileSelect={handleFileSelect}
          fileInputRef={fileInputRef}
          onPaste={handlePaste}
          agentType={agentType}
          onAgentTypeChange={type => {
            setAgentType(type);
            if (isSessionEmpty) {
              if (type === 'FSD') {
                setDocContent(fsdTemplate);
              } else {
                void loadShortBrdTemplate();
              }
            }
          }}
          onNewSession={handleNewSession}
          isSessionEmpty={isSessionEmpty}
          onSave={handleSave}
          onShowHistory={() => setShowHistory(true)}
          user={session.user}
          messagesEndRef={messagesEndRef}
          onMessageFeedbackChange={handleMessageFeedbackChange}
        />
      )}


      <ArtifactsPanel
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isLoading={isLoading}
        docContent={docContent}
        setDocContent={setDocContent}
        isEditingDoc={isEditingDoc}
        setIsEditingDoc={setIsEditingDoc}
        commentEditMode={commentEditMode}
        setCommentEditMode={setCommentEditMode}
        onTextSelection={handleTextSelection}
        showCommentPopup={showCommentPopup}
        selectedText={selectedText}
        commentInput={commentInput}
        setCommentInput={setCommentInput}
        isCommentEditing={isCommentEditing}
        onCommentEdit={handleCommentEdit}
        onCancelCommentEdit={cancelCommentEdit}
        docContentRef={docContentRef}
        isTranslating={isTranslating}
        onTranslate={handleTranslate}
        onDownload={handleDownload}
        flowchart={flowchart}
        mermaidAttempts={mermaidAttempts}
        onMermaidError={handleMermaidError}
        uiGenHtml={uiGenHtml}
        uiPages={uiPages}
        layoutSchema={layoutSchema}
        isUiGenerating={isUiGenerating}
        onUiUpdate={handleUiUpdate}
        onInsertUiToBrd={handleInsertUiToBrd}
        onDocSave={(content) => setSavedDocContent(content)}
        agentType={agentType}
        sessionTranscriptIds={sessionTranscriptIds}
        onTranscriptDone={(item) => {
          setMessages(prev => {
            const uploadMsgId = audioUploadMessageIds[item.id];
            if (!uploadMsgId) {
              return prev;
            }
            return prev.map(m =>
              m.id === uploadMsgId
                ? { ...m, content: t('audioTranscript.transcribeComplete') }
                : m
            );
          });
        }}
        onInsertTranscriptToChat={(text) => {
          setInput(prev => (prev ? `${prev}\n\n${text}` : text));
        }}
      />

      {toastMessage && (
        <div className="fixed bottom-4 right-4 z-50">
          <div className="px-3 py-2 rounded-md shadow-md text-xs bg-slate-900 text-white/90">
            {toastMessage}
          </div>
        </div>
      )}
    </main>
  );
}