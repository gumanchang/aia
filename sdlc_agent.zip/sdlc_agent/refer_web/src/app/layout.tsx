import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SDLC Agent",
  description: "AI-Powered Business Requirement Document Assistant",
};

import SessionWrapper from "@/components/SessionWrapper";
import I18nProvider from "@/components/I18nProvider";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${inter.variable} font-sans antialiased`}
      >
        <I18nProvider>
          <SessionWrapper>
            {children}
          </SessionWrapper>
        </I18nProvider>
      </body>
    </html>
  );
}
