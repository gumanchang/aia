# SDLC Agent - 快速开始指南

## 📋 项目概述

SDLC Agent 是一个智能需求文档撰写系统，支持：
- **BRD** (Business Requirements Document) - 业务需求文档
- **FDS** (Functional Design Specification) - 功能设计规格
- **SRS** (Software Requirements Specification) - 软件需求规格
- **PRD** (Product Requirements Document) - 产品需求文档
- **自定义模板**

## 🚀 快速启动

### Windows
```bash
start.bat
```

### Linux/Mac
```bash
chmod +x start.sh
./start.sh
```

### 手动启动
```bash
cd sdlc_agent
pip install -r requirements.txt
python main.py
```

## ⚙️ 配置

### 1. 设置 LLM API Key

复制环境变量模板：
```bash
cp sdlc_agent/.env.example sdlc_agent/.env
```

编辑 `.env` 文件，填入你的 API Key：
```env
LLM_API_KEY=your_api_key_here
LLM_API_URL=https://api.openai.com/v1
LLM_MODEL=gpt-4o
```

支持的 LLM 提供商：
- OpenAI (GPT-4, GPT-4o)
- Moonshot AI (Kimi)
- 其他 OpenAI 兼容的 API

### 2. 访问系统

启动后，在浏览器中打开：
- 主界面: http://localhost:8000
- API文档: http://localhost:8000/docs

## 📖 使用指南

### 1. 创建新文档

1. 在右侧选择模板类型（如 FDS）
2. 在底部输入框描述你的需求
3. 可选：点击回形针图标上传参考文件
4. 点击发送按钮
5. 等待文档生成完成

### 2. 支持的文件类型

- **PDF** (.pdf) - 会自动提取文本内容
- **Word** (.docx) - 支持段落和表格
- **Excel** (.xlsx, .xls) - 支持多工作表
- **图片** (.jpg, .png, .gif) - 用于多模态分析
- **文本** (.txt, .md)

### 3. 多轮对话修改

1. 在左侧聊天历史中选择已有会话
2. 在输入框中描述修改要求
3. 系统会基于上一轮文档进行修改

### 4. 查看流程图和UI设计

- **Document**: 查看完整文档
- **Flowchart**: 查看提取的流程图 (Mermaid)
- **UI Design**: 查看UI设计图 (HTML)
- **Knowledge Base**: 查看历史文档

### 5. 导出文档

点击预览区域右上角的按钮：
- 📥 下载 Markdown (.md)
- 🌐 下载 HTML (.html) - 包含渲染的流程图
- 📋 复制到剪贴板

## 📁 项目结构

```
sdlc_agent/
├── core/                       # 核心模块
│   ├── template_manager.py    # 模板管理
│   ├── file_processor.py      # 文件处理（PDF/DOCX/图片等）
│   ├── llm_client.py          # LLM客户端（流式输出）
│   ├── document_generator.py  # 文档生成引擎
│   ├── knowledge_base.py      # 知识库（本地存储）
│   └── session_manager.py     # 会话管理（多轮对话）
├── web/                        # Web层
│   ├── app.py                 # FastAPI主应用
│   └── templates/
│       └── index.html         # 前端界面
├── static/                     # 静态资源
│   ├── css/style.css          # 样式表
│   └── js/app.js              # 前端逻辑
├── templates/                  # 文档模板（在项目根目录）
│   ├── brd_template.md
│   ├── fds_template.md
│   ├── srs_template.md
│   └── feature_template.md
├── uploads/                    # 上传文件临时存储
├── knowledge_base/            # 知识库存储
├── generated_docs/            # 生成文档存储
├── config.py                  # 配置文件
├── main.py                    # 入口文件
└── requirements.txt           # 依赖包
```

## 🔧 高级功能

### 模板管理

1. 点击左侧 "Template Management"
2. 查看现有模板
3. 创建新模板：
   - 模板名称（如: CUSTOM）
   - Markdown 格式内容
   - 使用 `{{placeholder}}` 作为占位符

### 自定义模板示例

```markdown
# {{document_title}}

## 1. 概述
### 1.1 目的
{{purpose}}

## 2. 功能需求
{{functional_requirements}}

## 3. 流程图
<!-- 系统会自动在此插入 Mermaid 流程图 -->

## 4. UI 设计
<!-- 系统会自动在此插入 HTML UI 设计 -->
```

### API 使用

生成文档（HTTP）:
```bash
curl -X POST http://localhost:8000/api/documents/generate \
  -F "doc_type=FDS" \
  -F "requirements=创建一个用户登录模块的FDS文档" \
  -F "files=@reference.pdf"
```

WebSocket 流式生成:
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/generate');
ws.send(JSON.stringify({
    doc_type: 'FDS',
    requirements: '创建用户登录模块文档',
    session_id: null
}));
```

## 🐛 故障排除

### 问题：无法启动
- 检查 Python 版本 (>=3.8)
- 检查依赖是否安装完整: `pip install -r requirements.txt`
- 检查端口 8000 是否被占用

### 问题：LLM 不响应
- 检查 `.env` 中的 API Key 是否正确
- 检查 API URL 是否可访问
- 查看控制台错误信息

### 问题：文件上传失败
- 检查文件大小（最大 50MB）
- 检查文件类型是否在支持列表中
- 查看 `uploads/` 目录是否有写入权限

### 问题：流程图不显示
- 检查网络连接（需要加载 Mermaid CDN）
- 刷新页面或点击刷新按钮
- 检查浏览器控制台是否有 JS 错误

## 📚 更多资源

- [完整 README](./sdlc_agent/README.md)
- [API 文档](http://localhost:8000/docs) (启动后访问)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 License

MIT License
