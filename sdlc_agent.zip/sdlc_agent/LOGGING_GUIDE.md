# SDLC Agent - 日志查看指南

## 📋 日志配置

系统已配置日志输出，日志会同时输出到：
1. **终端/控制台** - 实时查看
2. **日志文件** - `sdlc_agent/logs/sdlc_agent.log`

## 🔍 查看日志

### 方式1：终端实时查看
启动服务后，日志会直接输出在终端：
```bash
cd sdlc_agent
python main.py
```

输出示例：
```
2024-01-15 10:30:25 | INFO     | sdlc_agent | SDLC Agent starting...
2024-01-15 10:30:25 | INFO     | sdlc_agent | Directories initialized
2024-01-15 10:30:25 | INFO     | sdlc_agent | LLM_API_KEY is configured
2024-01-15 10:30:25 | INFO     | sdlc_agent | Environment check passed
2024-01-15 10:30:25 | INFO     | sdlc_agent | Loaded 4 templates
2024-01-15 10:30:25 | INFO     | sdlc_agent | Starting server at 0.0.0.0:8000
```

### 方式2：查看日志文件
```bash
# 查看最新日志
tail -f sdlc_agent/logs/sdlc_agent.log

# 查看完整日志
cat sdlc_agent/logs/sdlc_agent.log

# Windows 使用 PowerShell
Get-Content sdlc_agent/logs/sdlc_agent.log -Tail 50
```

### 方式3：调试模式（更详细日志）
修改 `.env` 文件：
```env
DEBUG=True
```

或在启动时设置环境变量：
```bash
# Linux/Mac
DEBUG=True python main.py

# Windows
set DEBUG=True
python main.py
```

## 📊 日志级别

| 级别 | 说明 | 使用场景 |
|------|------|----------|
| DEBUG | 调试信息 | 详细的处理步骤 |
| INFO | 一般信息 | 主要操作记录 |
| WARNING | 警告 | 需要注意的问题 |
| ERROR | 错误 | 处理失败的操作 |

## 📝 常见日志输出

### 文档生成流程
```
INFO  | web | Generating FDS document, session: new
INFO  | web | Processing 2 uploaded files
DEBUG | web | File processed: requirement.pdf, content length: 15420
INFO  | web | Starting document generation stream for session xxx
INFO  | web | Stream completed: 156 chunks, total length 8542
INFO  | web | Document saved to knowledge base, doc_id: xxx
```

### WebSocket 连接
```
INFO  | web | WebSocket connection established for document generation
INFO  | web | WS Generate request: doc_type=FDS, session=new, files=1
INFO  | web | Starting document generation stream for session xxx
INFO  | web | Stream completed: 156 chunks, total length 8542
INFO  | web | WebSocket disconnected
```

## 🔧 故障排查

### 问题：终端没有日志输出
1. 检查是否在 `main.py` 中正确导入了日志模块
2. 检查 `core/logger.py` 是否存在
3. 尝试删除 `__pycache__` 目录后重新启动

### 问题：日志文件没有生成
1. 检查 `sdlc_agent/logs/` 目录是否有写权限
2. 检查磁盘空间是否充足
3. 查看终端是否有错误提示

### 问题：日志中有乱码（Windows）
在 PowerShell 中设置编码：
```powershell
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
python main.py
```

## 🎨 自定义日志格式

修改 `core/logger.py` 中的 `format_string`：
```python
format_string = (
    "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
)
```

可用字段：
- `%(asctime)s` - 时间
- `%(levelname)s` - 日志级别
- `%(name)s` - 模块名
- `%(message)s` - 消息内容
- `%(filename)s` - 文件名
- `%(lineno)d` - 行号
