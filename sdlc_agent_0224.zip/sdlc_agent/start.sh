#!/bin/bash

echo ""
echo "============================================"
echo "     SDLC Agent - Document Generator"
echo "============================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    exit 1
fi

# Check if virtual environment exists, if not create it
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install requirements
echo "Installing dependencies..."
pip install -q -r sdlc_agent/requirements.txt

# Check if .env file exists
if [ ! -f "sdlc_agent/.env" ]; then
    echo ""
    echo "WARNING: .env file not found!"
    echo "Please copy .env.example to .env and configure your LLM API key."
    echo ""
    read -p "Press Enter to continue..."
fi

# Start the application
echo ""
echo "Starting SDLC Agent..."
echo "Access the application at: http://localhost:8000"
echo ""

cd sdlc_agent
python main.py
