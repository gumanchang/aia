"""
SDLC Agent - Main Entry Point

Requirements Document Writing System
Supports: BRD, FDS, SRS, PRD and custom templates
"""
import os
import sys
import argparse
import uvicorn
import logging

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import settings
from core.logger import setup_logging, get_logger

# Setup logging
logger = setup_logging(
    level=logging.INFO if not settings.DEBUG else logging.DEBUG,
    log_file=os.path.join(settings.BASE_DIR, "logs", "sdlc_agent.log")
)


def print_banner():
    """Print application banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════╗
    ║                                                          ║
    ║              SDLC AGENT - Document Generator             ║
    ║                                                          ║
    ║  Requirements Document Writing System                    ║
    ║  Supports: BRD, FDS, SRS, PRD and custom templates       ║
    ║                                                          ║
    ╚══════════════════════════════════════════════════════════╝
    """
    print(banner)
    logger.info("SDLC Agent starting...")


def check_environment():
    """Check if all required environment variables are set"""
    issues = []
    
    if not settings.LLM_API_KEY:
        issues.append("⚠️  LLM_API_KEY not set. Set it via environment variable or .env file")
        logger.warning("LLM_API_KEY not set")
    else:
        logger.info("LLM_API_KEY is configured")
    
    if issues:
        print("\nEnvironment Check:")
        for issue in issues:
            print(f"  {issue}")
        print()
        return False
    
    logger.info("Environment check passed")
    return True


def setup_directories():
    """Create necessary directories"""
    dirs = [
        settings.UPLOADS_DIR,
        settings.KNOWLEDGE_BASE_DIR,
        settings.GENERATED_DOCS_DIR,
        os.path.join(settings.BASE_DIR, "sessions"),
        os.path.join(settings.BASE_DIR, "logs"),
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        logger.debug(f"Directory ensured: {d}")
    
    print(f"✓ Directories initialized")
    logger.info("Directories initialized")


def list_templates():
    """List all available templates"""
    from core.template_manager import template_manager
    
    print("\nAvailable Templates:")
    print("-" * 50)
    
    templates = template_manager.list_templates()
    for t in templates:
        print(f"  • {t['doc_type']}: {t['description']}")
    
    logger.info(f"Loaded {len(templates)} templates")
    print()


def run_server(host: str = "0.0.0.0", port: int = 8000, reload: bool = False):
    """Run the FastAPI server"""
    # Use localhost for display/access URLs, but keep host for binding
    display_host = "localhost" if host == "0.0.0.0" else host
    print(f"\n🚀 Starting server at http://{display_host}:{port}")
    print(f"   API Documentation: http://{display_host}:{port}/docs")
    print(f"   Web Interface: http://{display_host}:{port}/")
    print()
    
    logger.info(f"Starting server at {host}:{port} (access via http://{display_host}:{port})")
    
    uvicorn.run(
        "web.app:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info"
    )


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="SDLC Agent - Requirements Document Writing System"
    )
    
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Server host (default: 0.0.0.0)"
    )
    
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Server port (default: 8000)"
    )
    
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development"
    )
    
    parser.add_argument(
        "--templates",
        action="store_true",
        help="List available templates and exit"
    )
    
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check environment and exit"
    )
    
    args = parser.parse_args()
    
    print_banner()
    
    if args.check:
        check_environment()
        setup_directories()
        list_templates()
        return
    
    if args.templates:
        list_templates()
        return
    
    # Normal startup
    setup_directories()
    check_environment()
    list_templates()
    run_server(args.host, args.port, args.reload)


if __name__ == "__main__":
    main()
