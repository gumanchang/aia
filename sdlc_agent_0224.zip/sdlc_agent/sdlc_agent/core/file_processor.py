"""
File Processor - Handles various file types for multimodal input
"""
import os
import base64
import io
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from pathlib import Path
import tempfile

try:
    from PyPDF2 import PdfReader
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

try:
    from docx import Document
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False

try:
    from openpyxl import load_workbook
    EXCEL_SUPPORT = True
except ImportError:
    EXCEL_SUPPORT = False

try:
    from PIL import Image
    IMAGE_SUPPORT = True
except ImportError:
    IMAGE_SUPPORT = False

from config import settings


@dataclass
class ProcessedFile:
    """Represents a processed file"""
    filename: str
    file_type: str
    content: str
    images: List[Dict[str, Any]]  # Base64 encoded images for multimodal
    metadata: Dict[str, Any]
    raw_path: Optional[str] = None


class FileProcessor:
    """Processes various file types for multimodal LLM input"""
    
    def __init__(self, upload_dir: str = None):
        self.upload_dir = upload_dir or settings.UPLOADS_DIR
        os.makedirs(self.upload_dir, exist_ok=True)
    
    async def process_file(self, file_content: bytes, filename: str, content_type: str) -> ProcessedFile:
        """Process a file and extract its content"""
        
        # Save file temporarily
        temp_path = os.path.join(self.upload_dir, filename)
        with open(temp_path, 'wb') as f:
            f.write(file_content)
        
        try:
            # Route to appropriate processor
            if content_type in settings.SUPPORTED_IMAGE_TYPES:
                return await self._process_image(temp_path, filename, content_type)
            elif content_type == "application/pdf":
                return await self._process_pdf(temp_path, filename)
            elif content_type in ["application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                 "application/msword"]:
                return await self._process_docx(temp_path, filename)
            elif content_type in ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                 "application/vnd.ms-excel"]:
                return await self._process_excel(temp_path, filename)
            elif content_type in ["text/plain", "text/markdown"]:
                return await self._process_text(temp_path, filename)
            else:
                # Try to process as text
                return await self._process_text(temp_path, filename)
        
        except Exception as e:
            return ProcessedFile(
                filename=filename,
                file_type=content_type,
                content=f"[Error processing file: {str(e)}]",
                images=[],
                metadata={"error": str(e)},
                raw_path=temp_path
            )
    
    async def _process_image(self, file_path: str, filename: str, content_type: str) -> ProcessedFile:
        """Process image files - extract for multimodal input"""
        # Read and encode image to base64
        with open(file_path, 'rb') as f:
            image_data = f.read()
        
        base64_image = base64.b64encode(image_data).decode('utf-8')
        
        # Get image info
        width, height = 0, 0
        if IMAGE_SUPPORT:
            try:
                with Image.open(file_path) as img:
                    width, height = img.size
            except:
                pass
        
        return ProcessedFile(
            filename=filename,
            file_type=content_type,
            content=f"[Image: {filename} ({width}x{height})]",
            images=[{
                "type": "image_url",
                "image_url": {
                    "url": f"data:{content_type};base64,{base64_image}"
                }
            }],
            metadata={
                "width": width,
                "height": height,
                "size": len(image_data)
            },
            raw_path=file_path
        )
    
    async def _process_pdf(self, file_path: str, filename: str) -> ProcessedFile:
        """Process PDF files - extract text and images"""
        if not PDF_SUPPORT:
            return ProcessedFile(
                filename=filename,
                file_type="application/pdf",
                content="[PDF processing not available - PyPDF2 not installed]",
                images=[],
                metadata={},
                raw_path=file_path
            )
        
        try:
            reader = PdfReader(file_path)
            text_content = []
            
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text:
                    text_content.append(f"--- Page {i + 1} ---\n{text}")
            
            full_text = "\n\n".join(text_content)
            
            return ProcessedFile(
                filename=filename,
                file_type="application/pdf",
                content=full_text,
                images=[],  # PyPDF2 doesn't extract images easily, would need pdf2image
                metadata={
                    "pages": len(reader.pages),
                    "title": reader.metadata.get('/Title', ''),
                    "author": reader.metadata.get('/Author', '')
                },
                raw_path=file_path
            )
        
        except Exception as e:
            return ProcessedFile(
                filename=filename,
                file_type="application/pdf",
                content=f"[Error reading PDF: {str(e)}]",
                images=[],
                metadata={"error": str(e)},
                raw_path=file_path
            )
    
    async def _process_docx(self, file_path: str, filename: str) -> ProcessedFile:
        """Process DOCX files - extract text"""
        if not DOCX_SUPPORT:
            return ProcessedFile(
                filename=filename,
                file_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                content="[DOCX processing not available - python-docx not installed]",
                images=[],
                metadata={},
                raw_path=file_path
            )
        
        try:
            doc = Document(file_path)
            
            # Extract text from paragraphs
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            
            # Extract text from tables
            tables_text = []
            for table in doc.tables:
                table_rows = []
                for row in table.rows:
                    row_text = [cell.text for cell in row.cells]
                    table_rows.append(" | ".join(row_text))
                tables_text.append("\n".join(table_rows))
            
            full_text = "\n\n".join(paragraphs)
            if tables_text:
                full_text += "\n\n[Tables]\n" + "\n\n".join(tables_text)
            
            return ProcessedFile(
                filename=filename,
                file_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                content=full_text,
                images=[],  # Could extract images with additional processing
                metadata={
                    "paragraphs": len(paragraphs),
                    "tables": len(doc.tables)
                },
                raw_path=file_path
            )
        
        except Exception as e:
            return ProcessedFile(
                filename=filename,
                file_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                content=f"[Error reading DOCX: {str(e)}]",
                images=[],
                metadata={"error": str(e)},
                raw_path=file_path
            )
    
    async def _process_excel(self, file_path: str, filename: str) -> ProcessedFile:
        """Process Excel files - extract data"""
        if not EXCEL_SUPPORT:
            return ProcessedFile(
                filename=filename,
                file_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                content="[Excel processing not available - openpyxl not installed]",
                images=[],
                metadata={},
                raw_path=file_path
            )
        
        try:
            wb = load_workbook(file_path, data_only=True)
            
            sheets_content = []
            for sheet_name in wb.sheetnames:
                sheet = wb[sheet_name]
                rows = []
                
                for row in sheet.iter_rows(values_only=True):
                    row_data = [str(cell) if cell is not None else "" for cell in row]
                    rows.append(" | ".join(row_data))
                
                sheet_content = f"--- Sheet: {sheet_name} ---\n" + "\n".join(rows)
                sheets_content.append(sheet_content)
            
            full_text = "\n\n".join(sheets_content)
            
            return ProcessedFile(
                filename=filename,
                file_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                content=full_text,
                images=[],
                metadata={
                    "sheets": len(wb.sheetnames),
                    "sheet_names": wb.sheetnames
                },
                raw_path=file_path
            )
        
        except Exception as e:
            return ProcessedFile(
                filename=filename,
                file_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                content=f"[Error reading Excel: {str(e)}]",
                images=[],
                metadata={"error": str(e)},
                raw_path=file_path
            )
    
    async def _process_text(self, file_path: str, filename: str) -> ProcessedFile:
        """Process text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return ProcessedFile(
                filename=filename,
                file_type="text/plain",
                content=content,
                images=[],
                metadata={
                    "length": len(content),
                    "lines": content.count('\n')
                },
                raw_path=file_path
            )
        
        except UnicodeDecodeError:
            # Try with different encoding
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    content = f.read()
                
                return ProcessedFile(
                    filename=filename,
                    file_type="text/plain",
                    content=content,
                    images=[],
                    metadata={
                        "length": len(content),
                        "lines": content.count('\n'),
                        "encoding": "latin-1"
                    },
                    raw_path=file_path
                )
            except Exception as e:
                return ProcessedFile(
                    filename=filename,
                    file_type="text/plain",
                    content=f"[Error reading file: {str(e)}]",
                    images=[],
                    metadata={"error": str(e)},
                    raw_path=file_path
                )
    
    def cleanup(self, file_path: str):
        """Clean up a processed file"""
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except:
            pass


# Global file processor instance
file_processor = FileProcessor()
