# SDLC Agent - Requirements Document Writing System

A comprehensive system for generating requirements documents (BRD, FDS, SRS, PRD) using multimodal LLMs.

## Features

- **Document Generation**: Generate BRD, FDS, SRS, PRD documents based on user requirements
- **Multimodal Input**: Support text, PDF, DOCX, Excel, and image inputs
- **Flowchart Generation**: Automatically generate Mermaid flowcharts in relevant sections
- **UI Design**: Generate HTML-based UI design mockups
- **Template Management**: Upload and manage custom document templates
- **Multi-turn Conversation**: Iteratively refine documents through conversation
- **Knowledge Base**: Store and retrieve generated documents
- **Streaming Output**: Real-time document generation with WebSocket

## Architecture

```
sdlc_agent/
├── core/
│   ├── template_manager.py      # Document template management
│   ├── file_processor.py        # Multi-format file processing
│   ├── llm_client.py            # LLM API client with streaming
│   ├── document_generator.py    # Document generation engine
│   ├── knowledge_base.py        # Local document storage
│   └── session_manager.py       # Multi-turn session management
├── web/
│   ├── app.py                   # FastAPI web application
│   └── templates/
│       └── index.html           # Web UI
├── static/
│   ├── css/
│   │   └── style.css            # Stylesheet
│   └── js/
│       └── app.js               # Frontend logic
├── templates/                   # Document templates
│   ├── brd_template.md
│   ├── fds_template.md
│   ├── srs_template.md
│   └── feature_template.md
├── config.py                    # Configuration
├── main.py                      # Entry point
└── requirements.txt             # Dependencies
```

## Quick Start

### 1. Install Dependencies

```bash
cd sdlc_agent
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and add your LLM API key
```

### 3. Run the Application

```bash
python main.py
```

Or with custom options:

```bash
python main.py --host 0.0.0.0 --port 8080 --reload
```

### 4. Access the Web Interface

Open your browser and go to: http://localhost:8000

## Usage

### Creating a New Document

1. Select a template (BRD, FDS, SRS, PRD, etc.)
2. Describe your requirements in the chat input
3. Optionally attach reference files (PDF, DOCX, images)
4. Click send and wait for the document to be generated

### Modifying a Document

1. Select an existing session from the chat history
2. Enter your modification request
3. The system will generate an updated document based on the previous version

### Managing Templates

1. Click "Template Management" in the left sidebar
2. View existing templates or upload new ones
3. Templates must be in Markdown format with `{{placeholder}}` syntax

### Exporting Documents

- **Markdown**: Download as `.md` file
- **HTML**: Download as `.html` with rendered Mermaid diagrams

## API Endpoints

### Document Generation
- `POST /api/documents/generate` - Generate document (HTTP)
- `WS /ws/generate` - Generate document (WebSocket, streaming)

### Document Modification
- `POST /api/documents/modify` - Modify document (HTTP)
- `WS /ws/modify` - Modify document (WebSocket, streaming)

### Templates
- `GET /api/templates` - List all templates
- `GET /api/templates/{doc_type}` - Get specific template
- `POST /api/templates/upload` - Upload new template

### Sessions
- `GET /api/sessions` - List all sessions
- `GET /api/sessions/{session_id}` - Get session details
- `GET /api/sessions/{session_id}/history` - Get conversation history
- `DELETE /api/sessions/{session_id}` - Delete session

### Knowledge Base
- `GET /api/knowledge-base/documents` - List documents
- `GET /api/documents/{doc_id}` - Get document
- `GET /api/documents/{doc_id}/export?format=md|html` - Export document

## Template Format

Templates are Markdown files with placeholders:

```markdown
# {{document_title}}

## 1. Introduction
### 1.1 Purpose
{{purpose_description}}

## 2. Requirements
{{requirements_list}}
```

Placeholders use `{{variable_name}}` syntax and will be filled by the LLM.

## Configuration

Environment variables (can be set in `.env` file):

| Variable | Description | Default |
|----------|-------------|---------|
| `LLM_API_KEY` | LLM API key | - |
| `LLM_API_URL` | LLM API endpoint | https://api.openai.com/v1 |
| `LLM_MODEL` | Model name | gpt-4o |
| `LLM_TEMPERATURE` | Temperature | 0.7 |
| `LLM_MAX_TOKENS` | Max tokens | 4096 |
| `DEBUG` | Debug mode | True |

## Supported File Types

- **Documents**: PDF, DOCX, TXT, MD
- **Spreadsheets**: XLSX, XLS
- **Images**: JPG, JPEG, PNG, GIF, WEBP

## Development

### Running in Development Mode

```bash
python main.py --reload
```

### Project Structure Guidelines

- `core/` - Core business logic, no web dependencies
- `web/` - Web layer, FastAPI routes
- `static/` - Static assets (CSS, JS)
- `templates/` - Document templates

### Adding New Templates

1. Create a `.md` file in `templates/`
2. Use `{name}_template.md` naming convention
3. Include placeholders using `{{variable}}` syntax
4. The system will automatically load it

## License

MIT License
