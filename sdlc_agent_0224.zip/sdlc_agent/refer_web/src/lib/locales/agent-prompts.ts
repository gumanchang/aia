const agentPromptsEnUS = {
    brdMermaidInstruction:
      '【Important Instruction】Please embed the following Mermaid flowchart code completely into section "2. Specific Requirements -> Business Process" of the BRD document:',
    brdGenerateDocCommand:
      'Based on the above conversation and following the system prompt format requirements, please write a complete document.',
  };
  
  const agentPromptsZhCN = {
    brdMermaidInstruction:
      '【重要指令】请将以下 Mermaid 流程图代码完整地嵌入到 BRD 文档的「2. 具体需求 -> 业务流程」章节中：',
    brdGenerateDocCommand:
      '请根据上述对话内容，按照系统提示的格式要求，编写完整的文档。',
  };
  
  export { agentPromptsEnUS, agentPromptsZhCN };
  