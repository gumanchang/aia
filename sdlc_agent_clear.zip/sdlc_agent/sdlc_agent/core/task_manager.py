"""
Task Manager - Handles different task types (CLASSIFY, UI_GEN_UI, FLOWCHART, etc.)
"""
import json
import re
from typing import AsyncIterator, Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass
from enum import Enum

from core.llm_client import LLMClient, Message, llm_client
from core.prompts import task_prompts
from core.logger import get_logger
from core.session_manager import session_manager, MessageType

logger = get_logger("task_manager")


class TaskType(str, Enum):
    """Supported task types"""
    # P0 - Core
    CLASSIFY = "CLASSIFY"
    UI_GEN_UI = "UI_GEN_UI"
    SCREENSHOT_UI = "SCREENSHOT_UI"
    FLOWCHART = "FLOWCHART"
    FIX_MERMAID = "FIX_MERMAID"
    
    # P1 - Important
    TRANSLATE = "TRANSLATE"
    COMMENT_EDIT = "COMMENT_EDIT"
    UI_EDIT = "UI_EDIT"
    POLISH_TEXT = "POLISH_TEXT"  # 润色/修改选中的文字
    
    # Additional
    GENERAL = "GENERAL"
    COLLECT = "COLLECT"
    GEN_TITLE = "GEN_TITLE"
    SEARCHING_ANSWER = "SEARCHING_ANSWER"
    
    # Document types
    BRD = "BRD"
    FSD = "FSD"
    FSD_EN = "FSD_EN"


@dataclass
class ClassifyResult:
    """Result of classification"""
    classification: str
    confidence: float = 1.0


@dataclass
class TaskRequest:
    """Task request structure"""
    task_type: TaskType
    user_input: str
    context: Optional[Dict[str, Any]] = None
    images: Optional[List[Dict[str, Any]]] = None
    session_id: Optional[str] = None


class TaskManager:
    """Manages different task types"""
    
    def __init__(self, llm_client: LLMClient = None):
        self.llm_client = llm_client or LLMClient()
    
    async def classify_intent(self, user_input: str, conversation_history: List[Dict] = None) -> ClassifyResult:
        """
        Classify user intent into task types
        
        Returns:
            ClassifyResult with classification and confidence
        """
        messages = [
            Message(role="system", content=task_prompts.get_classify_prompt()),
            Message(role="user", content=user_input)
        ]
        
        # Add conversation history if provided
        if conversation_history:
            for msg in conversation_history[-3:]:  # Only use last 3 messages for context
                role = msg.get("role", "user")
                content = msg.get("content", "")
                messages.insert(-1, Message(role=role, content=content))
        #print('classify_intent conversation_history: ', conversation_history)
        try:
            response = await self.llm_client.generate(messages)
            
            # Extract JSON from response
            json_match = re.search(r'\{[^}]+\}', response)
            if json_match:
                result = json.loads(json_match.group())
                classification = result.get("classification", "PROCESS")
            else:
                # Fallback: try to find classification directly
                for task_type in ["FLOWCHART", "UI", "BRD", "PROCESS", "COLLECT", "SEARCHING", "GENERAL"]:
                    if task_type in response.upper():
                        classification = task_type
                        break
                else:
                    classification = "PROCESS"
            
            logger.info(f"Classified intent: {classification} for input: {user_input[:50]}...")
            return ClassifyResult(classification=classification)
            
        except Exception as e:
            logger.error(f"Classification error: {e}")
            return ClassifyResult(classification="PROCESS")
    
    def _clean_html_output(self, text: str) -> str:
        """Clean and fix common AI HTML generation issues"""
        import re
        
        # 1. Convert uppercase HTML tags to lowercase
        text = re.sub(r'<([A-Z][A-Z0-9]*)\b', lambda m: '<' + m.group(1).lower(), text)
        text = re.sub(r'</([A-Z][A-Z0-9]*)>', lambda m: '</' + m.group(1).lower() + '>', text)
        
        # 2. Fix class attributes with extra spaces
        def fix_class(match):
            classes = match.group(1)
            cleaned = ' '.join(classes.split())
            return f'class="{cleaned}"'
        text = re.sub(r'class="([^"]*)"', fix_class, text)
        
        # 3. Fix broken spacing in Tailwind classes (text-slate -900 -> text-slate-900)
        text = re.sub(r'(\w+)-\s+(\w+)', r'\1-\2', text)
        
        # 4. Fix space before > in tags
        text = re.sub(r'\s+>', '>', text)
        
        # 4.5 Fix buttons without type attribute - add type="button" to prevent form submission
        # Pattern: <button followed by attributes but NOT type=, then >
        def fix_button(match):
            attrs = match.group(1)
            return f'<button type="button"{attrs}>'
        text = re.sub(r'<button(?![^>]*\stype=)([^>]*)>', fix_button, text, flags=re.IGNORECASE)
        
        # 4.6 Remove form tags (they can cause page submission)
        text = re.sub(r'</?form[^>]*>', '', text, flags=re.IGNORECASE)
        
        # 4.7 Replace anchor tags with spans (keep styling but remove navigation)
        def replace_anchor(match):
            content = match.group(1)
            return f'<span class="text-blue-600 cursor-pointer">{content}</span>'
        text = re.sub(r'<a\s+[^>]*href="[^"]*"[^>]*>(.*?)</a>', replace_anchor, text, flags=re.IGNORECASE | re.DOTALL)
        
        # 4.8 Remove inline onclick handlers
        text = re.sub(r'\s+onclick="[^"]*"', '', text, flags=re.IGNORECASE)
        
        # 5. Remove JSX/React expressions entirely (they can't be rendered as HTML)
        # Remove {variable} patterns but keep the content if it's simple
        # This handles cases like {item.name}, {link}, etc.
        text = re.sub(r'\{[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*\}', '', text)
        
        # 6. Remove JSX map/array expressions completely
        # Pattern: {[...].map((...) => (...))} or {{...}.map(...)}
        text = re.sub(r'\{[^}]*\[[^\]]*\][^}]*\.map\s*\([^)]*\)[^}]*\}', '', text)
        
        # 7. Remove JSX conditionals: {condition ? <A/> : <B/>}
        text = re.sub(r'\{[^}]*\?[^}]*:[^}]*\}', '', text)
        
        # 8. Remove standalone JSX brackets that aren't HTML entities
        # Remove lines that start with just { or } (JSX block indicators)
        lines = text.split('\n')
        cleaned_lines = []
        for line in lines:
            stripped = line.strip()
            # Skip lines that are just JSX brackets or arrow function syntax
            if stripped in ['{', '}', '(', ')', '=>', '){', '){(', ')}']:
                continue
            # Skip lines that contain JSX expressions like .map, .filter, etc
            if re.search(r'\.(map|filter|reduce|forEach)\s*\(', stripped):
                continue
            cleaned_lines.append(line)
        text = '\n'.join(cleaned_lines)
        
        return text
    
    async def generate_ui(
        self, 
        user_input: str,
        images: Optional[List[Dict[str, Any]]] = None,
        is_screenshot: bool = False
    ) -> AsyncIterator[str]:
        """
        Generate UI using Tailwind CSS
        
        Args:
            user_input: User requirements
            images: Optional images for screenshot-based generation
            is_screenshot: Whether to use screenshot UI prompt
        """
        if is_screenshot and images:
            system_prompt = task_prompts.get_screenshot_ui_prompt()
        else:
            system_prompt = task_prompts.get_ui_gen_ui_prompt()
        
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_input, images=images)
        ]
        
        logger.info(f"Generating UI (screenshot={is_screenshot})...")
        
        buffer = ""
        async for chunk in self.llm_client.generate_stream(messages):
            buffer += chunk
            # Process and clean complete lines
            lines = buffer.split('\n')
            buffer = lines.pop()  # Keep incomplete line in buffer
            
            for line in lines:
                cleaned = self._clean_html_output(line)
                yield cleaned + "\n"
        
        # Process remaining buffer
        if buffer:
            yield self._clean_html_output(buffer) + "\n"
    
    def _extract_mermaid_code(self, text: str) -> str:
        """
        Smart extraction of Mermaid code from text.
        
        Supports multiple formats:
        1. ```mermaid\n...\n``` - Standard Mermaid code block
        2. ```\n...\n``` - Generic code block (Mermaid content)
        3. Plain text Mermaid code (starts with graph/flowchart/sequenceDiagram/etc.)
        
        Returns:
            Extracted Mermaid code or empty string if not found
        """
        import re
        
        text = text.strip()
        
        # Pattern 1: Standard mermaid code block
        mermaid_match = re.search(r'```mermaid\s*\n(.*?)```', text, re.DOTALL)
        if mermaid_match:
            return mermaid_match.group(1).strip()
        
        # Pattern 2: Generic code block (check if content looks like Mermaid)
        generic_match = re.search(r'```\s*\n(.*?)```', text, re.DOTALL)
        if generic_match:
            code = generic_match.group(1).strip()
            # Check if it looks like Mermaid code
            if self._looks_like_mermaid(code):
                return code
        
        # Pattern 3: Plain text (no code blocks)
        # Look for common Mermaid diagram starters
        lines = text.split('\n')
        mermaid_lines = []
        in_mermaid = False
        
        for line in lines:
            stripped = line.strip()
            
            # Skip empty lines at the start
            if not in_mermaid and not stripped:
                continue
            
            # Check if this line starts Mermaid code
            if not in_mermaid:
                if self._is_mermaid_start_line(stripped):
                    in_mermaid = True
                    mermaid_lines.append(line)
            else:
                # We're in Mermaid code, check for end markers
                if self._is_mermaid_end_line(stripped, lines, len(mermaid_lines)):
                    break
                mermaid_lines.append(line)
        
        if mermaid_lines and len(mermaid_lines) > 1:
            return '\n'.join(mermaid_lines).strip()
        
        return ""
    
    def _looks_like_mermaid(self, code: str) -> bool:
        """Check if code looks like Mermaid syntax"""
        mermaid_keywords = [
            'graph ', 'flowchart ', 'sequenceDiagram', 'classDiagram',
            'stateDiagram', 'erDiagram', 'journey', 'gantt', 'pie',
            'mindmap', 'timeline', 'gitGraph', 'C4Context', '%%'
        ]
        code_start = code.strip().lower()[:100]
        return any(keyword.lower() in code_start for keyword in mermaid_keywords)
    
    def _is_mermaid_start_line(self, line: str) -> bool:
        """Check if a line indicates the start of Mermaid code"""
        mermaid_starters = [
            'graph ', 'flowchart ', 'sequenceDiagram', 'classDiagram',
            'stateDiagram', 'stateDiagram-v2', 'erDiagram', 'journey',
            'gantt', 'pie ', 'mindmap', 'timeline', 'gitGraph',
            'C4Context', 'C4Container', 'C4Component', 'C4Dynamic',
            ' quadrantChart', 'requirementDiagram', ' %%'
        ]
        line_lower = line.lower()
        return any(line_lower.startswith(starter.lower()) for starter in mermaid_starters)
    
    def _is_mermaid_end_line(self, line: str, all_lines: list, current_idx: int) -> bool:
        """Check if we've reached the end of Mermaid code"""
        # End if we see markdown headers or other code blocks
        if line.startswith('# ') or line.startswith('## '):
            return True
        if line.startswith('```') and current_idx > 0:
            return True
        # End if we see explanatory text after substantial Mermaid code
        if current_idx > 5:
            # English markers
            if line.startswith(('This ', 'Note:', 'Explanation:', 'Below ', 'The ')):
                return True
            # Chinese markers - common patterns in LLM explanations
            if line.startswith(('以下是', '这是', '说明：', '说明:', '注意：', '注意:', '【', '注：', '上述', '该流程', '以上')):
                return True
            # Chinese punctuation often appears in explanations but not in mermaid code
            if '。' in line and ('graph ' not in line and 'flowchart ' not in line):
                return True
        return False
    
    async def generate_flowchart(
        self, 
        user_input: str,
        validate: bool = True,
        max_retries: int = 3
    ) -> AsyncIterator[str]:
        """
        Generate Mermaid flowchart with validation and auto-retry using online API
        
        Args:
            user_input: Process description
            validate: Whether to validate the generated code
            max_retries: Maximum number of retries if validation fails
        """
        from core.mermaid_validator import mermaid_validator
        
        logger.info(f"Generating flowchart (validate={validate}, max_retries={max_retries})...")
        
        current_input = user_input
        last_code = ""
        
        for attempt in range(max_retries):
            full_response = ""
            
            messages = [
                Message(role="system", content=task_prompts.get_flowchart_prompt()),
                Message(role="user", content=current_input)
            ]
            
            # Add retry context if this is a retry
            if attempt > 0:
                messages.append(Message(
                    role="system", 
                    content=f"""Previous attempt failed validation.
Common syntax errors to avoid:
- Unmatched brackets: (), [], {{}}
- Invalid arrow syntax: use --> for arrows
- Empty node definitions: nodes need text like [text] or (text)
- Missing direction in flowchart: use flowchart TD or flowchart LR
- Invalid characters in node IDs

Please fix these issues and try again. Only output the corrected mermaid code, no explanations."""
                ))
            
            # Collect all chunks first (don't yield yet)
            async for chunk in self.llm_client.generate_stream(messages):
                full_response += chunk
            
            # Extract mermaid code using smart extraction
            code = self._extract_mermaid_code(full_response)
            if not code:
                logger.warning(f"Attempt {attempt + 1}: No mermaid code found")
                if attempt == max_retries - 1:
                    # Return the last raw response if extraction failed
                    if last_code:
                        yield last_code
                    else:
                        yield full_response
                    return
                continue
            
            last_code = code
            
            # Validate if requested
            if validate:
                logger.info(f"Validating mermaid code (attempt {attempt + 1})...")
                is_valid, error_msg = await mermaid_validator.validate_async(code)
                
                if is_valid:
                    logger.info(f"Flowchart generated and validated successfully on attempt {attempt + 1}")
                    yield code + "\n"  # Only yield the clean, validated code with newline delimiter
                    return
                else:
                    logger.warning(f"Attempt {attempt + 1} failed validation: {error_msg}")
                    
                    if attempt < max_retries - 1:
                        # Get fix suggestions
                        suggestions = mermaid_validator.get_quick_fix_suggestions(error_msg, code)
                        
                        # Update input for next attempt
                        current_input = f"""{user_input}

VALIDATION ERROR (Attempt {attempt + 1}/{max_retries}):
{error_msg}

SUGGESTIONS:
{suggestions}

PREVIOUS CODE:
```mermaid
{code}
```

Please fix the syntax errors and regenerate. Only output the corrected mermaid code, no explanations."""
                    else:
                        # Last attempt failed, return the code anyway with a warning
                        logger.error(f"Failed to validate after {max_retries} attempts, returning last code")
                        yield code + "\n"
            else:
                # Validation disabled, return extracted code
                yield code + "\n"
                return
        
        logger.error(f"Failed to generate valid flowchart after {max_retries} attempts")
    
    async def fix_mermaid(
        self, 
        error_message: str, 
        mermaid_code: str,
        validate: bool = True,
        max_retries: int = 2
    ) -> AsyncIterator[str]:
        """
        Fix Mermaid syntax errors with validation using online API
        
        Args:
            error_message: The error message from Mermaid renderer
            mermaid_code: The original Mermaid code
            validate: Whether to validate the fixed code
            max_retries: Maximum number of fix attempts
        """
        from core.mermaid_validator import mermaid_validator
        
        logger.info(f"Fixing Mermaid code (validate={validate}, max_retries={max_retries})...")
        
        for attempt in range(max_retries):
            full_response = ""
            
            # Get fix suggestions
            suggestions = mermaid_validator.get_quick_fix_suggestions(error_message, mermaid_code)
            
            prompt = f"""Error: {error_message}

Original Code:
```mermaid
{mermaid_code}
```

Fix Suggestions:
{suggestions}"""
            
            if attempt > 0:
                prompt += f"""

Previous fix attempt {attempt} failed with new errors.
Please try a completely different approach - perhaps simplify the diagram or use a different diagram type."""
            
            messages = [
                Message(role="system", content=task_prompts.get_fix_mermaid_prompt()),
                Message(role="user", content=prompt)
            ]
            
            async for chunk in self.llm_client.generate_stream(messages):
                full_response += chunk
                yield chunk + "\n"
            
            # Extract fixed code using smart extraction
            code = self._extract_mermaid_code(full_response)
            if not code:
                # If extraction failed, assume the entire response is the fixed code
                code = full_response.strip()
            
            # Validate if requested
            if validate:
                logger.info(f"Validating fixed code (attempt {attempt + 1})...")
                is_valid, new_error = await mermaid_validator.validate_async(code)
                
                if is_valid:
                    logger.info(f"Mermaid code fixed successfully on attempt {attempt + 1}")
                    return
                else:
                    logger.warning(f"Fix attempt {attempt + 1} still has errors: {new_error}")
                    error_message = new_error
                    mermaid_code = code
                    
                    if attempt < max_retries - 1:
                        yield f"\n\n[Fix validation failed, trying different approach...]\n\n"
            else:
                return
        
        logger.error(f"Failed to fix Mermaid code after {max_retries} attempts")
    
    async def test_render_flowchart(self, mermaid_code: str) -> Tuple[bool, Optional[str], Optional[bytes]]:
        """
        Test render mermaid code to PNG
        
        Returns:
            (success, error_message, png_bytes)
        """
        from core.mermaid_validator import mermaid_validator
        return await mermaid_validator.test_render(mermaid_code)
    
    async def translate_document(
        self, 
        document_content: str, 
        target_lang: str = "English"
    ) -> AsyncIterator[str]:
        """
        Translate document to target language
        
        Args:
            document_content: The document to translate
            target_lang: Target language (English or Chinese)
        """
        messages = [
            Message(role="system", content=task_prompts.get_translate_prompt(target_lang)),
            Message(role="user", content=document_content)
        ]
        
        logger.info(f"Translating document to {target_lang}...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk + "\n"
    
    async def edit_by_comment(
        self,
        selected_text: str,
        user_comment: str,
        doc_context: Optional[str] = None
    ) -> AsyncIterator[str]:
        """
        Edit document based on user comment on selected text
        
        Args:
            selected_text: The text selected by user
            user_comment: User's modification request
            doc_context: Optional surrounding context
        """
        prompt = f"""【Selected Text】
{selected_text}

【User Comment/Instruction】
{user_comment}"""
        
        if doc_context:
            prompt += f"""

【Surrounding Context for Reference】
{doc_context}"""
        
        messages = [
            Message(role="system", content=task_prompts.get_comment_edit_prompt()),
            Message(role="user", content=prompt)
        ]
        
        logger.info("Editing by comment...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk + "\n"
    
    async def polish_text(
        self,
        selected_text: str,
        user_instruction: str,
        before_context: str = "",
        after_context: str = "",
        full_document: Optional[str] = None
    ) -> AsyncIterator[str]:
        """
        Polish/rewrite selected text while keeping surrounding context unchanged
        
        Args:
            selected_text: The text selected by user for polishing
            user_instruction: User's polishing requirements (e.g., "make it more formal", "simplify")
            before_context: Text before the selection (for context)
            after_context: Text after the selection (for context)
            full_document: Optional full document content for broader context
        """
        # Build context-aware prompt
        prompt_parts = []
        
        prompt_parts.append("【TEXT TO POLISH/REWRITE】")
        prompt_parts.append(selected_text)
        prompt_parts.append("")
        prompt_parts.append("【USER REQUIREMENT】")
        prompt_parts.append(user_instruction)
        
        if before_context or after_context:
            prompt_parts.append("")
            prompt_parts.append("【SURROUNDING CONTEXT】")
            if before_context:
                prompt_parts.append("Before selection:")
                prompt_parts.append(before_context[-500:] if len(before_context) > 500 else before_context)
            if after_context:
                prompt_parts.append("")
                prompt_parts.append("After selection:")
                prompt_parts.append(after_context[:500] if len(after_context) > 500 else after_context)
        
        if full_document:
            prompt_parts.append("")
            prompt_parts.append("【FULL DOCUMENT CONTEXT (for reference)】")
            # Include document summary or first part
            doc_preview = full_document[:1000] if len(full_document) > 1000 else full_document
            prompt_parts.append(doc_preview)
        
        prompt = "\n".join(prompt_parts)
        
        system_prompt = """You are an expert editor and writing assistant. Your task is to polish or rewrite the selected text according to the user's requirements.

IMPORTANT RULES:
1. ONLY modify the 【TEXT TO POLISH/REWRITE】 section
2. Keep the tone, style, and terminology consistent with the surrounding context
3. Maintain the original meaning while improving clarity, flow, and style
4. Do NOT add explanations or comments - output ONLY the polished text
5. Do NOT change the fundamental meaning or technical accuracy
6. Match the document's overall style and tone
7. If the text is technical, preserve all technical details and specifications

Your output should be the polished version of the selected text, ready to replace the original."""
        
        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=prompt)
        ]
        
        logger.info(f"Polishing text: {user_instruction[:50]}...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def edit_ui(
        self,
        original_html: str,
        user_instruction: str
    ) -> AsyncIterator[str]:
        """
        Edit UI based on user feedback
        
        Args:
            original_html: Original HTML code
            user_instruction: User's modification request
        """
        prompt = f"""Original HTML:
{original_html}

User Feedback:
{user_instruction}"""
        
        messages = [
            Message(role="system", content=task_prompts.get_ui_edit_prompt()),
            Message(role="user", content=prompt)
        ]
        
        logger.info("Editing UI...")
        
        buffer = ""
        async for chunk in self.llm_client.generate_stream(messages):
            buffer += chunk
            # Process and clean complete lines
            lines = buffer.split('\n')
            buffer = lines.pop()  # Keep incomplete line in buffer
            
            for line in lines:
                cleaned = self._clean_html_output(line)
                yield cleaned + "\n"
        
        # Process remaining buffer
        if buffer:
            yield self._clean_html_output(buffer) + "\n"
    
    async def general_chat(
        self, 
        user_input: str, 
        document_context: str = None,
        conversation_history: List[Dict[str, str]] = None,
        images: Optional[List[Dict[str, Any]]] = None
    ) -> AsyncIterator[str]:
        """
        General chat for PROCESS/GENERAL type conversations
        
        Args:
            user_input: User message
            document_context: Current document content for reference
            conversation_history: Previous conversation messages
            images: Optional images for analysis (e.g., "帮我看看图片里有啥")
        """
        # Build system prompt with document context if available
        system_prompt = task_prompts.get_general_prompt()
        if document_context:
            system_prompt += f"\n\n=== CURRENT DOCUMENT CONTEXT ===\n{document_context[:15000]}\n=== END DOCUMENT CONTEXT ==="
        
        messages = [
            Message(role="system", content=system_prompt)
        ]
        #print('conversation_history:', conversation_history)
        # Add conversation history if provided
        if conversation_history:
            # Filter to last 10 messages to avoid token limit
            recent_history = conversation_history[-10:]
            for msg in recent_history:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if content:
                    messages.append(Message(role=role, content=content))
        
        # Add current user message with images if provided
        messages.append(Message(role="user", content=user_input, images=images))
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def collect_info(
        self, 
        user_input: str,
        document_context: str = None,
        conversation_history: List[Dict[str, str]] = None
    ) -> AsyncIterator[str]:
        """
        Information collection mode with context awareness
        
        Args:
            user_input: User message
            document_context: Current document content for reference
            conversation_history: Previous conversation messages for context
        """
        # Build system prompt with document context if available
        system_prompt = task_prompts.get_collect_prompt()
        if document_context:
            system_prompt += f"\n\n=== 当前已有文档内容 ===\n{document_context[:5000]}\n=== 文档内容结束 ==="
        
        messages = [
            Message(role="system", content=system_prompt)
        ]
        
        # Add conversation history if provided
        if conversation_history:
            # Filter to last 15 messages to avoid token limit but keep enough context
            recent_history = conversation_history[-15:]
            for msg in recent_history:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if content:
                    messages.append(Message(role=role, content=content))
        
        # Add current user message
        messages.append(Message(role="user", content=user_input))
        
        logger.info(f"Collecting information with {len(conversation_history) if conversation_history else 0} history messages...")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def generate_title(self, user_input: str) -> str:
        """
        Generate session title from user input
        Simply uses the first 20 characters of user input as the title
        
        Args:
            user_input: First user message
            
        Returns:
            First 20 characters of user input (trimmed)
        """
        # Use first 20 chars of user input as title
        title = user_input.strip()[:20]
        logger.info(f"Using user input as title: {title}")
        return title
    
    async def search_answer(
        self,
        user_question: str,
        search_results: List[Dict[str, Any]],
        document_context: str = None,
        conversation_history: List[Dict[str, str]] = None
    ) -> AsyncIterator[str]:
        """
        Answer user question based on search results and/or current document
        
        Args:
            user_question: User's question
            search_results: Results from knowledge base search
            document_context: Current document content for reference
            conversation_history: Previous conversation messages
        """
        # Format search results
        formatted_results = "\n\n---\n\n".join([
            f"[{i+1}] Title: {r.get('title', 'Untitled')}\nScore: {r.get('score', 'N/A')}\nContent: {r.get('content', '')}"
            for i, r in enumerate(search_results)
        ])
        
        # Build context sections
        context_sections = []
        if document_context:
            context_sections.append(f"=== CURRENT DOCUMENT ===\n{document_context[:10000]}\n=== END DOCUMENT ===")
        if formatted_results:
            context_sections.append(f"=== KNOWLEDGE BASE RESULTS ===\n{formatted_results}\n=== END RESULTS ===")
        
        full_context = "\n\n".join(context_sections) if context_sections else "No additional context available."
        
        prompt = task_prompts.get_searching_answer_prompt()
        prompt = prompt.replace("{{SEARCH_RESULTS}}", full_context)
        prompt = prompt.replace("{{USER_QUESTION}}", user_question)
        
        messages = [
            Message(role="system", content=prompt)
        ]
        
        # Add conversation history if provided
        if conversation_history:
            recent_history = conversation_history[-10:]
            for msg in recent_history:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if content:
                    messages.append(Message(role=role, content=content))
        
        messages.append(Message(role="user", content=user_question))
        
        logger.info(f"Answering search query: {user_question[:50]}...")
        if document_context:
            logger.info(f"Document context included: {len(document_context)} chars")
        
        async for chunk in self.llm_client.generate_stream(messages):
            yield chunk
    
    async def execute_task(self, request: TaskRequest) -> AsyncIterator[str]:
        """
        Execute a task based on request
        
        Args:
            request: TaskRequest with task details
            
        Yields:
            Response chunks
        """
        task_type = request.task_type
        user_input = request.user_input
        context = request.context or {}
        session_id = request.session_id
        
        logger.info(f"Executing task: {task_type}")
        
        # Create session for ALL task types (for complete chat history tracking)
        # Every user interaction should be recorded
        if not session_id:
            title = await self.generate_title(user_input)
            
            # Map task_type to doc_type for session categorization
            doc_type_map = {
                TaskType.BRD: "BRD",
                TaskType.FSD: "FSD",
                TaskType.FSD_EN: "FSD_EN",
                TaskType.UI_GEN_UI: "UI",
                TaskType.SCREENSHOT_UI: "UI",
                TaskType.FLOWCHART: "FLOWCHART",
                TaskType.TRANSLATE: "TRANSLATE",
                TaskType.COLLECT: "CHAT",
                TaskType.GENERAL: "CHAT",
                TaskType.SEARCHING_ANSWER: "CHAT",
                TaskType.COMMENT_EDIT: "EDIT",
                TaskType.UI_EDIT: "UI",
                TaskType.POLISH_TEXT: "EDIT",
                TaskType.FIX_MERMAID: "EDIT",
            }
            doc_type = doc_type_map.get(task_type, "CHAT")
            
            session = session_manager.create_session(
                title=title,
                doc_type=doc_type,
                initial_requirements=user_input
            )
            session_id = session.id
            logger.info(f"Created new session: {session_id} for task: {task_type}")
            
            # Yield session_created event first (with newline delimiter for SSE)
            yield json.dumps({
                "type": "session_created",
                "session_id": session_id,
                "title": title
            }) + "\n"
        
        if task_type == TaskType.CLASSIFY:
            result = await self.classify_intent(user_input)
            yield json.dumps({"classification": result.classification})
            
        elif task_type == TaskType.UI_GEN_UI:
            images = request.images
            async for chunk in self.generate_ui(user_input, images, is_screenshot=False):
                yield chunk
                
        elif task_type == TaskType.SCREENSHOT_UI:
            images = request.images
            async for chunk in self.generate_ui(user_input, images, is_screenshot=True):
                yield chunk
                
        elif task_type == TaskType.FLOWCHART:
            async for chunk in self.generate_flowchart(user_input):
                yield chunk
                
        elif task_type == TaskType.FIX_MERMAID:
            error_msg = context.get("error_message", "")
            mermaid_code = context.get("mermaid_code", "")
            async for chunk in self.fix_mermaid(error_msg, mermaid_code):
                yield chunk
                
        elif task_type == TaskType.TRANSLATE:
            target_lang = context.get("target_lang", "English")
            async for chunk in self.translate_document(user_input, target_lang):
                yield chunk
                
        elif task_type == TaskType.COMMENT_EDIT:
            selected_text = context.get("selected_text", "")
            user_comment = context.get("user_comment", "")
            doc_context = context.get("doc_context")
            async for chunk in self.edit_by_comment(selected_text, user_comment, doc_context):
                yield chunk
                
        elif task_type == TaskType.UI_EDIT:
            original_html = context.get("original_html", "")
            user_instruction = context.get("user_instruction", "")
            async for chunk in self.edit_ui(original_html, user_instruction):
                yield chunk
        
        elif task_type == TaskType.POLISH_TEXT:
            selected_text = context.get("selected_text", "")
            user_instruction = user_input  # The instruction is in user_input
            before_context = context.get("before_context", "")
            after_context = context.get("after_context", "")
            full_document = context.get("full_document")
            async for chunk in self.polish_text(
                selected_text, 
                user_instruction, 
                before_context, 
                after_context, 
                full_document
            ):
                yield chunk
                
        elif task_type == TaskType.COLLECT:
            # Get document context and conversation history if session exists
            document_context = None
            conversation_history = None
            if session_id:
                session = session_manager.get_session(session_id)
                if session:
                    document_context = session.current_document
                    # Build conversation history from session messages
                    conversation_history = []
                    for msg in session.messages:
                        if msg.type == MessageType.DOCUMENT:
                            continue  # Skip document messages, they're in document_context
                        role = "user" if msg.type in [MessageType.USER, MessageType.MODIFICATION] else "assistant"
                        conversation_history.append({
                            "role": role,
                            "content": msg.content
                        })
            
            async for chunk in self.collect_info(
                user_input,
                document_context=document_context,
                conversation_history=conversation_history
            ):
                yield chunk
                
        elif task_type == TaskType.GEN_TITLE:
            title = await self.generate_title(user_input)
            yield title
            
        elif task_type == TaskType.SEARCHING_ANSWER:
            search_results = context.get("search_results", [])
            
            # Get document context if session exists
            document_context = None
            conversation_history = None
            if session_id:
                session = session_manager.get_session(session_id)
                if session:
                    document_context = session.current_document
                    # Build conversation history from session messages
                    conversation_history = []
                    for msg in session.messages:
                        if msg.type == MessageType.DOCUMENT:
                            continue
                        role = "user" if msg.type in [MessageType.USER, MessageType.MODIFICATION] else "assistant"
                        conversation_history.append({
                            "role": role,
                            "content": msg.content
                        })
            
            async for chunk in self.search_answer(
                user_input, 
                search_results,
                document_context=document_context,
                conversation_history=conversation_history
            ):
                yield chunk
        
        elif task_type == TaskType.GENERAL:
            # Get document context if session exists
            document_context = None
            conversation_history = None
            if session_id:
                session = session_manager.get_session(session_id)
                if session:
                    document_context = session.current_document
                    # Build conversation history from session messages
                    conversation_history = []
                    for msg in session.messages:
                        if msg.type == MessageType.DOCUMENT:
                            continue  # Skip document messages, they're in document_context
                        role = "user" if msg.type in [MessageType.USER, MessageType.MODIFICATION] else "assistant"
                        conversation_history.append({
                            "role": role,
                            "content": msg.content
                        })
            
            # Get images from request.images or context.images
            images = request.images
            if not images and context:
                images = context.get("images")
            
            async for chunk in self.general_chat(
                user_input, 
                document_context=document_context,
                conversation_history=conversation_history,
                images=images
            ):
                yield chunk
                
        else:
            # Default to general chat for unknown types
            logger.warning(f"Unknown task type: {task_type}, defaulting to GENERAL")
            async for chunk in self.general_chat(user_input):
                yield chunk


# Global task manager instance
task_manager = TaskManager()
