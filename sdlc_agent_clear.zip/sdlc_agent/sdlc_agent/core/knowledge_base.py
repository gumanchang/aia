"""
Knowledge Base - Local storage for generated documents and context
"""
import os
import json
import uuid
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

from config import settings


@dataclass
class KnowledgeEntry:
    """A single knowledge base entry"""
    id: str
    entry_type: str  # document, template, feedback, etc.
    title: str
    content: str
    metadata: Dict[str, Any]
    created_at: str
    updated_at: str
    tags: List[str]


class KnowledgeBase:
    """Simple local file-based knowledge base"""
    
    def __init__(self, base_dir: str = None):
        self.base_dir = base_dir or settings.KNOWLEDGE_BASE_DIR
        self.documents_dir = os.path.join(self.base_dir, "documents")
        self.index_file = os.path.join(self.base_dir, "index.json")
        
        # Ensure directories exist
        os.makedirs(self.documents_dir, exist_ok=True)
        
        # Load or create index
        self.index = self._load_index()
    
    def _load_index(self) -> Dict[str, Any]:
        """Load the knowledge base index"""
        if os.path.exists(self.index_file):
            try:
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "version": "1.0",
            "created_at": datetime.now().isoformat(),
            "entries": {},
            "tags": {}
        }
    
    def _save_index(self):
        """Save the knowledge base index"""
        with open(self.index_file, 'w', encoding='utf-8') as f:
            json.dump(self.index, f, indent=2, ensure_ascii=False)
    
    def save_document(
        self,
        doc_type: str,
        title: str,
        content: str,
        metadata: Dict[str, Any] = None,
        tags: List[str] = None
    ) -> str:
        """
        Save a document to the knowledge base
        
        Returns:
            Document ID
        """
        doc_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        
        entry = KnowledgeEntry(
            id=doc_id,
            entry_type=doc_type,
            title=title,
            content=content,
            metadata=metadata or {},
            created_at=now,
            updated_at=now,
            tags=tags or []
        )
        
        # Save document file
        doc_file = os.path.join(self.documents_dir, f"{doc_id}.md")
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # Update index
        self.index["entries"][doc_id] = {
            "id": doc_id,
            "entry_type": doc_type,
            "title": title,
            "metadata": metadata or {},
            "created_at": now,
            "updated_at": now,
            "tags": tags or [],
            "file": doc_file
        }
        
        # Update tags index
        for tag in (tags or []):
            if tag not in self.index["tags"]:
                self.index["tags"][tag] = []
            self.index["tags"][tag].append(doc_id)
        
        self._save_index()
        
        return doc_id
    
    def get_document(self, doc_id: str) -> Optional[KnowledgeEntry]:
        """Get a document by ID"""
        entry_data = self.index["entries"].get(doc_id)
        if not entry_data:
            return None
        
        # Load content from file
        doc_file = entry_data.get("file")
        if doc_file and os.path.exists(doc_file):
            with open(doc_file, 'r', encoding='utf-8') as f:
                content = f.read()
        else:
            content = ""
        
        return KnowledgeEntry(
            id=entry_data["id"],
            entry_type=entry_data["entry_type"],
            title=entry_data["title"],
            content=content,
            metadata=entry_data["metadata"],
            created_at=entry_data["created_at"],
            updated_at=entry_data["updated_at"],
            tags=entry_data["tags"]
        )
    
    def update_document(
        self,
        doc_id: str,
        content: str = None,
        metadata: Dict[str, Any] = None,
        tags: List[str] = None
    ) -> bool:
        """Update a document"""
        entry_data = self.index["entries"].get(doc_id)
        if not entry_data:
            return False
        
        now = datetime.now().isoformat()
        
        # Update content
        if content is not None:
            doc_file = entry_data.get("file")
            if doc_file:
                with open(doc_file, 'w', encoding='utf-8') as f:
                    f.write(content)
        
        # Update metadata
        if metadata is not None:
            entry_data["metadata"].update(metadata)
        
        # Update tags
        if tags is not None:
            # Remove from old tags
            for tag in entry_data["tags"]:
                if tag in self.index["tags"] and doc_id in self.index["tags"][tag]:
                    self.index["tags"][tag].remove(doc_id)
            
            # Add to new tags
            entry_data["tags"] = tags
            for tag in tags:
                if tag not in self.index["tags"]:
                    self.index["tags"][tag] = []
                self.index["tags"][tag].append(doc_id)
        
        entry_data["updated_at"] = now
        self._save_index()
        
        return True
    
    def delete_document(self, doc_id: str) -> bool:
        """Delete a document"""
        entry_data = self.index["entries"].get(doc_id)
        if not entry_data:
            return False
        
        # Remove file
        doc_file = entry_data.get("file")
        if doc_file and os.path.exists(doc_file):
            os.remove(doc_file)
        
        # Remove from tags
        for tag in entry_data["tags"]:
            if tag in self.index["tags"] and doc_id in self.index["tags"][tag]:
                self.index["tags"][tag].remove(doc_id)
        
        # Remove from index
        del self.index["entries"][doc_id]
        self._save_index()
        
        return True
    
    def search(
        self,
        query: str = None,
        doc_type: str = None,
        tags: List[str] = None,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """Search documents"""
        results = []
        
        for doc_id, entry in self.index["entries"].items():
            # Filter by type
            if doc_type and entry["entry_type"] != doc_type:
                continue
            
            # Filter by tags
            if tags and not all(tag in entry["tags"] for tag in tags):
                continue
            
            # Filter by query
            if query:
                query_lower = query.lower()
                if (query_lower not in entry["title"].lower() and 
                    query_lower not in json.dumps(entry["metadata"]).lower()):
                    continue
            
            results.append({
                "id": entry["id"],
                "entry_type": entry["entry_type"],
                "title": entry["title"],
                "metadata": entry["metadata"],
                "created_at": entry["created_at"],
                "updated_at": entry["updated_at"],
                "tags": entry["tags"]
            })
        
        # Sort by updated_at desc
        results.sort(key=lambda x: x["updated_at"], reverse=True)
        
        return results[:limit]
    
    def list_documents(
        self,
        doc_type: str = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """List all documents"""
        return self.search(doc_type=doc_type, limit=limit)
    
    def get_similar_documents(
        self,
        doc_id: str,
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """Get similar documents based on tags and type"""
        entry = self.index["entries"].get(doc_id)
        if not entry:
            return []
        
        # Find documents with similar tags
        similar = []
        for other_id, other_entry in self.index["entries"].items():
            if other_id == doc_id:
                continue
            
            # Same type gets priority
            score = 0
            if other_entry["entry_type"] == entry["entry_type"]:
                score += 10
            
            # Common tags
            common_tags = set(other_entry["tags"]) & set(entry["tags"])
            score += len(common_tags) * 5
            
            if score > 0:
                similar.append({
                    "id": other_entry["id"],
                    "entry_type": other_entry["entry_type"],
                    "title": other_entry["title"],
                    "score": score,
                    "created_at": other_entry["created_at"]
                })
        
        # Sort by score
        similar.sort(key=lambda x: x["score"], reverse=True)
        
        return similar[:limit]


# Global knowledge base instance
knowledge_base = KnowledgeBase()
