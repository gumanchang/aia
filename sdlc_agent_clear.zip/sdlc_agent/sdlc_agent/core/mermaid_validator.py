"""
Mermaid Validator - Pure Python Mermaid syntax validation using PNG rendering
"""
import re
import os
import tempfile
import shutil
from typing import Tuple, Optional, List, Dict, Set
from dataclasses import dataclass
from pathlib import Path


@dataclass
class ValidationError:
    """Validation error details"""
    line: int
    column: int
    message: str
    severity: str = "error"  # error, warning


class MermaidValidator:
    """Mermaid syntax validator using PNG rendering"""
    
    # Valid diagram types
    DIAGRAM_TYPES = {
        'flowchart': ['TD', 'LR', 'RL', 'BT', 'TB'],
        'graph': ['TD', 'LR', 'RL', 'BT', 'TB'],
        'sequenceDiagram': [],
        'classDiagram': [],
        'erDiagram': [],
        'gantt': [],
        'stateDiagram': [],
        'stateDiagram-v2': [],
        'journey': [],
        'pie': [],
        'requirementDiagram': [],
        'gitGraph': [],
        'mindmap': [],
        'timeline': [],
    }
    
    # Reserved keywords that cannot be used as node IDs
    RESERVED_KEYWORDS = {
        'flowchart', 'graph', 'sequenceDiagram', 'classDiagram', 'erDiagram',
        'gantt', 'stateDiagram', 'journey', 'pie', 'subgraph', 'end',
        'class', 'click', 'style', 'linkStyle', 'classDef', 'direction',
        'participant', 'actor', 'note', 'loop', 'alt', 'else', 'opt',
        'par', 'and', 'rect', 'end'
    }
    
    def __init__(self):
        """Initialize validator with temp directory"""
        self.temp_dir = None
    
    def _get_temp_dir(self) -> str:
        """Create and return temp directory for validation files"""
        if self.temp_dir is None or not os.path.exists(self.temp_dir):
            self.temp_dir = tempfile.mkdtemp(prefix="mermaid_val_")
        return self.temp_dir
    
    def cleanup(self):
        """Clean up temp directory"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
            self.temp_dir = None
    
    def __del__(self):
        """Destructor to ensure cleanup"""
        self.cleanup()
    
    async def validate_async(self, code: str) -> Tuple[bool, Optional[str]]:
        """
        Validate mermaid code using pattern-based validation only (no external API calls)
        
        Returns:
            (is_valid, error_message)
        """
        # Pattern-based validation (pure Python, no external dependencies)
        errors = self._validate(code)
        if errors:
            return False, f"Line {errors[0].line}: {errors[0].message}"
        
        # Additional syntax validation
        try:
            is_valid, error_msg = self._validate_syntax_rules(code)
            return is_valid, error_msg
        except Exception as e:
            # If validation fails unexpectedly, still return success
            # (pattern validation already passed)
            return True, None
    
    def _validate_by_png_rendering(self, code: str) -> Tuple[bool, Optional[str]]:
        """
        Validate by rendering to PNG using mermaid library
        
        Returns:
            (is_valid, error_message)
        """
        temp_dir = None
        temp_mmd_path = None
        temp_png_path = None
        
        try:
            # Create temp directory
            temp_dir = tempfile.mkdtemp(prefix="mermaid_val_")
            
            # Write mermaid code to temp file
            temp_mmd_path = os.path.join(temp_dir, "diagram.mmd")
            with open(temp_mmd_path, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # PNG output path
            temp_png_path = os.path.join(temp_dir, "diagram.png")
            
            # Try to import and use mermaid library
            try:
                # Try mermaid-py library
                from mermaid import Mermaid
                
                mm = Mermaid(code)
                mm.to_png(temp_png_path)
                
                # Check if PNG was created and is valid
                if os.path.exists(temp_png_path) and os.path.getsize(temp_png_path) > 0:
                    if self._is_valid_png(temp_png_path):
                        return True, None
                    else:
                        return False, "Generated PNG is corrupted"
                else:
                    return False, "Failed to generate PNG"
                    
            except ImportError:
                # mermaid-py not installed, try alternative
                try:
                    # Try using matplotlib backend if available
                    import matplotlib
                    matplotlib.use('Agg')  # Non-interactive backend
                    
                    # Use mermaid.ink API as fallback (requires internet)
                    # Or return pattern validation success
                    return self._validate_with_pattern_only(code)
                    
                except Exception as e:
                    # Fall back to pattern validation only
                    return self._validate_with_pattern_only(code)
                    
        except Exception as e:
            return False, f"PNG validation error: {str(e)}"
        finally:
            # Clean up temp files
            pass
            #self._cleanup_temp_files(temp_dir, temp_mmd_path, temp_png_path)
    
    def _cleanup_temp_files(self, temp_dir: str, mmd_path: Optional[str], png_path: Optional[str]):
        """Clean up temporary files"""
        try:
            # Remove individual files if they exist
            if mmd_path and os.path.exists(mmd_path):
                os.remove(mmd_path)
            if png_path and os.path.exists(png_path):
                os.remove(png_path)
            
            # Remove temp directory
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception as e:
            # Log but don't raise - cleanup errors shouldn't break validation
            print(f"Warning: Failed to cleanup temp files: {e}")
    
    def _is_valid_png(self, file_path: str) -> bool:
        """Check if file is a valid PNG image"""
        try:
            # Check PNG magic number
            with open(file_path, 'rb') as f:
                header = f.read(8)
                if header != b'\x89PNG\r\n\x1a\n':
                    return False
            
            # Try to open with PIL if available
            try:
                from PIL import Image
                with Image.open(file_path) as img:
                    img.verify()
                return True
            except ImportError:
                # PIL not available, rely on magic number only
                return True
            except Exception:
                return False
                
        except Exception:
            return False
    
    def _validate_with_pattern_only(self, code: str) -> Tuple[bool, Optional[str]]:
        """Fallback to pattern-only validation"""
        errors = self._validate(code)
        if errors:
            return False, f"Line {errors[0].line}: {errors[0].message}"
        return True, None
    
    def _validate(self, code: str) -> List[ValidationError]:
        """Full validation of mermaid code"""
        errors = []
        
        if not code or not code.strip():
            errors.append(ValidationError(0, 0, "Empty code"))
            return errors
        
        lines = code.split('\n')
        
        # 1. Detect diagram type
        diagram_type, direction, error = self._detect_diagram_type(lines)
        if error:
            errors.append(ValidationError(1, 0, error))
            return errors
        
        # 2. Validate based on diagram type
        if diagram_type in ['flowchart', 'graph']:
            errors.extend(self._validate_flowchart(lines, diagram_type))
        elif diagram_type == 'sequenceDiagram':
            errors.extend(self._validate_sequence_diagram(lines))
        elif diagram_type == 'gantt':
            errors.extend(self._validate_gantt(lines))
        elif diagram_type in ['classDiagram', 'erDiagram']:
            errors.extend(self._validate_class_diagram(lines, diagram_type))
        else:
            # For other types, do basic validation
            errors.extend(self._validate_basic_syntax(lines))
        
        return errors
    
    def _validate_syntax_rules(self, code: str) -> Tuple[bool, Optional[str]]:
        """
        Additional syntax validation without external API calls.
        
        Returns:
            (is_valid, error_message)
        """
        lines = code.split('\n')
        
        # 1. Check for basic structure
        diagram_type, direction, error = self._detect_diagram_type(lines)
        if error:
            return False, error
        
        # 2. Check for common syntax issues
        errors = []
        
        for line_num, line in enumerate(lines, 1):
            stripped = line.strip()
            
            # Skip empty lines and comments
            if not stripped or stripped.startswith('%%'):
                continue
            
            # Check for unbalanced brackets in the line
            brackets = {'(': ')', '[': ']', '{': '}', '"': '"'}
            stack = []
            in_string = False
            string_char = None
            
            for char in stripped:
                if char in '"\'':
                    if not in_string:
                        in_string = True
                        string_char = char
                        stack.append(char)
                    elif string_char == char:
                        in_string = False
                        string_char = None
                        if stack and stack[-1] == char:
                            stack.pop()
                elif not in_string:
                    if char in brackets.keys():
                        stack.append(char)
                    elif char in brackets.values():
                        if not stack:
                            errors.append(f"Line {line_num}: Unmatched closing bracket '{char}'")
                            break
                        last_open = stack.pop()
                        if brackets[last_open] != char:
                            errors.append(f"Line {line_num}: Mismatched brackets '{last_open}' and '{char}'")
                            break
            
            if in_string:
                errors.append(f"Line {line_num}: Unclosed string")
        
        # 3. Check for required elements based on diagram type
        if diagram_type in ['flowchart', 'graph']:
            # Check if there's at least one node or connection
            has_nodes = False
            for line in lines:
                # Look for node definitions or connections
                if re.search(r'\w+\s*[-=~]+>', line):  # Arrow connections
                    has_nodes = True
                    break
                if re.search(r'\w+\s*[\[\{\(\</]', line):  # Node definitions
                    has_nodes = True
                    break
            
            if not has_nodes:
                errors.append("Flowchart has no nodes or connections")
        
        # 4. Check for invalid characters in node IDs
        for line_num, line in enumerate(lines, 1):
            # Find potential node IDs (alphanumeric before brackets or arrows)
            matches = re.finditer(r'\b([a-zA-Z_][a-zA-Z0-9_]*)\s*[[{(]', line)
            for match in matches:
                node_id = match.group(1)
                if node_id in self.RESERVED_KEYWORDS:
                    errors.append(f"Line {line_num}: '{node_id}' is a reserved keyword and cannot be used as node ID")
        
        if errors:
            return False, errors[0]
        
        return True, None
    
    def _detect_diagram_type(self, lines: List[str]) -> Tuple[str, Optional[str], Optional[str]]:
        """Detect the type of mermaid diagram"""
        if not lines:
            return None, None, "Empty diagram"
        
        first_line = lines[0].strip().lower()
        
        for diagram_type in self.DIAGRAM_TYPES.keys():
            if first_line.startswith(diagram_type.lower()):
                # Extract direction if present
                direction = None
                parts = lines[0].strip().split()
                if len(parts) > 1:
                    direction = parts[1].upper()
                return diagram_type, direction, None
        
        return None, None, f"Unknown diagram type. Must start with one of: {', '.join(self.DIAGRAM_TYPES.keys())}"
    
    def _validate_flowchart(self, lines: List[str], diagram_type: str) -> List[ValidationError]:
        """Validate flowchart/graph syntax"""
        errors = []
        defined_nodes: Set[str] = set()
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('%%'):
                continue
            
            # Skip direction statement
            if line.lower().startswith('direction '):
                continue
            
            # Skip subgraph
            if line.lower().startswith('subgraph'):
                continue
            if line.lower() == 'end':
                continue
            
            # Skip style and classDef
            if line.lower().startswith('style ') or line.lower().startswith('classdef '):
                continue
            
            # Skip class assignment
            if line.lower().startswith('class '):
                continue
            
            # Validate node definitions and connections
            errors.extend(self._validate_flowchart_line(line, line_num, defined_nodes))
        
        return errors
    
    def _validate_flowchart_line(self, line: str, line_num: int, defined_nodes: Set[str]) -> List[ValidationError]:
        """Validate a single flowchart line"""
        errors = []
        
        # Pattern for node definition: ID["text"] or ID("text") or ID{"text"} or ID[/text/] etc.
        node_patterns = [
            (r'\[([^\]]*)\]', 'rectangle'),      # [text]
            (r'\(([^\)]*)\)', 'rounded'),        # (text)
            (r'\{([^\}]*)\}', 'rhombus'),        # {text}
            (r'\(\(([^\)]*)\)\)', 'circle'),     # ((text))
            (r'>\[([^\]]*)\]', 'flag'),          # >[text]
            (r'\[\/([^\/]*)\/\]', 'sl-rect'),    # [/text/]
            (r'\[\\([^\\]*)\\\\\]', 'sr-rect'),  # [\text\]
            (r'\[\/([^\/]*)\\/\]', 'trapezoid'), # [/text\]
            (r'\[\\([^\\]*)\/\]', 'inv-trapezoid'), # [\text/]
        ]
        
        # Pattern for arrows
        arrow_pattern = r'(-->|-->|==>|-.->|-.->|--x|--o|<-->|-->)'
        
        # Split line by arrows to get connections
        parts = re.split(arrow_pattern, line)
        
        if len(parts) == 1:
            # Single node definition
            node_id, error = self._extract_node_id(line, node_patterns)
            if error:
                errors.append(ValidationError(line_num, 0, error))
            elif node_id:
                defined_nodes.add(node_id)
        else:
            # Connection: A --> B
            for i, part in enumerate(parts):
                part = part.strip()
                if not part:
                    continue
                
                # Check if it's an arrow
                if re.match(arrow_pattern, part):
                    continue
                
                # It should be a node
                node_id, error = self._extract_node_id(part, node_patterns)
                if error:
                    errors.append(ValidationError(line_num, 0, f"Invalid node syntax '{part}': {error}"))
                elif node_id:
                    # Node IDs are implicitly defined when used
                    defined_nodes.add(node_id)
                    
                    # Check for reserved keywords
                    if node_id.lower() in self.RESERVED_KEYWORDS:
                        errors.append(ValidationError(line_num, 0, f"'{node_id}' is a reserved keyword"))
        
        return errors
    
    def _extract_node_id(self, text: str, node_patterns: List[tuple]) -> Tuple[Optional[str], Optional[str]]:
        """Extract node ID from text"""
        text = text.strip()
        
        # Check if it's just an ID without brackets
        if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', text):
            return text, None
        
        # Check for node with text
        for pattern, shape in node_patterns:
            match = re.search(pattern, text)
            if match:
                # Extract ID before the bracket
                id_match = re.match(r'^([a-zA-Z_][a-zA-Z0-9_]*)', text)
                if id_match:
                    return id_match.group(1), None
                else:
                    # Inline node definition without explicit ID
                    return None, None
        
        # Check for special characters
        if any(c in text for c in ['(', ')', '[', ']', '{', '}', '<', '>']):
            # Check for unbalanced brackets
            brackets = {'(': ')', '[': ']', '{': '}', '<': '>'}
            stack = []
            for char in text:
                if char in brackets.keys():
                    stack.append(char)
                elif char in brackets.values():
                    if not stack:
                        return None, f"Unmatched closing bracket: {char}"
                    opening = stack.pop()
                    if brackets[opening] != char:
                        return None, f"Mismatched brackets: {opening} and {char}"
            if stack:
                return None, f"Unmatched opening brackets: {''.join(stack)}"
        
        return None, None
    
    def _validate_sequence_diagram(self, lines: List[str]) -> List[ValidationError]:
        """Validate sequence diagram syntax"""
        errors = []
        participants: Set[str] = set()
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            if not line or line.startswith('%%'):
                continue
            
            # Skip diagram type declaration
            if line.lower().startswith('sequencediagram'):
                continue
            
            # Participant declaration
            participant_match = re.match(r'participant\s+(\w+)', line, re.IGNORECASE)
            if participant_match:
                participants.add(participant_match.group(1))
                continue
            
            # Actor declaration
            actor_match = re.match(r'actor\s+(\w+)', line, re.IGNORECASE)
            if actor_match:
                participants.add(actor_match.group(1))
                continue
            
            # Message: A->B: text
            message_match = re.match(r'(\w+)\s*(-?-?>?-?)\s*(\w+)\s*:\s*(.+)', line)
            if message_match:
                sender = message_match.group(1)
                receiver = message_match.group(3)
                
                if sender not in participants:
                    participants.add(sender)  # Auto-add participants
                if receiver not in participants:
                    participants.add(receiver)
                continue
            
            # Note: note over/right/left of
            note_match = re.match(r'note\s+(over|right\s+of|left\s+of)\s+(\w+)', line, re.IGNORECASE)
            if note_match:
                participant = note_match.group(2)
                if participant not in participants:
                    errors.append(ValidationError(line_num, 0, f"Undefined participant in note: {participant}"))
                continue
            
            # Loops and alts
            if any(line.lower().startswith(kw) for kw in ['loop', 'alt', 'else', 'opt', 'par', 'and', 'end', 'rect']):
                continue
            
            # Activation/deactivation
            if re.match(r'(activate|deactivate)\s+\w+', line, re.IGNORECASE):
                continue
        
        return errors
    
    def _validate_gantt(self, lines: List[str]) -> List[ValidationError]:
        """Validate Gantt chart syntax"""
        errors = []
        
        date_formats = ['YYYY-MM-DD', 'YYYY/MM/DD', 'DD-MM-YYYY', 'DD/MM/YYYY']
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            if not line or line.startswith('%%'):
                continue
            
            # Skip diagram type
            if line.lower().startswith('gantt'):
                continue
            
            # dateFormat
            if line.lower().startswith('dateformat'):
                continue
            
            # title
            if line.lower().startswith('title'):
                continue
            
            # Section
            if line.lower().startswith('section'):
                continue
            
            # Task: name :status, id, start, end/duration
            task_pattern = r'([^:]+):\s*(\w+),\s*(\w+),\s*(\S+),\s*(\S+)'
            task_match = re.match(task_pattern, line)
            
            if task_match:
                status = task_match.group(2)
                valid_statuses = ['done', 'active', 'crit', 'milestone', '']
                if status not in valid_statuses and not any(s in status for s in valid_statuses):
                    errors.append(ValidationError(line_num, 0, f"Invalid task status: {status}"))
        
        return errors
    
    def _validate_class_diagram(self, lines: List[str], diagram_type: str) -> List[ValidationError]:
        """Validate class diagram or ER diagram syntax"""
        errors = []
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            if not line or line.startswith('%%'):
                continue
            
            # Skip diagram type
            if line.lower().startswith(diagram_type.lower()):
                continue
            
            # Class definitions and relationships
            # For now, basic validation only
        
        return errors
    
    def _validate_basic_syntax(self, lines: List[str]) -> List[ValidationError]:
        """Basic syntax validation for other diagram types"""
        errors = []
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            if not line or line.startswith('%%'):
                continue
            
            # Check for unmatched brackets
            brackets = {'(': ')', '[': ']', '{': '}'}
            stack = []
            
            for char in line:
                if char in brackets.keys():
                    stack.append(char)
                elif char in brackets.values():
                    if not stack:
                        errors.append(ValidationError(line_num, 0, f"Unmatched closing bracket: {char}"))
                    else:
                        opening = stack.pop()
                        if brackets[opening] != char:
                            errors.append(ValidationError(line_num, 0, f"Mismatched brackets: {opening} and {char}"))
            
            if stack:
                errors.append(ValidationError(line_num, 0, f"Unmatched opening brackets: {''.join(stack)}"))
        
        return errors
    
    @staticmethod
    def get_quick_fix_suggestions(error: str, code: str) -> str:
        """Get suggestions for fixing common errors"""
        suggestions = []
        
        error_lower = error.lower()
        
        if "unmatched" in error_lower or "bracket" in error_lower:
            suggestions.append("Check that all brackets (), [], {} are properly closed and matched")
        
        if "arrow" in error_lower:
            suggestions.append("Use standard arrow syntax: --> for solid arrows, -.-> for dashed, ==> for thick")
        
        if "reserved keyword" in error_lower:
            suggestions.append("Avoid using reserved keywords (flowchart, graph, class, etc.) as node IDs")
        
        if "empty" in error_lower:
            suggestions.append("Node definitions cannot be empty - add text inside brackets like [text]")
        
        if "diagram type" in error_lower:
            suggestions.append("Start with valid diagram type: flowchart TD, graph LR, sequenceDiagram, etc.")
        
        if "undefined participant" in error_lower:
            suggestions.append("Define participants before using them, or they will be auto-created")
        
        if "png" in error_lower or "render" in error_lower:
            suggestions.append("Make sure the diagram syntax is valid for the specific diagram type")
        
        if not suggestions:
            suggestions.append("Check Mermaid syntax documentation for the specific diagram type")
            suggestions.append("Ensure all node IDs are alphanumeric and start with a letter")
        
        return "; ".join(suggestions)
    
    @staticmethod
    def validate_node_count(code: str, max_nodes: int = 100) -> Tuple[bool, Optional[str]]:
        """Validate that diagram doesn't have too many nodes"""
        # Count potential nodes
        node_pattern = r'\b[a-zA-Z_][a-zA-Z0-9_]*\b'
        nodes = set(re.findall(node_pattern, code))
        
        # Filter out keywords
        keywords = {'flowchart', 'graph', 'subgraph', 'end', 'direction', 'style', 'classDef'}
        nodes = nodes - keywords
        
        if len(nodes) > max_nodes:
            return False, f"Too many nodes ({len(nodes)}). Maximum is {max_nodes}."
        
        return True, None


# Global validator instance
mermaid_validator = MermaidValidator()
