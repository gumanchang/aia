"""
FastAPI Web Application - Main API endpoints
"""
import os
import json
import asyncio
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime

from fastapi import FastAPI, File, UploadFile, Form, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import settings
from core.template_manager import template_manager
from core.file_processor import file_processor, ProcessedFile
from core.document_generator import document_generator, GeneratedDocument
from core.knowledge_base import knowledge_base
from core.session_manager import session_manager, MessageType
from core.logger import get_logger
from core.task_manager import task_manager, TaskType, TaskRequest

# Get logger
logger = get_logger("web")

# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    debug=settings.DEBUG
)

# Mount static files
app.mount("/static", StaticFiles(directory=settings.STATIC_DIR), name="static")


# ============= Pydantic Models =============

class GenerateRequest(BaseModel):
    doc_type: str
    requirements: str
    session_id: Optional[str] = None
    generate_flowcharts: bool = True
    generate_ui: bool = True


class ModifyRequest(BaseModel):
    session_id: str
    modification_request: str


class TemplateUploadRequest(BaseModel):
    name: str
    content: str
    doc_type: str


class MessageResponse(BaseModel):
    status: str
    message: str
    data: Optional[dict] = None


# ============= NEW: Task-based Request Models =============

class ClassifyRequest(BaseModel):
    user_input: str
    conversation_history: Optional[List[Dict[str, str]]] = None
    session_id: Optional[str] = None


class ClassifyResponse(BaseModel):
    status: str
    classification: str
    confidence: float = 1.0
    session_id: Optional[str] = None
    title: Optional[str] = None


class UIGenerateRequest(BaseModel):
    user_input: str
    session_id: Optional[str] = None
    is_screenshot: bool = False


class FlowchartRequest(BaseModel):
    user_input: str
    session_id: Optional[str] = None


class FixMermaidRequest(BaseModel):
    error_message: str
    mermaid_code: str


class TranslateRequest(BaseModel):
    document_content: str
    target_lang: str = "English"  # or "Chinese"


class CommentEditRequest(BaseModel):
    selected_text: str
    user_comment: str
    doc_context: Optional[str] = None


class PolishTextRequest(BaseModel):
    selected_text: str
    user_instruction: str
    before_context: str = ""
    after_context: str = ""
    full_document: Optional[str] = None


class UIEditRequest(BaseModel):
    original_html: str
    user_instruction: str


class GenerateTitleRequest(BaseModel):
    user_input: str


class TaskExecuteRequest(BaseModel):
    task_type: str
    user_input: str
    context: Optional[Dict[str, Any]] = None
    session_id: Optional[str] = None


# ============= API Routes =============

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main HTML page"""
    html_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
    if os.path.exists(html_path):
        with open(html_path, 'r', encoding='utf-8') as f:
            return f.read()
    return HTMLResponse(content="<h1>SDLC Agent</h1><p>UI not found</p>")


@app.get("/callback.html", response_class=HTMLResponse)
async def callback():
    """Serve the OKTA callback HTML page"""
    html_path = os.path.join(os.path.dirname(__file__), "templates", "callback.html")
    if os.path.exists(html_path):
        with open(html_path, 'r', encoding='utf-8') as f:
            return f.read()
    return HTMLResponse(content="<h1>SDLC Agent</h1><p>Callback page not found</p>")


# ============= NEW: Task-based Endpoints =============

@app.post("/api/tasks/classify")
async def classify_intent(request: ClassifyRequest):
    """
    Classify user intent into task types
    
    Returns: UI | BRD | PROCESS | COLLECT | SEARCHING
    Creates a new session only if no session_id provided
    """
    logger.info(f"Classifying intent: {request.user_input[:50]}...")
    
    result = await task_manager.classify_intent(
        request.user_input,
        request.conversation_history
    )
    
    # Only create a new session if no session_id provided
    if not request.session_id:
        title = await task_manager.generate_title(request.user_input)
        session = session_manager.create_session(
            title=title,
            doc_type="CHAT",
            initial_requirements=request.user_input
        )
        
        return {
            "status": "success",
            "classification": result.classification,
            "confidence": result.confidence,
            "session_id": session.id,
            "title": title
        }
    
    # Return classification without creating new session
    return {
        "status": "success",
        "classification": result.classification,
        "confidence": result.confidence
    }


@app.post("/api/tasks/ui-generate")
async def generate_ui(request: UIGenerateRequest):
    """
    Generate UI using Tailwind CSS (streaming)
    """
    logger.info(f"UI Generate request (screenshot={request.is_screenshot}): {request.user_input[:50]}...")
    
    async def generate_stream():
        task_type = TaskType.SCREENSHOT_UI if request.is_screenshot else TaskType.UI_GEN_UI
        task_request = TaskRequest(
            task_type=task_type,
            user_input=request.user_input,
            session_id=request.session_id
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/flowchart")
async def generate_flowchart(request: FlowchartRequest):
    """
    Generate Mermaid flowchart (streaming)
    """
    logger.info(f"Flowchart request: {request.user_input[:50]}...")
    
    async def generate_stream():
        task_request = TaskRequest(
            task_type=TaskType.FLOWCHART,
            user_input=request.user_input,
            session_id=request.session_id
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/fix-mermaid")
async def fix_mermaid(request: FixMermaidRequest):
    """
    Fix Mermaid syntax errors (streaming)
    """
    logger.info("Fix Mermaid request")
    
    async def generate_stream():
        task_request = TaskRequest(
            task_type=TaskType.FIX_MERMAID,
            user_input="",
            context={
                "error_message": request.error_message,
                "mermaid_code": request.mermaid_code
            }
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/translate")
async def translate_document(request: TranslateRequest):
    """
    Translate document to target language (streaming)
    """
    logger.info(f"Translate request to {request.target_lang}")
    
    async def generate_stream():
        task_request = TaskRequest(
            task_type=TaskType.TRANSLATE,
            user_input=request.document_content,
            context={"target_lang": request.target_lang}
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/comment-edit")
async def comment_edit(request: CommentEditRequest):
    """
    Edit document based on user comment (streaming)
    """
    logger.info(f"Comment edit request: {request.user_comment[:50]}...")
    
    async def generate_stream():
        task_request = TaskRequest(
            task_type=TaskType.COMMENT_EDIT,
            user_input="",
            context={
                "selected_text": request.selected_text,
                "user_comment": request.user_comment,
                "doc_context": request.doc_context
            }
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/polish-text")
async def polish_text(request: PolishTextRequest):
    """
    Polish/rewrite selected text (streaming)
    """
    logger.info(f"Polish text request: {request.user_instruction[:50]}...")
    
    async def generate_stream():
        task_request = TaskRequest(
            task_type=TaskType.POLISH_TEXT,
            user_input=request.user_instruction,
            context={
                "selected_text": request.selected_text,
                "before_context": request.before_context,
                "after_context": request.after_context,
                "full_document": request.full_document
            }
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/ui-edit")
async def edit_ui(request: UIEditRequest):
    """
    Edit UI based on user feedback (streaming)
    """
    logger.info(f"UI Edit request: {request.user_instruction[:50]}...")
    
    async def generate_stream():
        task_request = TaskRequest(
            task_type=TaskType.UI_EDIT,
            user_input="",
            context={
                "original_html": request.original_html,
                "user_instruction": request.user_instruction
            }
        )
        
        async for chunk in task_manager.execute_task(task_request):
            yield chunk
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


@app.post("/api/tasks/generate-title")
async def generate_title(request: GenerateTitleRequest):
    """
    Generate session title from user input
    """
    logger.info(f"Generate title request: {request.user_input[:50]}...")
    
    title = await task_manager.generate_title(request.user_input)
    
    return {
        "status": "success",
        "title": title
    }


@app.post("/api/tasks/execute")
async def execute_task(request: TaskExecuteRequest):
    """
    Execute any task type (generic endpoint, streaming)
    """
    logger.info(f"Execute task: {request.task_type}, session: {request.session_id or 'new'}")
    
    try:
        task_type = TaskType(request.task_type.upper())
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Unknown task type: {request.task_type}")
    
    # Save user message to existing session before processing
    # (For new sessions, user message is added by create_session in task_manager)
    if request.session_id:
        logger.info(f"[Execute Task] Saving user message to session {request.session_id}")
        session_manager.add_message(
            session_id=request.session_id,
            message_type=MessageType.USER,
            content=request.user_input
        )
    
    full_content = ""
    
    async def generate_stream():
        nonlocal full_content
        task_request = TaskRequest(
            task_type=task_type,
            user_input=request.user_input,
            context=request.context,
            session_id=request.session_id
        )
        
        async for chunk in task_manager.execute_task(task_request):
            full_content += chunk
            yield chunk
        
        # Save assistant response to session after streaming completes
        if request.session_id and full_content:
            logger.info(f"[Execute Task] Saving assistant response to session {request.session_id}")
            session_manager.add_message(
                session_id=request.session_id,
                message_type=MessageType.ASSISTANT,
                content=full_content
            )
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain; charset=utf-8"
    )


# ============= Existing API Routes =============

@app.get("/api/templates")
async def list_templates():
    """List all available templates"""
    templates = template_manager.list_templates()
    return {
        "status": "success",
        "templates": templates
    }


@app.get("/api/templates/{doc_type}")
async def get_template(doc_type: str):
    """Get a specific template"""
    template = template_manager.get_template(doc_type)
    if not template:
        raise HTTPException(status_code=404, detail=f"Template {doc_type} not found")
    
    return {
        "status": "success",
        "template": {
            "doc_type": template.doc_type,
            "name": template.name,
            "content": template.content,
            "structure": template.structure,
            "visual_sections": template_manager.get_sections_with_visuals(doc_type)
        }
    }


@app.post("/api/templates/upload")
async def upload_template(request: TemplateUploadRequest):
    """Upload a new template"""
    filename = f"{request.doc_type.lower()}_template.md"
    success = template_manager.upload_template(request.content, filename, request.doc_type)
    
    if success:
        return {"status": "success", "message": f"Template {request.doc_type} uploaded successfully"}
    else:
        raise HTTPException(status_code=500, detail="Failed to upload template")


@app.post("/api/documents/generate")
async def generate_document(
    doc_type: str = Form(...),
    requirements: str = Form(...),
    session_id: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[])
):
    """
    Generate a document (non-streaming version)
    
    For streaming, use the WebSocket endpoint
    """
    logger.info(f"Generating {doc_type} document, session: {session_id or 'new'}")
    logger.debug(f"Requirements: {requirements[:100]}...")
    
    # Create or get session
    if not session_id:
        session = session_manager.create_session(
            title=f"New {doc_type} Document",
            doc_type=doc_type,
            initial_requirements=requirements
        )
        session_id = session.id
    else:
        session = session_manager.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Add user message
        session_manager.add_message(
            session_id=session_id,
            message_type=MessageType.USER,
            content=requirements
        )
    
    # Process uploaded files
    attachments = []
    logger.info(f"Processing {len(files)} uploaded files")
    for file in files:
        if file.filename:
            logger.debug(f"Processing file: {file.filename} ({file.content_type})")
            content = await file.read()
            processed = await file_processor.process_file(
                content, file.filename, file.content_type
            )
            attachments.append(processed)
            logger.debug(f"File processed: {file.filename}, content length: {len(processed.content)}")
    
    # Get context if this is a modification
    context = session_manager.get_context_for_generation(session_id)
    previous_document = context.get("previous_document")
    
    # Generate document
    logger.info("Starting document generation...")
    full_content = ""
    chunk_count = 0
    async for chunk in document_generator.generate_document(
        doc_type=doc_type,
        user_requirements=requirements,
        attachments=attachments,
        previous_document=previous_document
    ):
        full_content += chunk
        chunk_count += 1
    
    logger.info(f"Document generation completed, {chunk_count} chunks, total length: {len(full_content)}")
    
    # Update session with generated document
    # Don't pass requirements as modification_request for new document generation
    session_manager.update_document(session_id, full_content, "")
    
    # Save to knowledge base
    doc_id = knowledge_base.save_document(
        doc_type=doc_type,
        title=f"{doc_type} Document - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        content=full_content,
        metadata={
            "session_id": session_id,
            "doc_type": doc_type,
            "version": context.get("document_version", 0) + 1
        }
    )
    
    logger.info(f"Document saved to knowledge base, doc_id: {doc_id}")
    
    return {
        "status": "success",
        "session_id": session_id,
        "document_id": doc_id,
        "content": full_content
    }


@app.post("/api/documents/modify")
async def modify_document(request: ModifyRequest):
    """Modify an existing document"""
    context = session_manager.get_context_for_generation(request.session_id)
    
    if not context["previous_document"]:
        raise HTTPException(status_code=400, detail="No document to modify")
    
    full_content = ""
    async for chunk in document_generator.modify_document(
        current_document=context["previous_document"],
        modification_request=request.modification_request,
        doc_type=context["doc_type"]
    ):
        full_content += chunk
    
    # Update session
    session_manager.update_document(
        request.session_id,
        full_content,
        request.modification_request
    )
    
    return {
        "status": "success",
        "session_id": request.session_id,
        "content": full_content
    }


@app.get("/api/documents/{doc_id}")
async def get_document(doc_id: str):
    """Get a document by ID"""
    document = knowledge_base.get_document(doc_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    return {
        "status": "success",
        "document": {
            "id": document.id,
            "title": document.title,
            "content": document.content,
            "metadata": document.metadata,
            "created_at": document.created_at,
            "updated_at": document.updated_at
        }
    }


@app.get("/api/documents/{doc_id}/export")
async def export_document(doc_id: str, format: str = "markdown"):
    """Export document in different formats (markdown, html, word)"""
    document = knowledge_base.get_document(doc_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    if format == "markdown":
        return StreamingResponse(
            iter([document.content]),
            media_type="text/markdown",
            headers={"Content-Disposition": f"attachment; filename={doc_id}.md"}
        )
    
    elif format == "html":
        from core.document_generator import GeneratedDocument
        
        gen_doc = GeneratedDocument(
            doc_type=document.metadata.get("doc_type", "DOC"),
            title=document.title,
            content=document.content,
            sections=[]
        )
        html_content = document_generator.export_document(gen_doc, "html")
        
        return StreamingResponse(
            iter([html_content]),
            media_type="text/html",
            headers={"Content-Disposition": f"attachment; filename={doc_id}.html"}
        )
    
    elif format == "word" or format == "docx":
        from core.document_generator import GeneratedDocument
        
        # Create GeneratedDocument object
        gen_doc = GeneratedDocument(
            doc_type=document.metadata.get("doc_type", "DOC"),
            title=document.title,
            content=document.content,
            sections=[]
        )
        
        try:
            # Export to Word
            word_path = document_generator.export_to_word(gen_doc)
            
            # Read the file and return as response
            def file_iterator():
                with open(word_path, 'rb') as f:
                    yield f.read()
                # Clean up temp file
                try:
                    os.unlink(word_path)
                except:
                    pass
            
            return StreamingResponse(
                file_iterator(),
                media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                headers={"Content-Disposition": f"attachment; filename={doc_id}.docx"}
            )
            
        except ImportError as e:
            raise HTTPException(status_code=500, detail=f"Word export not available: {str(e)}")
        except Exception as e:
            logger.error(f"Error exporting to Word: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to export to Word: {str(e)}")
    
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported format: {format}. Supported: markdown, html, word/docx")


# ============= NEW: Direct Word Export from Content =============

class WordExportRequest(BaseModel):
    """Request model for direct Word export"""
    title: str = "Document"
    content: str
    doc_type: str = "DOC"


class SaveDocumentEditRequest(BaseModel):
    """Request model for saving document edit to session"""
    session_id: str
    content: str
    edit_summary: str = "用户编辑了文档"


@app.post("/api/documents/save-edit")
async def save_document_edit(request: SaveDocumentEditRequest):
    """
    Save document edit to session and add to chat history
    """
    logger.info(f"[Save Document Edit] session_id={request.session_id}, content_length={len(request.content)}")
    
    # Update document in session
    success = session_manager.update_document(
        request.session_id,
        request.content,
        request.edit_summary
    )
    
    if not success:
        raise HTTPException(status_code=404, detail="Session not found")
    
    # Add a message to chat history indicating the edit
    session_manager.add_message(
        session_id=request.session_id,
        message_type=MessageType.USER,
        content=request.edit_summary
    )
    
    session_manager.add_message(
        session_id=request.session_id,
        message_type=MessageType.ASSISTANT,
        content=f"✅ 文档已更新\n\n{request.content[:500]}..." if len(request.content) > 500 else f"✅ 文档已更新\n\n{request.content}"
    )
    
    return {
        "status": "success",
        "message": "Document saved to session",
        "session_id": request.session_id
    }


@app.post("/api/documents/export/word")
async def export_word_direct(request: WordExportRequest):
    """
    Export document to Word format directly from content.
    This endpoint renders flowcharts and UI designs as images.
    """
    from core.document_generator import GeneratedDocument
    
    logger.info(f"[Word Export] Received request: title={request.title}, doc_type={request.doc_type}")
    logger.info(f"[Word Export] Content length: {len(request.content)}")
    logger.info(f"[Word Export] Has mermaid: {'```mermaid' in request.content}")
    logger.info(f"[Word Export] Has html: {'```html' in request.content}")
    
    # Create GeneratedDocument object
    gen_doc = GeneratedDocument(
        doc_type=request.doc_type,
        title=request.title,
        content=request.content,
        sections=[]
    )
    
    try:
        # Export to Word
        word_path = document_generator.export_to_word(gen_doc)
        logger.info(f"[Word Export] Export completed: {word_path}")
        
        # Read the file and return as response
        def file_iterator():
            with open(word_path, 'rb') as f:
                yield f.read()
            # Clean up temp file
            try:
                os.unlink(word_path)
            except:
                pass
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        return StreamingResponse(
            file_iterator(),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f"attachment; filename=document_{timestamp}.docx"}
        )
        
    except ImportError as e:
        raise HTTPException(status_code=500, detail=f"Word export not available: {str(e)}")
    except Exception as e:
        logger.error(f"Error exporting to Word: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to export to Word: {str(e)}")


# ============= Session Management =============

@app.get("/api/sessions")
async def list_sessions(doc_type: Optional[str] = None):
    """List all sessions"""
    sessions = session_manager.list_sessions(doc_type=doc_type)
    return {
        "status": "success",
        "sessions": sessions
    }


@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str):
    """Get a specific session"""
    session = session_manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {
        "status": "success",
        "session": session.to_dict()
    }


@app.get("/api/sessions/{session_id}/history")
async def get_session_history(session_id: str):
    """Get session conversation history"""
    history = session_manager.get_conversation_history(session_id)
    return {
        "status": "success",
        "history": history
    }


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    """Delete a session"""
    success = session_manager.delete_session(session_id)
    if success:
        return {"status": "success", "message": "Session deleted"}
    else:
        raise HTTPException(status_code=500, detail="Failed to delete session")


@app.put("/api/sessions/{session_id}/title")
async def rename_session(session_id: str, title: str = Form(...)):
    """Rename a session"""
    success = session_manager.rename_session(session_id, title)
    if success:
        return {"status": "success", "message": "Session renamed"}
    else:
        raise HTTPException(status_code=404, detail="Session not found")


# ============= Knowledge Base =============

@app.get("/api/knowledge-base/documents")
async def list_kb_documents(
    doc_type: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = 20
):
    """List documents in knowledge base"""
    documents = knowledge_base.search(query=query, doc_type=doc_type, limit=limit)
    return {
        "status": "success",
        "documents": documents
    }


@app.get("/api/knowledge-base/documents/{doc_id}/similar")
async def get_similar_documents(doc_id: str, limit: int = 5):
    """Get similar documents"""
    similar = knowledge_base.get_similar_documents(doc_id, limit=limit)
    return {
        "status": "success",
        "similar": similar
    }


# ============= WebSocket for Streaming =============

class ConnectionManager:
    """Manages WebSocket connections"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    
    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
    
    async def send_message(self, websocket: WebSocket, message: str):
        await websocket.send_text(message)


manager = ConnectionManager()


@app.websocket("/ws/generate")
async def websocket_generate(websocket: WebSocket):
    """WebSocket endpoint for streaming document generation"""
    await manager.connect(websocket)
    logger.info("WebSocket connection established for document generation")
    
    try:
        while True:
            # Receive request
            data = await websocket.receive_json()
            
            doc_type = data.get("doc_type")
            requirements = data.get("requirements")
            session_id = data.get("session_id")
            files_data = data.get("files", [])  # Base64 encoded files
            
            logger.info(f"WS Generate request: doc_type={doc_type}, session={session_id or 'new'}, files={len(files_data)}")
            
            # Create or get session
            if not session_id:
                # Generate title automatically
                title = await task_manager.generate_title(requirements)
                session = session_manager.create_session(
                    title=title,
                    doc_type=doc_type,
                    initial_requirements=requirements
                )
                session_id = session.id
                await websocket.send_json({
                    "type": "session_created",
                    "session_id": session_id,
                    "title": title
                })
            
            # Process files if any
            attachments = []
            for file_info in files_data:
                try:
                    import base64
                    file_content = base64.b64decode(file_info["content"])
                    logger.debug(f"Processing file: {file_info['filename']}")
                    processed = await file_processor.process_file(
                        file_content,
                        file_info["filename"],
                        file_info["content_type"]
                    )
                    attachments.append(processed)
                    logger.debug(f"File processed successfully: {file_info['filename']}")
                except Exception as e:
                    logger.error(f"Error processing file {file_info.get('filename')}: {e}")
            
            # Get context
            context = session_manager.get_context_for_generation(session_id)
            previous_document = context.get("previous_document")
            conversation_history = context.get("history", [])
            
            # Stream generate
            logger.info(f"Starting document generation stream for session {session_id}")
            full_content = ""
            chunk_count = 0
            async for chunk in document_generator.generate_document(
                doc_type=doc_type,
                user_requirements=requirements,
                attachments=attachments,
                previous_document=previous_document,
                conversation_history=conversation_history
            ):
                full_content += chunk
                chunk_count += 1
                await websocket.send_json({
                    "type": "chunk",
                    "content": chunk
                })
            
            logger.info(f"Stream completed: {chunk_count} chunks, total length {len(full_content)}")
            
            # Update session
            # Don't pass requirements as modification_request for new document generation
            session_manager.update_document(session_id, full_content, "")
            
            # Save to knowledge base
            doc_id = knowledge_base.save_document(
                doc_type=doc_type,
                title=f"{doc_type} Document - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                content=full_content,
                metadata={
                    "session_id": session_id,
                    "doc_type": doc_type
                }
            )
            
            await websocket.send_json({
                "type": "complete",
                "session_id": session_id,
                "document_id": doc_id,
                "content": full_content
            })
    
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
        manager.disconnect(websocket)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"WebSocket error: {error_msg}", exc_info=True)
        
        # Handle Pydantic/OpenAI compatibility errors
        if "by_alias" in error_msg:
            error_msg = "System compatibility error. Please update dependencies: pip install -r requirements.txt --upgrade"
        
        await websocket.send_json({
            "type": "error",
            "message": error_msg
        })
        manager.disconnect(websocket)


@app.websocket("/ws/modify")
async def websocket_modify(websocket: WebSocket):
    """WebSocket endpoint for streaming document modification"""
    await manager.connect(websocket)
    
    try:
        while True:
            data = await websocket.receive_json()
            
            session_id = data.get("session_id")
            modification_request = data.get("modification_request")
            
            context = session_manager.get_context_for_generation(session_id)
            
            if not context["previous_document"]:
                await websocket.send_json({
                    "type": "error",
                    "message": "No document to modify"
                })
                continue
            
            # Stream modify
            full_content = ""
            conversation_history = context.get("history", [])
            async for chunk in document_generator.modify_document(
                current_document=context["previous_document"],
                modification_request=modification_request,
                doc_type=context["doc_type"],
                conversation_history=conversation_history
            ):
                full_content += chunk
                await websocket.send_json({
                    "type": "chunk",
                    "content": chunk
                })
            
            # Update session
            session_manager.update_document(session_id, full_content, modification_request)
            
            await websocket.send_json({
                "type": "complete",
                "session_id": session_id,
                "content": full_content
            })
    
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        await websocket.send_json({
            "type": "error",
            "message": str(e)
        })
        manager.disconnect(websocket)


# ============= NEW: Generic Task WebSocket =============

@app.websocket("/ws/task")
async def websocket_task(websocket: WebSocket):
    """
    Generic WebSocket endpoint for executing any task type
    
    Message format:
    {
        "task_type": "UI_GEN_UI | FLOWCHART | TRANSLATE | ...",
        "user_input": "...",
        "context": {...},
        "session_id": "..."
    }
    """
    await manager.connect(websocket)
    logger.info("WebSocket connection established for generic task execution")
    
    try:
        while True:
            data = await websocket.receive_json()
            
            task_type_str = data.get("task_type", "GENERAL")
            user_input = data.get("user_input", "")
            context = data.get("context", {})
            session_id = data.get("session_id")
            
            logger.info(f"WS Task request: task_type={task_type_str}, session={session_id or 'new'}")
            
            try:
                task_type = TaskType(task_type_str.upper())
            except ValueError:
                await websocket.send_json({
                    "type": "error",
                    "message": f"Unknown task type: {task_type_str}"
                })
                continue
            
            # Note: If this is a new session, the user message was already added by create_session
            # We only need to save the assistant response after task completion
            
            # Execute task
            full_content = ""
            chunk_count = 0
            
            task_request = TaskRequest(
                task_type=task_type,
                user_input=user_input,
                context=context,
                session_id=session_id
            )
            
            async for chunk in task_manager.execute_task(task_request):
                full_content += chunk
                chunk_count += 1
                await websocket.send_json({
                    "type": "chunk",
                    "content": chunk
                })
            
            logger.info(f"Task completed: {chunk_count} chunks, total length {len(full_content)}")
            
            # Save assistant response to session if session exists
            if session_id and full_content:
                session_manager.add_message(
                    session_id=session_id,
                    message_type=MessageType.ASSISTANT,
                    content=full_content
                )
            
            await websocket.send_json({
                "type": "complete",
                "task_type": task_type_str,
                "content": full_content
            })
    
    except WebSocketDisconnect:
        logger.info("Task WebSocket disconnected")
        manager.disconnect(websocket)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Task WebSocket error: {error_msg}", exc_info=True)
        
        await websocket.send_json({
            "type": "error",
            "message": error_msg
        })
        manager.disconnect(websocket)


# ============================================
# OKTA SSO Authentication (Real + Mock)
# ============================================

# OKTA Configuration (fill these in for real OKTA integration)
OKTA_CONFIG = {
    "enabled": False,  # Set to True to enable real OKTA
    "domain": "https://your-company.okta.com",  # Your OKTA domain
    "client_id": "0oa...",  # Your OKTA App Client ID
    "client_secret": "...",  # Your OKTA App Client Secret (keep secure!)
    "redirect_uri": "http://localhost:8000/callback.html"
}

class OktaCallbackRequest(BaseModel):
    """Request model for OKTA callback"""
    code: str
    state: str


class OktaTokenResponse(BaseModel):
    """Response model for OKTA token exchange"""
    access_token: str
    refresh_token: Optional[str] = None
    id_token: Optional[str] = None
    token_type: str = "Bearer"
    expires_in: int = 3600
    user: dict


@app.post("/api/auth/okta/callback", response_model=OktaTokenResponse)
async def okta_callback(request: OktaCallbackRequest):
    """
    Handle OKTA OAuth callback - Exchange authorization code for tokens
    
    When useRealOkta=true in frontend, this endpoint is called by callback.html
    to exchange the authorization code for access/refresh tokens.
    
    TODO: For real OKTA integration:
    1. Set OKTA_CONFIG["enabled"] = True
    2. Fill in OKTA_CONFIG["domain"], ["client_id"], ["client_secret"]
    3. Uncomment the real token exchange code below
    4. Add JWT validation with OKTA's public keys
    """
    
    # =========================================================================
    # MOCK IMPLEMENTATION (for development/testing)
    # Returns fake tokens - does NOT actually validate with OKTA
    # =========================================================================
    if not OKTA_CONFIG["enabled"]:
        logger.info(f"Mock OKTA callback received: code={request.code[:10]}... state={request.state[:10]}...")
        
        # Generate mock tokens
        import secrets
        mock_user = {
            "email": "user@example.com",
            "name": "user",
            "fullName": "Demo User",
            "company": "Example Corp",
            "okta_user_id": "mock_user_001"
        }
        
        return OktaTokenResponse(
            access_token=f"mock_access_token_{secrets.token_urlsafe(16)}",
            refresh_token=f"mock_refresh_token_{secrets.token_urlsafe(16)}",
            id_token=f"mock_id_token_{secrets.token_urlsafe(16)}",
            token_type="Bearer",
            expires_in=3600,
            user=mock_user
        )
    
    # =========================================================================
    # REAL OKTA IMPLEMENTATION (uncomment and configure for production)
    # =========================================================================
    """
    import httpx
    import jwt
    from jwt import PyJWKClient
    
    # 1. Exchange authorization code for tokens
    token_url = f"{OKTA_CONFIG['domain']}/oauth2/default/v1/token"
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            token_url,
            data={
                "grant_type": "authorization_code",
                "code": request.code,
                "redirect_uri": OKTA_CONFIG["redirect_uri"],
                "client_id": OKTA_CONFIG["client_id"],
                "client_secret": OKTA_CONFIG["client_secret"],
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        
        if response.status_code != 200:
            logger.error(f"OKTA token exchange failed: {response.text}")
            raise HTTPException(status_code=401, detail="Invalid authorization code")
        
        tokens = response.json()
        access_token = tokens["access_token"]
        refresh_token = tokens.get("refresh_token")
        id_token = tokens.get("id_token")
    
    # 2. Validate and decode ID Token (JWT)
    try:
        # Fetch OKTA's public keys
        jwks_url = f"{OKTA_CONFIG['domain']}/oauth2/default/v1/keys"
        jwks_client = PyJWKClient(jwks_url)
        
        # Get the signing key
        signing_key = jwks_client.get_signing_key_from_jwt(id_token)
        
        # Decode and verify the token
        payload = jwt.decode(
            id_token,
            signing_key.key,
            algorithms=["RS256"],
            audience=OKTA_CONFIG["client_id"],
            issuer=f"{OKTA_CONFIG['domain']}/oauth2/default"
        )
        
        # Extract user info from token
        user_info = {
            "email": payload.get("email"),
            "name": payload.get("name", payload.get("preferred_username", "").split("@")[0]),
            "fullName": payload.get("name", ""),
            "company": payload.get("org_name", "Unknown"),
            "okta_user_id": payload.get("sub")
        }
        
        logger.info(f"User authenticated via OKTA: {user_info['email']}")
        
        return OktaTokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            id_token=id_token,
            token_type="Bearer",
            expires_in=tokens.get("expires_in", 3600),
            user=user_info
        )
        
    except jwt.InvalidTokenError as e:
        logger.error(f"JWT validation failed: {e}")
        raise HTTPException(status_code=401, detail="Invalid ID token")
    except Exception as e:
        logger.error(f"OKTA callback error: {e}")
        raise HTTPException(status_code=500, detail="Authentication failed")
    """


# ============= Health Check =============

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "features": [
            "classify",
            "ui_generate",
            "flowchart",
            "translate",
            "comment_edit",
            "ui_edit",
            "document_generation",
            "word_export"
        ],
        "auth": {
            "okta_enabled": OKTA_CONFIG["enabled"],
            "okta_domain": OKTA_CONFIG["domain"] if OKTA_CONFIG["enabled"] else None
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
