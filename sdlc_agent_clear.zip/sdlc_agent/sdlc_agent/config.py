"""
SDLC Agent Configuration
"""
import os
from pydantic_settings import BaseSettings
from typing import Optional, List


class Settings(BaseSettings):
    """Application settings"""
    
    # App
    APP_NAME: str = "SDLC Agent"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Paths
    BASE_DIR: str = os.path.dirname(os.path.abspath(__file__))
    TEMPLATES_DIR: str = os.path.join(os.path.dirname(BASE_DIR), "templates")
    UPLOADS_DIR: str = os.path.join(BASE_DIR, "uploads")
    KNOWLEDGE_BASE_DIR: str = os.path.join(BASE_DIR, "knowledge_base")
    GENERATED_DOCS_DIR: str = os.path.join(BASE_DIR, "generated_docs")
    STATIC_DIR: str = os.path.join(BASE_DIR, "static")
    
    # LLM Configuration
    LLM_API_KEY: Optional[str] = os.getenv("LLM_API_KEY", "")
    LLM_API_URL: Optional[str] = os.getenv("LLM_API_URL", "https://api.openai.com/v1")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o")
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 10240
    
    # Supported file types
    SUPPORTED_IMAGE_TYPES: List[str] = ["image/jpeg", "image/png", "image/jpg", "image/gif", "image/webp"]
    SUPPORTED_DOCUMENT_TYPES: List[str] = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  # docx
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  # xlsx
        "application/vnd.ms-excel",  # xls
        "text/plain",
        "text/markdown"
    ]
    
    # Document Types
    DOC_TYPES: dict = {
        "BRD": "Business Requirements Document",
        "FDS": "Functional Design Specification", 
        "SRS": "Software Requirements Specification",
        "PRD": "Product Requirements Document",
        "FEATURE": "Feature Specification"
    }
    
    # Max upload size (50MB)
    MAX_UPLOAD_SIZE: int = 50 * 1024 * 1024
    
    class Config:
        env_file = ".env"


settings = Settings()

# Ensure directories exist
for dir_path in [settings.UPLOADS_DIR, settings.KNOWLEDGE_BASE_DIR, 
                 settings.GENERATED_DOCS_DIR, settings.STATIC_DIR]:
    os.makedirs(dir_path, exist_ok=True)
